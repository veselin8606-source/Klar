#!/bin/bash
awk '
/function AppContent\(\)/ {
    print $0
    print "  const [isMaintenance, setIsMaintenance] = useState(false);"
    print "  const [maintenanceMessage, setMaintenanceMessage] = useState<string | undefined>();"
    print ""
    print "  useEffect(() => {"
    print "    const handleMaintenanceEvent = () => setIsMaintenance(true);"
    print "    window.addEventListener(\"klar-maintenance-mode\", handleMaintenanceEvent);"
    print "    "
    print "    let unsub = () => {};"
    print "    import(\"./lib/firebase\").then(({ db }) => {"
    print "      import(\"firebase/firestore\").then(({ doc, onSnapshot }) => {"
    print "        unsub = onSnapshot(doc(db, \"config\", \"maintenance\"), (docSnap) => {"
    print "          if (docSnap.exists() && docSnap.data().active) {"
    print "            setIsMaintenance(true);"
    print "            setMaintenanceMessage(docSnap.data().message);"
    print "          } else if (docSnap.exists() && !docSnap.data().active) {"
    print "            setIsMaintenance(false);"
    print "          }"
    print "        }, () => {});"
    print "      });"
    print "    }).catch(() => {});"
    print ""
    print "    return () => {"
    print "      window.removeEventListener(\"klar-maintenance-mode\", handleMaintenanceEvent);"
    print "      unsub();"
    print "    };"
    print "  }, []);"
    print ""
    print "  if (isMaintenance) {"
    print "    return <Maintenance onRetry={() => window.location.reload()} message={maintenanceMessage} />;"
    print "  }"
    next
}
{ print $0 }
' src/App.tsx > src/App.tsx.new
mv src/App.tsx.new src/App.tsx
