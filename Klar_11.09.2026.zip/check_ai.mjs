import fs from 'fs';
const text = fs.readFileSync('server.ts', 'utf8');
const regex = /generateContent\(\s*\{([^]*?)\}\s*\)/g;
let match;
let missing = [];
while ((match = regex.exec(text)) !== null) {
  if (!match[1].includes('responseSchema')) {
    missing.push(match[0].substring(0, 100));
  }
}
console.log("Missing responseSchema:", missing.length);
console.log(missing.join('\n\n'));
