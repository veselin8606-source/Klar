import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

// For line 1445 (/api/generate-message)
code = code.replace(/(\/api\/generate-message"[\s\S]*?config: \{[\s\S]*?systemInstruction:[\s\S]*?`,\s*)\}/g,
`$1 responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } } }`);

// icebreakers (2591)
code = code.replace(/(\/api\/icebreakers"[\s\S]*?config: \{[\s\S]*?systemInstruction:[\s\S]*?`,\s*)\}/g,
`$1 responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { suggestions: { type: Type.ARRAY, items: { type: Type.STRING } } } } }`);
code = code.replace(/\{ json: false, feld: "suggestions" \}/g, '{ json: true }'); // if any

// 2272, 2313, 2351, 2449 ? Let's check them.
fs.writeFileSync('server.ts', code);
