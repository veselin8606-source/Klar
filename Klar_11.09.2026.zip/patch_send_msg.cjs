const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const importStr = `import { sendPushNotification } from "./src/server/notifications";\n`;
if (!code.includes('import { sendPushNotification }')) {
  code = code.replace(`import express from "express";`, `import express from "express";\n${importStr}`);
}

const target = `    await db.collection("chats").doc(chatId).update({
      lastMessage: text,
      lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    res.json({ success: true, messageId: newMessageRef.id });`;

const replace = `    await db.collection("chats").doc(chatId).update({
      lastMessage: text,
      lastMessageAt: admin.firestore.FieldValue.serverTimestamp(),
    });

    // Send push notification to the recipient
    const recipientId = chatData.participants.find((p: string) => p !== uid);
    if (recipientId) {
       // Datenschutz: Keine Klarnamen im Sperrbildschirm
       await sendPushNotification(recipientId, "Klar", "Du hast eine neue Nachricht erhalten.");
    }

    res.json({ success: true, messageId: newMessageRef.id });`;

code = code.replace(target, replace);
fs.writeFileSync('server.ts', code);
