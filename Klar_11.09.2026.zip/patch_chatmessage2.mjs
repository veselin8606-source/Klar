import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

const target = `export interface ChatMessage {
  role: 'user' | 'verbindung';
  text: string;
  originalText?: string;
  isTranslated?: boolean;
  translationError?: boolean;
  isRead?: boolean;
  isDateProposal?: boolean;
  proposalDetails?: DateIdee;
}`;

const replacement = `export interface ChatMessage {
  role: 'user' | 'verbindung';
  text: string;
  originalText?: string;
  textTranslated?: string;
  sourceLang?: string;
  targetLang?: string;
  isTranslated?: boolean;
  translationError?: boolean;
  isRead?: boolean;
  isDateProposal?: boolean;
  proposalDetails?: DateIdee;
}`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/screens/ChatView.tsx', code);
  console.log("Patched ChatMessage interface.");
} else {
  console.log("Still not found?");
}
