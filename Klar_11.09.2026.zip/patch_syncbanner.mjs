import fs from 'fs';
let code = fs.readFileSync('src/components/SyncBanner.tsx', 'utf-8');

// Replace the direct Firestore addDoc call with a fetch to our new endpoint
const oldAddDoc = `await addDoc(collection(db, 'chats', action.payload.chatId, 'messages'), action.payload.message);`;
const newFetch = `
            const token = await auth.currentUser?.getIdToken();
            const res = await fetch('/api/messages/send', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'Authorization': \`Bearer \${token}\`
              },
              body: JSON.stringify({
                chatId: action.payload.chatId,
                text: action.payload.message.text
              })
            });
            if (!res.ok) {
              const err = await res.json();
              throw new Error(err.error || 'Failed to send message via API');
            }
`;

if (code.includes(oldAddDoc)) {
  code = code.replace(oldAddDoc, newFetch);
  
  // Need to import auth if it's not imported
  if (!code.includes('auth')) {
    code = code.replace("import { db } from '../lib/firebase';", "import { db, auth } from '../lib/firebase';");
  }

  fs.writeFileSync('src/components/SyncBanner.tsx', code);
  console.log("Patched SyncBanner.tsx");
} else {
  console.log("Could not find addDoc call");
}
