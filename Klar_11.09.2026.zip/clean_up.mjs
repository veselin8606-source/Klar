import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// Remove toggleRecording
content = content.replace(
  /const toggleRecording = \(\) => \{[\s\S]*?return;\n    \}\n    setSprachHinweis\(''\);\n\n    if \(isRecording\) \{[\s\S]*?\} else \{[\s\S]*?\}\n  \};/m,
  ""
);

content = content.replace(
    /const \[isProcessingAudio, setIsProcessingAudio\] = useState\(false\);/,
    ""
);
content = content.replace(
    /setIsProcessingAudio\(true\);/g,
    ""
);
content = content.replace(
    /\} finally \{\n      setIsProcessingAudio\(false\);\n    \}/g,
    "}"
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
