import fs from 'fs';
import path from 'path';

function processFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  let original = content;
  
  if (content.includes('console.error(') && !content.includes('import { melde }')) {
    content = 'import { melde } from "../lib/fehler";\n' + content;
  }
  
  // A naive replace, mapping console.error("...", e) to melde("file", e, { message: "..." })
  content = content.replace(/console\.error\((['"`])(.*?)\1,\s*([a-zA-Z0-9_]+)\)/g, (match, quote, msg, err) => {
    return `melde("${path.basename(filePath)}", ${err}, { message: "${msg}" })`;
  });

  // console.error(err) -> melde("file", err)
  content = content.replace(/console\.error\(([a-zA-Z0-9_]+)\)/g, (match, err) => {
    return `melde("${path.basename(filePath)}", ${err})`;
  });

  if (content !== original) {
    fs.writeFileSync(filePath, content);
  }
}

const dir = 'src/screens';
fs.readdirSync(dir).forEach(file => {
  if (file.endsWith('.tsx')) {
    processFile(path.join(dir, file));
  }
});
