import fs from 'fs';

let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

// Add import
content = content.replace(
  'import { AppTour } from "../components/AppTour";',
  'import { AppTour } from "../components/AppTour";\nimport { LiveTranslationChartWidget } from "../components/LiveTranslationChartWidget";'
);

// Add component to layout
content = content.replace(
  '<MiniDiaryWidget />',
  '<LiveTranslationChartWidget />\n            <MiniDiaryWidget />'
);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
