import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

// 1. Imports
if (!code.includes('import { gateStatus, beantworteGate')) {
  code = code.replace(
    'import { MessageBubble } from "../components/MessageBubble";',
    'import { MessageBubble } from "../components/MessageBubble";\nimport { gateStatus, beantworteGate, type GateZustand, type GateAntwort } from "../lib/klar";'
  );
}

// 2. States
const stateHookStr = '  const [reportReason, setReportReason] = useState("");';
if (code.includes(stateHookStr) && !code.includes('const [gateZustand')) {
  code = code.replace(stateHookStr, stateHookStr + `
  const [gateZustand, setGateZustand] = useState<GateZustand | "lade">("lade");
  const [gateDaten, setGateDaten] = useState<GateAntwort | null>(null);
  const [gateFehler, setGateFehler] = useState<string | null>(null);
  const [gateInput, setGateInput] = useState("");
  const [gateSubmitting, setGateSubmitting] = useState(false);

  useEffect(() => {
    if (!id || istBeispielGespraech) {
      setGateZustand("offen");
      return;
    }
    gateStatus(id).then(res => {
      setGateDaten(res);
      setGateZustand(res.zustand);
    }).catch(e => {
      console.warn('Gate status error:', e);
      setGateZustand("offen");
    });
  }, [id, istBeispielGespraech]);

  const onGateSubmit = async () => {
    if (!id || !gateInput.trim()) return;
    setGateSubmitting(true);
    setGateFehler(null);
    try {
      const res = await beantworteGate(id, gateInput);
      setGateDaten(res);
      setGateZustand(res.zustand);
      setGateInput("");
    } catch (e) {
      setGateFehler(String(e));
    } finally {
      setGateSubmitting(false);
    }
  };
`);
}

// 3. UI
const headerEnd = `        </div>
      </div>`;
const parts = code.split(headerEnd);
if (parts.length > 1 && !code.includes('Icebreaker-Gate')) {
  // we want to insert right after the header
  const gateUI = `
      {gateZustand !== "offen" && (
        <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4 flex flex-col items-center justify-center min-h-[50vh]">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-6 shadow-xl max-w-md w-full text-center">
            <h2 className="text-2xl font-serif text-stone-900 dark:text-stone-100 mb-2">Icebreaker-Gate</h2>
            <p className="text-sm text-stone-500 dark:text-stone-400 mb-6">
              Beide beantworten 2 Fragen. Erst danach öffnet sich der freie Chat.
            </p>
            
            {gateZustand === "lade" && (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-1/2 mx-auto"></div>
              </div>
            )}
            
            {gateZustand === "du_bist_dran" && (
              <div>
                <p className="font-medium text-stone-800 dark:text-stone-200 mb-4">
                  {gateDaten?.fragen?.[gateDaten?.meine || 0] || "Was macht dich wirklich glücklich?"}
                </p>
                <textarea
                  value={gateInput}
                  onChange={(e) => setGateInput(e.target.value)}
                  placeholder="Deine Antwort..."
                  className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl p-4 text-sm mb-4 min-h-[100px] resize-none focus:outline-none focus:ring-2 focus:ring-brand"
                />
                {gateFehler && <p className="text-rose-500 text-sm mb-4">{gateFehler}</p>}
                <button
                  onClick={onGateSubmit}
                  disabled={!gateInput.trim() || gateSubmitting}
                  className="w-full bg-brand text-white font-medium rounded-full py-3 disabled:opacity-50 transition-colors hover:bg-brand-light"
                >
                  {gateSubmitting ? "Senden..." : "Antworten"}
                </button>
              </div>
            )}

            {gateZustand === "wartet_auf_andere" && (
              <div className="py-8">
                <div className="w-16 h-16 bg-stone-100 dark:bg-stone-800 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                  <span className="text-2xl">⏳</span>
                </div>
                <h3 className="font-medium text-stone-800 dark:text-stone-200">Wartet auf Antwort</h3>
                <p className="text-sm text-stone-500 mt-2">Du hast deine Fragen beantwortet. Sobald die andere Person nachzieht, öffnet sich der Chat.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {gateZustand === "offen" && (
        <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4 flex flex-col" id="chat-messages-container">
`;

  // Actually, we need to wrap the whole chat messages area.
  // We can just replace the first `parts[1]` div opener with our condition.
  // Let's do it safer.
}

// Let's do a much simpler approach: Replace the container div directly.
// The main chat body is:
// <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4" id="chat-messages-container">
const chatBodyStart = '<div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4" id="chat-messages-container">';
if (code.includes(chatBodyStart) && !code.includes('Icebreaker-Gate')) {
  code = code.replace(chatBodyStart, `
      {gateZustand !== "offen" && (
        <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4 flex flex-col items-center justify-center min-h-[50vh]">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-6 shadow-xl max-w-md w-full text-center">
            <h2 className="text-2xl font-serif text-stone-900 dark:text-stone-100 mb-2">Icebreaker-Gate</h2>
            <p className="text-sm text-stone-500 dark:text-stone-400 mb-6">
              Beide beantworten 2 Fragen. Erst danach öffnet sich der freie Chat.
            </p>
            
            {gateZustand === "lade" && (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-1/2 mx-auto"></div>
              </div>
            )}
            
            {gateZustand === "du_bist_dran" && (
              <div>
                <p className="font-medium text-stone-800 dark:text-stone-200 mb-4">
                  {gateDaten?.fragen?.[gateDaten?.meine || 0] || "Was macht dich wirklich glücklich?"}
                </p>
                <textarea
                  value={gateInput}
                  onChange={(e) => setGateInput(e.target.value)}
                  placeholder="Deine Antwort..."
                  className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl p-4 text-sm mb-4 min-h-[100px] resize-none focus:outline-none focus:ring-2 focus:ring-brand"
                />
                {gateFehler && <p className="text-rose-500 text-sm mb-4">{gateFehler}</p>}
                <button
                  onClick={onGateSubmit}
                  disabled={!gateInput.trim() || gateSubmitting}
                  className="w-full bg-brand text-white font-medium rounded-full py-3 disabled:opacity-50 transition-colors hover:bg-brand-light"
                >
                  {gateSubmitting ? "Senden..." : "Antworten"}
                </button>
              </div>
            )}

            {gateZustand === "wartet_auf_andere" && (
              <div className="py-8">
                <div className="w-16 h-16 bg-stone-100 dark:bg-stone-800 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                  <span className="text-2xl">⏳</span>
                </div>
                <h3 className="font-medium text-stone-800 dark:text-stone-200">Wartet auf Antwort</h3>
                <p className="text-sm text-stone-500 mt-2">Du hast deine Fragen beantwortet. Sobald die andere Person nachzieht, öffnet sich der Chat.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {gateZustand === "offen" && (
        <>
          <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4" id="chat-messages-container">
`);
  // Close the <> right before DatePrepChecklistModal
  code = code.replace('<DatePrepChecklistModal', '</div>\n      </>\n      )}\n      <DatePrepChecklistModal');
  
  // also the `<div className="flex-1 overflow-y-auto ...` gets closed somewhere, but I wrapped the whole thing in `<> ... </div> </>` so I also need to close the original div! Wait.
  // The original div had a closing `</div>`. 
  // Let's undo the `<DatePrepChecklistModal` replacement.
  code = code.replace('</div>\n      </>\n      )}\n      <DatePrepChecklistModal', '<DatePrepChecklistModal');
  // It's much safer to just wrap it:
  // Original structure:
  // <div id="chat-messages-container"> ... </div>
  // <div className="p-4 bg-white"> ... </div> (the input area)
  // We want to hide BOTH the message container and the input area if gate is not "offen".
}

fs.writeFileSync('src/screens/ChatView.tsx', code);
