import { useState, useRef, useEffect } from 'react';
import { Globe } from 'lucide-react';
import { useTranslation } from 'react-i18next';

const LANGUAGES = [
  { code: 'de', label: 'Deutsch', short: 'DE' },
  { code: 'en', label: 'English', short: 'EN' },
  { code: 'es', label: 'Español', short: 'ES' },
  { code: 'fr', label: 'Français', short: 'FR' },
];

export function LanguageSwitcher() {
  const { i18n, t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const menuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (menuRef.current && !menuRef.current.contains(event.target as Node)) {
        setIsOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const changeLanguage = (code: string) => {
    i18n.changeLanguage(code);
    setIsOpen(false);
  };

  const currentLang = LANGUAGES.find(l => l.code === i18n.language) || LANGUAGES[0]!;

  return (
    <div className="relative" ref={menuRef}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        aria-expanded={isOpen}
        aria-haspopup="listbox"
        aria-label={t('settings.language', 'Sprache')}
        className="flex items-center justify-center gap-1.5 p-2 rounded-full hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors focus:outline-none focus:ring-2 focus:ring-stone-900 dark:focus:ring-stone-100"
        type="button"
      >
        <Globe size={20} aria-hidden="true" />
        <span className="font-medium text-sm uppercase" aria-hidden="true">
          {currentLang.short}
        </span>
      </button>
      
      {isOpen && (
        <ul 
          className="absolute right-0 mt-2 py-1 w-32 bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl shadow-lg z-50"
          role="listbox"
        >
          {LANGUAGES.map((lang) => (
            <li key={lang.code} role="none">
              <button
                role="option"
                aria-selected={i18n.language === lang.code}
                onClick={() => changeLanguage(lang.code)}
                lang={lang.code}
                className={`w-full text-left px-4 py-2 text-sm hover:bg-stone-100 dark:hover:bg-stone-700 transition-colors ${i18n.language === lang.code ? 'text-brand dark:text-brand-light font-medium' : 'text-stone-700 dark:text-stone-300'}`}
              >
                {lang.label}
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
