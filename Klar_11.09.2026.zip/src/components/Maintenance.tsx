import { RefreshCw, Hammer } from "lucide-react";

interface MaintenanceProps {
  onRetry?: () => void;
  message?: string;
}

export function Maintenance({ onRetry, message = "Wir führen derzeit notwendige Wartungsarbeiten durch, um Klar für dich zu verbessern. Wir sind in Kürze wieder da." }: MaintenanceProps) {
  return (
    <div 
      role="alert" 
      aria-live="polite"
      className="maintenance-container fixed inset-0 z-[9999] bg-light-bg dark:bg-dark-bg flex flex-col items-center justify-center p-6 text-center w-full min-h-screen"
    >
      <div className="w-24 h-24 bg-brand/10 dark:bg-brand-light/10 text-brand dark:text-brand-light rounded-full flex items-center justify-center mb-6 mx-auto">
        <Hammer size={48} className="animate-pulse" aria-hidden="true" />
      </div>
      
      <h1 className="text-2xl sm:text-3xl font-semibold text-ink dark:text-stone-100 mb-3 text-center">
        Wir sind gleich zurück
      </h1>
      
      <p className="text-stone-600 dark:text-stone-400 max-w-md mx-auto mb-8 leading-relaxed text-center">
        {message}
      </p>
      
      {onRetry && (
        <button 
          onClick={onRetry}
          aria-label="Seite neu laden, um zu prüfen, ob die Wartung beendet ist"
          className="flex items-center justify-center gap-2 bg-stone-900 dark:bg-stone-100 text-stone-100 dark:text-stone-900 px-6 py-3 rounded-full font-medium hover:opacity-90 transition-opacity focus:outline-none focus:ring-2 focus:ring-brand focus:ring-offset-2 dark:focus:ring-offset-stone-900 mx-auto"
        >
          <RefreshCw size={18} aria-hidden="true" />
          <span>Erneut versuchen</span>
        </button>
      )}
    </div>
  );
}
