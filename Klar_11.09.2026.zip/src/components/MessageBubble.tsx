/* eslint-disable */
import { useState } from 'react';
import { CheckCheck } from 'lucide-react';
import type { ChatMessage } from '../screens/ChatView';

interface MessageBubbleProps {
  msg: ChatMessage;
}

export function MessageBubble({ msg }: MessageBubbleProps) {
  const isMe = msg.role === 'user';
  
  const [showOriginal, setShowOriginal] = useState(false);

  // Ist eine Übersetzung vorhanden (und fehlerfrei)?
  const hasTranslation = !!msg.originalText && !msg.translationError;
  const displayText = showOriginal && msg.originalText ? msg.originalText : msg.text;

  // Barrierefreiheitstexte berechnen
  const ariaStatus = hasTranslation 
    ? (showOriginal ? "Originaltext." : `Übersetzt aus ${msg.sourceLanguage || 'einer anderen Sprache'}.`) 
    : "";

  let timeString = '';
  if ((msg as any).createdAt) {
    const d = new Date((msg as any).createdAt);
    const today = new Date();
    if (d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()) {
      timeString = d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } else {
      timeString = d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
  }

  return (
    <div 
      className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} mb-4 w-full`}
    >
      <div 
        className={`px-4 py-3 rounded-2xl max-w-[80%] relative outline-none ${
          isMe ? 'bg-brand dark:bg-brand-light text-white dark:text-stone-900 rounded-tr-sm' : 'bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-tl-sm text-stone-900 dark:text-stone-100'
        } ${hasTranslation ? 'cursor-pointer' : ''}`}
        onClick={() => hasTranslation && setShowOriginal(!showOriginal)}
        role={hasTranslation ? "button" : "text"}
        aria-label={`Nachricht: ${displayText}. ${ariaStatus}`}
        tabIndex={hasTranslation ? 0 : -1}
        onKeyDown={(e) => {
          if (hasTranslation && (e.key === 'Enter' || e.key === ' ')) {
            e.preventDefault();
            setShowOriginal(!showOriginal);
          }
        }}
      >
        {msg.audioUrl ? (
          <div className="mb-2">
            <audio controls src={msg.audioUrl} className="w-full max-w-[200px] h-8 rounded-full bg-stone-100 dark:bg-stone-800" />
            <p className="mt-2 text-[13px] italic text-stone-600 dark:text-stone-300 leading-relaxed border-l-2 border-brand/50 pl-2">
              {msg.audioTranscription || 'Wird transkribiert...'}
            </p>
          </div>
        ) : (
          <p className="text-[15px] leading-relaxed break-words">{displayText}</p>
        )}

        <div className="flex justify-end items-center mt-2 gap-1.5">
          <span className={`text-[10px] ${isMe ? 'opacity-90' : 'text-stone-400'}`}>{timeString}</span>
          {isMe && <CheckCheck size={14} className={msg.isRead ? "text-stone-100 dark:text-stone-800" : "opacity-70"} />}
        </div>
      </div>
      
      {/* Meta-Zeile unter der Blase */}
      {(!isMe && (hasTranslation || msg.translationError)) && (
        <span 
          aria-live="polite"
          className="text-[11px] text-stone-500 dark:text-stone-400 mt-1 px-1 select-none"
        >
          {msg.translationError 
            ? "Original (Übersetzung verzögert)"
            : showOriginal 
              ? "Original anzeigen. Tippe zum Übersetzen." 
              : `Übersetzt aus ${msg.sourceLanguage || 'Fremdsprache'}.`}
        </span>
      )}
    </div>
  );
}
