import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';

export function DashboardOnboarding() {
  const [step, setStep] = useState(0);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const hasSeen = localStorage.getItem('klar_onboarding_seen');
    if (!hasSeen) {
      setIsVisible(true);
    }
  }, []);

  const close = () => {
    setIsVisible(false);
    localStorage.setItem('klar_onboarding_seen', 'true');
  };

  if (!isVisible) return null;

  const steps = [
    { title: "Willkommen bei Klar", content: "Dein Dashboard. Hier siehst du jeden Tag maximal 8-12 Vorschläge. Keine Endlos-Listen. Wir setzen auf Qualität." },
    { title: "Sichtschutz", content: "Tippe oben auf das Auge-Symbol, um den Bildschirm zu verdecken. Wer mag schon fremde Blicke auf dem Display? Halt es lange gedrückt, um ihn für 5 Minuten zu pausieren." },
    { title: "Verbindungen", content: "Wenn du jemanden anschreibst, landet der Kontakt drüben in deinen Verbindungen. Du hast jeden Tag nur begrenzte Kontakte." },
    { title: "Weniger Scrollen, mehr Fokus", content: "Lass uns loslegen. Dein erstes Kontingent wartet auf dich." }
  ];

  const currentStep = steps[step];

  return (
    <div className="fixed inset-0 z-[400] flex items-center justify-center p-4 bg-black/60">
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.15 }}
        className="bg-white dark:bg-stone-800 rounded-[24px] p-6 max-w-sm w-full"
      >
        <h3 className="text-xl font-serif text-stone-900 dark:text-white mb-2">{currentStep?.title}</h3>
        <p className="text-base text-stone-600 dark:text-stone-300 mb-8">{currentStep?.content}</p>
        
        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            {steps.map((_, i) => (
              <div key={i} className={`w-2 h-2 rounded-full transition-colors ${i === step ? 'bg-brand' : 'bg-stone-200 dark:bg-stone-700'}`} />
            ))}
          </div>
          
          {step < steps.length - 1 ? (
            <button onClick={() => setStep(s => s + 1)} className="px-6 py-2.5 bg-stone-900 dark:bg-stone-100 text-white dark:text-stone-900 rounded-full font-medium">Weiter</button>
          ) : (
            <button onClick={close} className="px-6 py-2.5 bg-brand text-white rounded-full font-medium">Loslegen</button>
          )}
        </div>
      </motion.div>
    </div>
  );
}
