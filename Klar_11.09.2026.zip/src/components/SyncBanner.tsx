import { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { X, WifiOff, Server, Database } from 'lucide-react';
import { getQueuedActions, removeQueuedAction } from '../lib/offlineQueue';
import { auth } from '../lib/firebase';

interface SyncBannerProps {
  variant?: 'toast' | 'admin-inline';
}

export function SyncBanner({ variant = 'toast' }: SyncBannerProps) {
  const [isVisible, setIsVisible] = useState(variant === 'admin-inline');
  const [isSyncing, setIsSyncing] = useState(false);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);
  const [syncMessage, setSyncMessage] = useState('Daten synchronisiert');
  const [syncDetail, setSyncDetail] = useState('Neue Daten sind verfügbar.');
  
  const [firestoreHealth, setFirestoreHealth] = useState('online');
  const [cloudFunctionHealth, setCloudFunctionHealth] = useState('online');

  useEffect(() => {
    if (variant === 'admin-inline') {
      const pingInterval = setInterval(() => {
        setFirestoreHealth(navigator.onLine ? 'online' : 'offline');
        setCloudFunctionHealth(navigator.onLine ? 'online' : 'offline');
      }, 5000);
      return () => clearInterval(pingInterval);
    }
  }, [variant]);

  useEffect(() => {
    if (variant === 'admin-inline') return;
    const handleSync = () => {
      setSyncMessage('Daten synchronisiert');
      setSyncDetail('Neue Daten sind verfügbar. Die Ansicht wurde aktualisiert.');
      setIsVisible(true);
      setTimeout(() => setIsVisible(false), 5000);
    };
    window.addEventListener('klar-in-app-notification', handleSync);
    return () => window.removeEventListener('klar-in-app-notification', handleSync);
  }, [variant]);

  const calculateSize = (actions: any[]) => {
    const jsonString = JSON.stringify(actions);
    const bytes = new Blob([jsonString]).size;
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
  };

  useEffect(() => {
    let checkInterval: any;
    let offlineTimestamp: number | null = !navigator.onLine ? performance.now() : null;
    const checkOfflineQueueSize = async () => {
      if (!navigator.onLine) {
        const actions = await getQueuedActions();
        if (actions.length > 0) {
          const size = calculateSize(actions);
          setIsOffline(true);
          setSyncMessage('Du bist offline');
          setSyncDetail(`${actions.length} Aktionen (${size}) in der Warteschlange. Werden synchronisiert, sobald du wieder online bist.`);
          if (variant !== 'admin-inline') setIsVisible(true);
        }
      }
    };
    if (!navigator.onLine) {
      checkOfflineQueueSize();
      checkInterval = setInterval(checkOfflineQueueSize, 10000); // Check every 10s
    }

    const processQueue = async () => {
      if (offlineTimestamp !== null) {
        const duration = performance.now() - offlineTimestamp;
        console.log(`[Performance Marker] Offline phase duration: ${duration.toFixed(2)}ms`);
        offlineTimestamp = null;
      }
      setIsOffline(false);
      const actions = await getQueuedActions();
      if (actions.length === 0) return;
      
      setIsSyncing(true);
      setSyncMessage('Synchronisiere Offline-Aktionen...');
      setSyncDetail(`${actions.length} Aktion(en) (${calculateSize(actions)}) werden verarbeitet.`);
      if (variant !== 'admin-inline') setIsVisible(true);
      
      try {
        for (const action of actions) {
          if (action.type === 'SEND_MESSAGE') {
            const token = await auth.currentUser?.getIdToken();
            const res = await fetch('/api/messages/send', {
              method: 'POST',
              headers: {
                'Content-Type': 'application/json',
                'X-Firebase-Token': token || ''
              },
              body: JSON.stringify({
                chatId: action.payload.chatId,
                text: action.payload.message.text
              })
            });
            if (!res.ok) {
              const err = await res.json();
              throw new Error(err.error || 'Failed to send message via API');
            }
          }
          await removeQueuedAction(action.id);
        }
        setSyncMessage('Synchronisation erfolgreich');
        setSyncDetail('Alle Offline-Aktionen wurden erfolgreich hochgeladen.');
      } catch (error) {
        console.error("Failed to sync offline actions", error);
        setSyncMessage('Synchronisation fehlgeschlagen');
        setSyncDetail('Einige Aktionen konnten nicht synchronisiert werden.');
      } finally {
        setIsSyncing(false);
        if (variant !== 'admin-inline') setTimeout(() => setIsVisible(false), 5000);
      }
    };

    const handleOnline = () => {
      clearInterval(checkInterval);
      processQueue();
    };

    const handleOffline = () => {
      if (offlineTimestamp === null) {
        offlineTimestamp = performance.now();
      }
      checkOfflineQueueSize();
      checkInterval = setInterval(checkOfflineQueueSize, 10000);
    };

    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    
    if (navigator.onLine) {
      processQueue();
    }
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
      clearInterval(checkInterval);
    };
  }, [variant]);

  if (variant === 'admin-inline') {
    return (
      <div className="bg-stone-50 dark:bg-stone-900 border border-stone-200 dark:border-stone-700 p-4 rounded-xl mb-6">
        <h3 className="font-bold text-sm mb-3 text-stone-900 dark:text-white">System-Status & Synchronisation</h3>
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <Database size={16} className={firestoreHealth === 'online' ? 'text-emerald-500' : 'text-amber-500'} />
            <div>
              <div className="text-xs font-semibold">Firestore Sync</div>
              <div className="text-[10px] text-stone-500">{firestoreHealth === 'online' ? 'Verbunden' : 'Offline'}</div>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Server size={16} className={cloudFunctionHealth === 'online' ? 'text-emerald-500' : 'text-amber-500'} />
            <div>
              <div className="text-xs font-semibold">Cloud Functions</div>
              <div className="text-[10px] text-stone-500">{cloudFunctionHealth === 'online' ? 'Verfügbar' : 'Eingeschränkt'}</div>
            </div>
          </div>
        </div>
        {(isOffline || isSyncing) && (
          <div className="mt-4 pt-3 border-t border-stone-200 dark:border-stone-800 text-xs text-stone-600 dark:text-stone-400">
            {syncMessage}: {syncDetail}
          </div>
        )}
      </div>
    );
  }

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          initial={{ opacity: 0, y: -50 }}
          animate={{ opacity: 1, y: 0 }}
          exit={{ opacity: 0, y: -50 }}
          className={`fixed top-4 left-4 right-4 z-[999] mx-auto max-w-md text-white dark:text-stone-900 rounded-2xl p-4 shadow-md flex items-start gap-3 ${
            isOffline 
              ? 'bg-amber-600 dark:bg-amber-400' 
              : 'bg-stone-900/90 dark:bg-stone-100/90'
          }`}
          role="alert"
          aria-live="assertive"
        >
          <div className="p-2 bg-white/10 dark:bg-black/10 rounded-full shrink-0">
            {isOffline ? (
              <WifiOff size={16} />
            ) : isSyncing ? (
              <span className="text-xs animate-pulse">Sync...</span>
            ) : (
              <span className="w-4 h-4 rounded-full bg-current opacity-50 block"></span>
            )}
          </div>
          <div className="flex-1 pt-0.5">
            <h3 className="text-sm font-semibold mb-1">{syncMessage}</h3>
            <p className="text-xs text-white/80 dark:text-black/60">
              {syncDetail}
            </p>
          </div>
          <button 
            onClick={() => setIsVisible(false)}
            className="p-1.5 shrink-0 rounded-full hover:bg-white/10 dark:hover:bg-black/10 transition-colors"
            aria-label="Schließen"
          >
            <X size={16} />
          </button>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
