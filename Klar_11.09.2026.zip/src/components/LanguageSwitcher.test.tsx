import { render, screen, fireEvent } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach } from 'vitest';
import '@testing-library/jest-dom';
import { LanguageSwitcher } from './LanguageSwitcher';
import i18n from '../i18n/config';

// Mock the lucide-react icons
vi.mock('lucide-react', () => ({
  Globe: () => <div data-testid="globe-icon" />,
}));

describe('LanguageSwitcher', () => {
  beforeEach(() => {
    // Reset language to German before each test
    i18n.changeLanguage('de');
    localStorage.clear();
  });

  it('renders correctly with current language', () => {
    render(<LanguageSwitcher />);
    
    const btn = screen.getByRole('button', { name: /Sprache/i });
    expect(btn).toBeInTheDocument();
    expect(btn).toHaveTextContent(/DE/i);
    expect(screen.getByTestId('globe-icon')).toBeInTheDocument();
  });

  it('opens dropdown and switches language', () => {
    render(<LanguageSwitcher />);
    
    // Check initial state
    const btn = screen.getByRole('button', { name: /Sprache/i });
    expect(btn).toHaveTextContent(/DE/i);
    
    // Open dropdown
    fireEvent.click(btn);
    
    // Select English
    const enOption = screen.getByRole('option', { name: /English/i });
    fireEvent.click(enOption);
    
    // Language should change
    expect(i18n.language).toBe('en');
    expect(document.documentElement.lang).toBe('en');
    expect(localStorage.getItem('klar_language')).toBe('en');
    
    // Button should reflect new language
    expect(btn).toHaveTextContent(/EN/i);
  });
});
