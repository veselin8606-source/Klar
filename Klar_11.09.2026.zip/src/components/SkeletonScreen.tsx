import { motion } from 'motion/react';

export const BaseSkeleton = ({ className = "" }: { className?: string }) => (
  <div className={`animate-pulse bg-stone-200/60 dark:bg-stone-800/60 ${className}`} />
);

export const AppSkeleton = () => {
  return (
    <motion.div 
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.3 }}
      className="h-[100dvh] flex flex-col p-4 sm:p-6 bg-light-bg dark:bg-dark-bg w-full gap-4 max-w-2xl mx-auto overflow-hidden"
    >
      <div className="flex justify-between items-center mb-2 mt-4 px-2">
         <BaseSkeleton className="h-8 w-32 rounded-lg" />
         <div className="flex gap-2">
            <BaseSkeleton className="h-10 w-10 rounded-full" />
            <BaseSkeleton className="h-10 w-10 rounded-full" />
         </div>
      </div>
      
      {/* Top Banner Area */}
      <BaseSkeleton className="h-24 w-full rounded-3xl" />
      
      {/* Cards Area */}
      <div className="flex-1 flex flex-col gap-4">
        <BaseSkeleton className="h-48 w-full rounded-3xl" />
        <BaseSkeleton className="h-40 w-full rounded-3xl" />
      </div>

      {/* Bottom Nav Area */}
      <div className="h-16 w-full rounded-full border border-stone-100 dark:border-stone-800 flex items-center justify-around px-4">
         {[1, 2, 3, 4, 5].map(i => (
           <BaseSkeleton key={i} className="h-10 w-10 rounded-full" />
         ))}
      </div>
    </motion.div>
  );
};
