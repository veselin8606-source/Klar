import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

const audioEndpoint = `
  app.post("/api/messages/send-audio", async (req, res) => {
    const { chatId, audioBase64, mimeType } = req.body;
    
    try {
      if (!process.env.GEMINI_API_KEY) {
         return res.json({ success: true, transcription: "Kein API Key für Transkription gefunden." });
      }
      const model = genai.getGenerativeModel({ model: "gemini-1.5-pro" });
      const result = await model.generateContent([
        "Transkribiere diese Sprachnachricht wortgetreu auf Deutsch. Gib nur das Transkript ohne weitere Erklärungen zurück.",
        { inlineData: { mimeType: mimeType || "audio/webm", data: audioBase64 } }
      ]);
      const transcription = result.response.text();
      // Optionally save to Firestore if auth is configured
      res.json({ success: true, transcription: transcription.trim() });
    } catch (e) {
      console.error("Transkriptionsfehler", e);
      res.json({ success: true, transcription: "Transkription fehlgeschlagen." });
    }
  });
`;

if (!content.includes('/api/messages/send-audio')) {
  content = content.replace(
    /app\.post\("\/api\/journal-audio-dump", async \(req, res\) => \{/,
    audioEndpoint + '\n  app.post("/api/journal-audio-dump", async (req, res) => {'
  );
  fs.writeFileSync('server.ts', content);
}
