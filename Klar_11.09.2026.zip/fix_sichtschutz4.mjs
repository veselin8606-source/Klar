import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');

const replacement = `
  return (
    <div className="relative">
      <motion.button
        whileTap={{ scale: 0.9 }}
        transition={{ duration: 0.1 }}
        onPointerDown={startPress}
        onPointerUp={cancelPress}
        onPointerLeave={cancelPress}
        onClick={() => {
          if (!menuOpen) aktiviereSichtschutz();
        }}
        className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
        aria-label="Bildschirm verdecken"
        title="Bildschirm verdecken"
      >
        <EyeOff size={20} />
      </motion.button>

      <AnimatePresence>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-stone-900 rounded-xl shadow-lg border border-stone-200 dark:border-stone-800 z-50 overflow-hidden"
            >
              <button
                onClick={handlePause}
                className="w-full text-left px-4 py-3 text-sm text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                Für 5 Minuten pausieren
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
`;

content = content.replace(/  return \([\s\S]*?113	\}/m, replacement);

fs.writeFileSync('src/components/Sichtschutz.tsx', content);
