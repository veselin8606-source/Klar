#!/bin/bash
# 1. KlarMatchWidget: Missing useTranslation
sed -i 's/export function KlarMatchWidget({ onProfileClick }: { onProfileClick: (profile: Profile) => void }) {/import { useTranslation } from "react-i18next";\n\nexport function KlarMatchWidget({ onProfileClick }: { onProfileClick: (profile: Profile) => void }) {\n  const { t } = useTranslation();/g' src/components/KlarMatchWidget.tsx

# Also fix "Interessen-Fokus"
sed -i 's/>\s*Interessen-Fokus\s*</>{t("dashboard.interestFocus", "Interessen-Fokus")}</g' src/components/KlarMatchWidget.tsx

# 2. LanguageSwitcher: Possibly undefined check
sed -i 's/const currentLang = LANGUAGES.find(l => l.code === i18n.language) || LANGUAGES\[0\];/const currentLang = LANGUAGES.find(l => l.code === i18n.language) ?? LANGUAGES[0];/g' src/components/LanguageSwitcher.tsx
