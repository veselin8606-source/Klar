import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// There are extra lines 411-422 in ChatView.tsx which are duplicate closure.
content = content.replace(
  /reader\.readAsDataURL\(blob\);\n    \} catch \(e\) \{\n      console\.error\('Audio send error', e\);\n    \} finally \{\n      setIsProcessingAudio\(false\);\n    \}\n  \};\n\n\n\n  \n\n  \n      reader\.readAsDataURL\(blob\);\n    \} catch \(e\) \{\n      console\.error\('Audio send error', e\);\n    \} finally \{\n      setIsProcessingAudio\(false\);\n    \}\n  \};/,
  "      reader.readAsDataURL(blob);\n    } catch (e) {\n      console.error('Audio send error', e);\n    } finally {\n      setIsProcessingAudio(false);\n    }\n  };"
);

// If the regex above failed, let's just do a manual string replace of the exact lines
const blockToRemove = `
  

  

      reader.readAsDataURL(blob);
    } catch (e) {
      console.error('Audio send error', e);
    } finally {
      setIsProcessingAudio(false);
    }
  };`;
content = content.replace(blockToRemove, "");

fs.writeFileSync('src/screens/ChatView.tsx', content);
