import fs from 'fs';
const text = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
let level = 0;
let lines = text.split('\n');
for (let i = 0; i < lines.length; i++) {
  let line = lines[i];
  let stripped = line.replace(/\/\/.*$/, ''); // strip comments
  for (let j = 0; j < stripped.length; j++) {
    if (stripped[j] === '{') level++;
    if (stripped[j] === '}') level--;
  }
  if (level === 0 && stripped.includes('}')) {
    console.log(`Reached level 0 at line ${i + 1}`);
  }
}
console.log('Final level:', level);
