import fs from 'fs';

// 1. App.tsx - Add import for useNavigate
let app = fs.readFileSync('src/App.tsx', 'utf8');
app = app.replace('import { Route, Routes, Navigate }', 'import { Route, Routes, Navigate, useNavigate }');
fs.writeFileSync('src/App.tsx', app);

// 2. Chats.tsx - Remove unused 'Archive', '_' for 'e'
let chats = fs.readFileSync('src/screens/Chats.tsx', 'utf8');
chats = chats.replace('Archive, Trash2', 'Trash2');
chats = chats.replace('onDragEnd={(e, {', 'onDragEnd={(_e, {');
fs.writeFileSync('src/screens/Chats.tsx', chats);

// 3. Profile.tsx - Import icons, use ProfileFeedback
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!prof.includes('import { ChevronRight, MessageSquare, Star, Heart }')) {
  prof = prof.replace('import { ChevronRight', 'import { ChevronRight, MessageSquare, Star, Heart');
}
if (!prof.includes('import { Heart }')) {
  prof = prof.replace('import { Settings, ShieldCheck', 'import { Settings, ShieldCheck, Heart, MessageSquare, Star');
}
// check why ProfileFeedback is not used.
if (!prof.match(/<ProfileFeedback \/>/)) {
  // It probably got stripped because of my regex.
  prof = prof.replace(
    /<\/main>\n\s*<\/div>\n\s*\);\n\}/,
    '  <ProfileFeedback />\n      </main>\n    </div>\n  );\n}'
  );
}
fs.writeFileSync('src/screens/Profile.tsx', prof);

// 4. Tips.tsx - Favorites are unused in Tips? Ah, I used them in string template but wait, they are in the component KlarPrinciplesCards.
let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
// Let's check if the replacement succeeded.
// if toggleFavorite is not used, it means the replace failed.
const regex = /<div className="flex justify-between items-start mb-2">\s*<h4 className="font-medium text-lg text-stone-900 dark:text-stone-100">\{p\.title\}<\/h4>\s*<button onClick=\{\(\) => toggleFavorite\(p\.id\)\}/;
if (!tips.match(regex)) {
  tips = tips.replace(
    /<h4 className="font-medium text-lg text-stone-900 dark:text-stone-100 mb-2">\{p\.title\}<\/h4>/g,
    `<div className="flex justify-between items-start mb-2">
       <h4 className="font-medium text-lg text-stone-900 dark:text-stone-100">{p.title}</h4>
       <button onClick={() => toggleFavorite(p.id)} className="text-stone-400 hover:text-amber-500 transition-colors">
         <Star size={20} className={favorites.includes(p.id) ? "fill-amber-500 text-amber-500" : ""} />
       </button>
     </div>`
  );
}
fs.writeFileSync('src/screens/Tips.tsx', tips);

