const fs = require('fs');
let code = fs.readFileSync('src/components/QuickThemeToggle.tsx', 'utf-8');

const target = `<button
      onClick={umschalten}
      className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
      aria-label={wirktDunkel ? 'Zu hellem Aussehen wechseln' : 'Zu dunklem Aussehen wechseln'}
      title={wirktDunkel ? 'Helles Aussehen' : 'Dunkles Aussehen'}
    >
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={wirktDunkel ? 'sun' : 'moon'}
          initial={{ opacity: 0, scale: 0.8, rotate: wirktDunkel ? -30 : 30 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          exit={{ opacity: 0, scale: 0.8, rotate: wirktDunkel ? 30 : -30 }}
          transition={{ duration: 0.15 }}
          className="flex items-center justify-center"
        >
          {wirktDunkel ? <Sun size={20} /> : <Moon size={20} />}
        </motion.div>
      </AnimatePresence>
    </button>`;

const replacement = `<button
      onClick={umschalten}
      className="relative p-2 w-9 h-9 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
      aria-label={wirktDunkel ? 'Zu hellem Aussehen wechseln' : 'Zu dunklem Aussehen wechseln'}
      title={wirktDunkel ? 'Helles Aussehen' : 'Dunkles Aussehen'}
    >
      <Sun 
        size={20} 
        className={\`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-opacity duration-200 \${wirktDunkel ? 'opacity-100' : 'opacity-0'}\`} 
      />
      <Moon 
        size={20} 
        className={\`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 transition-opacity duration-200 \${wirktDunkel ? 'opacity-0' : 'opacity-100'}\`} 
      />
    </button>`;

code = code.replace(target, replacement);

// Remove unused motion imports if any
code = code.replace(/import { motion, AnimatePresence } from 'motion\/react';\n/, '');

fs.writeFileSync('src/components/QuickThemeToggle.tsx', code);
