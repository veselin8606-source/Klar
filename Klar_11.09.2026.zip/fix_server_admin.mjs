import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

const adminEndpoints = `
  let failedApiCalls: any[] = [];
  
  app.use((req, res, next) => {
    const originalSend = res.send;
    res.send = function (body) {
      if (res.statusCode >= 400 && req.path.startsWith('/api/')) {
        failedApiCalls.unshift({
          path: req.path,
          method: req.method,
          status: res.statusCode,
          time: new Date().toISOString()
        });
        if (failedApiCalls.length > 10) failedApiCalls.pop();
      }
      return originalSend.apply(res, arguments as any);
    };
    next();
  });

  app.get('/api/admin/build-info', (req, res) => {
    res.json({ commit: process.env.COMMIT_HASH || 'unknown', time: process.env.BUILD_TIME || new Date().toISOString() });
  });

  app.get('/api/admin/failed-apis', (req, res) => {
    res.json(failedApiCalls);
  });

  app.get('/api/admin/health-check', async (req, res) => {
    const start = Date.now();
    let fsOk = false, authOk = false;
    try {
      const db = (await import("./src/server/db")).getDb();
      await db.collection('system_health').doc('ping').get();
      fsOk = true;
    } catch(e) {}
    try {
      const { getAuth } = await import("firebase-admin/auth");
      await getAuth().listUsers(1);
      authOk = true;
    } catch(e) {}
    res.json({ 
      firestore: fsOk, 
      auth: authOk, 
      latency: Date.now() - start 
    });
  });
`;

code = code.replace(
  "app.get('/api/system-health'",
  adminEndpoints + "\n  app.get('/api/system-health'"
);

fs.writeFileSync('server.ts', code);
console.log("Admin endpoints added");
