import fs from 'fs';

let content = fs.readFileSync('src/screens/MeilensteineAlle.tsx', 'utf8');

const imports = `import { hapticFeedback, HAPTIC_PATTERNS } from '../lib/haptics';
import { Confetti } from '../components/Confetti';`;

content = content.replace(
  "import type { Rohdaten } from '../lib/meilensteine';",
  "import type { Rohdaten } from '../lib/meilensteine';\n" + imports
);

content = content.replace(
  "const [roh, setRoh] = useState<Rohdaten>({});",
  "const [roh, setRoh] = useState<Rohdaten>({});\n  const [showConfetti, setShowConfetti] = useState(false);"
);

const liReplacement = `
            <li
              key={m.id}
              onClick={() => {
                if (!fertig) {
                  hapticFeedback(HAPTIC_PATTERNS.MEDIUM);
                  setShowConfetti(true);
                  setTimeout(() => setShowConfetti(false), 3000);
                }
              }}
              className={\`rounded-2xl border border-line-ui p-4 flex gap-3 items-start \${!fertig ? 'cursor-pointer hover:bg-stone-50 dark:hover:bg-stone-800/50 transition-colors' : ''}\`}
            >`;

content = content.replace(
  /<li\s*key=\{m\.id\}\s*className="rounded-2xl border border-line-ui p-4 flex gap-3 items-start"\s*>/m,
  liReplacement
);

content = content.replace(
  '<div className="min-h-[100dvh] bg-canvas px-6 py-8 mx-auto w-full max-w-2xl">',
  '<div className="min-h-[100dvh] bg-canvas px-6 py-8 mx-auto w-full max-w-2xl">\n      {showConfetti && <Confetti />}'
);

fs.writeFileSync('src/screens/MeilensteineAlle.tsx', content);
