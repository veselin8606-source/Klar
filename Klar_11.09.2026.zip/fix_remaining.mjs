import fs from 'fs';

// Fix ChatView.tsx
let cv = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
cv = cv.replace(/melde\("ChatView\.tsx", e, \{ message: "Failed to sync offline messages" \}\)/, `melde("ChatView.tsx", new Error("offline"), { message: "Failed to sync offline messages" })`);
fs.writeFileSync('src/screens/ChatView.tsx', cv);

// Fix Dashboard.tsx
let db = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
db = db.replace(/isSmartKontaktEnabled/g, 'isSmartMatchEnabled');
db = db.replace(/checkNewProfilesForSmartKontaktes/g, 'checkNewProfilesForSmartMatches');
db = db.replace(/isDeepKontakt/g, 'isDeepMatch');
db = db.replace(/const filtered = profiles\.filter\(p =>/g, 'const filtered = profiles.filter((p: any) =>');
fs.writeFileSync('src/screens/Dashboard.tsx', db);

