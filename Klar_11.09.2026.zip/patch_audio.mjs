import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const audioState = `
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [isProcessingAudio, setIsProcessingAudio] = useState(false);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      let chunks: BlobPart[] = [];
      
      recorder.ondataavailable = e => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: recorder.mimeType });
        processAudioMessage(blob, recorder.mimeType);
        stream.getTracks().forEach(t => t.stop());
      };
      
      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (e) {
      console.error('Mic error:', e);
      setSprachHinweis('Mikrofon konnte nicht gestartet werden.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  const processAudioMessage = async (blob: Blob, mimeType: string) => {
    setIsProcessingAudio(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        const token = auth.currentUser ? await auth.currentUser.getIdToken() : '';
        
        // Show optimistic UI for audio message
        const tempId = Date.now().toString();
        const localAudioUrl = URL.createObjectURL(blob);
        setMessages(prev => [...prev, {
          id: tempId,
          role: 'user',
          text: 'Sprachnachricht',
          audioUrl: localAudioUrl,
          audioTranscription: 'Wird transkribiert...',
          isRead: false
        }]);

        const res = await fetch('/api/messages/send-audio', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': \`Bearer \${token}\`
          },
          body: JSON.stringify({ chatId: id, audioBase64: base64data, mimeType })
        });
        
        if (res.ok) {
           // Rely on firestore snapshot listener to update it, or reload
        }
      };
      reader.readAsDataURL(blob);
    } catch (e) {
      console.error('Audio send error', e);
    } finally {
      setIsProcessingAudio(false);
    }
  };
`;

content = content.replace(
  "const [sprachHinweis, setSprachHinweis] = useState('');",
  "const [sprachHinweis, setSprachHinweis] = useState('');\n" + audioState
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
