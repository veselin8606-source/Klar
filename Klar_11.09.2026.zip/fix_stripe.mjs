import fs from 'fs';
let code = fs.readFileSync('src/server/stripeService.ts', 'utf8');

code = code.replace(
  '       const userDoc = snapshot.docs[0];\n       await userDoc.ref.set({ plan: \'free\' }, { merge: true });\n       await trackEvent(userDoc!.id, \'subscription_cancelled\' as any as any, { subscriptionId: subscription.id });',
  '       const userDoc = snapshot.docs[0];\n       if (userDoc) {\n         await userDoc.ref.set({ plan: \'free\' }, { merge: true });\n         await trackEvent(userDoc.id, \'subscription_cancelled\' as any, { subscriptionId: subscription.id });\n       }'
);

fs.writeFileSync('src/server/stripeService.ts', code);
console.log('Fixed stripeService');
