import fs from 'fs';
let content = fs.readFileSync('src/components/QuickThemeToggle.tsx', 'utf8');
content = content.replace(
  /import \{ Sun, Moon \} from 'lucide-react';/,
  "import { Sun, Moon, MonitorSmartphone } from 'lucide-react';"
);
content = content.replace(
  /\{theme === 'dark' && <div className="text-\[10px\].*<\/div>\}/,
  "{theme === 'dark' && <MonitorSmartphone size={20} />}"
);
fs.writeFileSync('src/components/QuickThemeToggle.tsx', content);
