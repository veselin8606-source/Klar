import fs from 'fs';

const files = [
  'src/components/DatingReadinessWidget.tsx',
  'src/components/DailyCoachInsightWidget.tsx'
];

for (const file of files) {
  let content = fs.readFileSync(file, 'utf8');
  
  // Replace import
  content = content.replace('import { auth } from "../lib/firebase";\n', '');
  if (!content.includes('import { useAuth }')) {
    content = content.replace('import { useState, useEffect } from "react";', 'import { useState, useEffect } from "react";\nimport { useAuth } from "../lib/AuthContext";');
  }

  // Replace component start
  content = content.replace('export function DatingReadinessWidget() {\n  const [data', 'export function DatingReadinessWidget() {\n  const { user } = useAuth();\n  const [data');
  content = content.replace('export function DailyCoachInsightWidget() {\n  const [data', 'export function DailyCoachInsightWidget() {\n  const { user } = useAuth();\n  const [data');

  // Replace useEffect start
  content = content.replace('useEffect(() => {\n    const fetchReadiness = async () => {', 'useEffect(() => {\n    if (!user) return;\n    const fetchReadiness = async () => {');
  content = content.replace('useEffect(() => {\n    const fetchInsight = async () => {', 'useEffect(() => {\n    if (!user) return;\n    const fetchInsight = async () => {');

  // Replace auth.currentUser
  content = content.replace(/const token = await auth\.currentUser\?\.getIdToken\(\);/g, 'const token = await user.getIdToken();');

  // Replace useEffect deps
  content = content.replace('    fetchReadiness();\n  }, []);', '    fetchReadiness();\n  }, [user]);');
  content = content.replace('    fetchInsight();\n  }, []);', '    fetchInsight();\n  }, [user]);');

  fs.writeFileSync(file, content, 'utf8');
}
