import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

// Insert import
content = content.replace(
  /import \{ WeeklyMilestoneRevealWidget \} from "\.\.\/components\/WeeklyMilestoneRevealWidget";/,
  "import { WeeklyMilestoneRevealWidget } from \"../components/WeeklyMilestoneRevealWidget\";\nimport { ActivityChartWidget } from \"../components/ActivityChartWidget\";"
);

// Insert component
content = content.replace(
  /        <div className="min-w-\[85%\] max-w-md snap-center shrink-0 empty:hidden">\n          <WeeklySuccessSummaryWidget \/>\n        <\/div>\n/,
  "        <div className=\"min-w-[85%] max-w-md snap-center shrink-0 empty:hidden\">\n          <WeeklySuccessSummaryWidget />\n        </div>\n        <div className=\"min-w-[85%] max-w-md snap-center shrink-0 empty:hidden\">\n          <ActivityChartWidget />\n        </div>\n"
);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
