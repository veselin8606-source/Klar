import fs from 'fs';
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf8');

const feedbackForm = `
function ProfileFeedback() {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (rating === 0) return;
    setSubmitted(true);
    // In a real app this would post to backend
  };

  if (submitted) {
    return (
      <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm text-center">
        <div className="w-12 h-12 bg-green-100 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <Heart size={24} />
        </div>
        <h3 className="font-medium text-stone-900 dark:text-stone-100">Danke für dein Feedback!</h3>
        <p className="text-sm text-stone-500 mt-2">Deine Meinung hilft uns, Klar noch besser zu machen.</p>
      </div>
    );
  }

  return (
    <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-6 shadow-sm">
      <h3 className="font-medium text-stone-900 dark:text-stone-100 flex items-center gap-2 mb-4">
        <MessageSquare size={18} className="text-brand dark:text-brand-light" />
        Deine Meinung zu Klar
      </h3>
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm text-stone-600 dark:text-stone-400 mb-2">Wie zufrieden bist du?</label>
          <div className="flex gap-2">
            {[1,2,3,4,5].map(r => (
              <button 
                key={r} type="button" 
                onClick={() => setRating(r)}
                className={\`p-2 rounded-full transition-colors \${rating >= r ? 'text-amber-400' : 'text-stone-300 dark:text-stone-700'}\`}
              >
                <Star size={24} className={rating >= r ? "fill-current" : ""} />
              </button>
            ))}
          </div>
        </div>
        <div>
          <label className="block text-sm text-stone-600 dark:text-stone-400 mb-2">Verbesserungsvorschläge (optional)</label>
          <textarea 
            className="w-full bg-stone-50 dark:bg-stone-950 border border-stone-200 dark:border-stone-800 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-brand/50 min-h-[80px]"
            placeholder="Was können wir besser machen?"
            value={feedback}
            onChange={e => setFeedback(e.target.value)}
          />
        </div>
        <button 
          type="submit" 
          disabled={rating === 0}
          className="w-full bg-stone-100 dark:bg-stone-800 hover:bg-stone-200 dark:hover:bg-stone-700 text-stone-700 dark:text-stone-300 font-medium py-2.5 rounded-xl transition-colors disabled:opacity-50"
        >
          Feedback senden
        </button>
      </form>
    </div>
  );
}
`;

// Make sure imports exist
if (!code.includes('import { MessageSquare')) {
  code = code.replace('import { ChevronRight', 'import { ChevronRight, MessageSquare, Star, Heart');
}
code = code.replace(/export default function Profile\(\) \{/, feedbackForm + '\nexport default function Profile() {');

// Inject at the end of the profile settings
code = code.replace(
  /<div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-sm mb-6">([\s\S]*?)<\/div>/,
  '<div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-2xl p-4 shadow-sm mb-6">$1</div>\n<ProfileFeedback />'
);

fs.writeFileSync('src/screens/Profile.tsx', code);
