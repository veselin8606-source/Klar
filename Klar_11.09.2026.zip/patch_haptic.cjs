const fs = require('fs');
let code = fs.readFileSync('src/components/HapticSettings.tsx', 'utf-8');

// Add `isTesting` state
code = code.replace(
  "const [patternType, setPatternType] = useState<string>('medium');",
  "const [patternType, setPatternType] = useState<string>('medium');\n  const [isTesting, setIsTesting] = useState(false);"
);

// Update testVibration function
code = code.replace(
  /const testVibration = \(\) => \{\n    triggerHaptic\('LIGHT_TAP'\);\n  \};/,
  `const testVibration = () => {
    triggerHaptic('LIGHT_TAP');
    setIsTesting(true);
    setTimeout(() => setIsTesting(false), 200);
  };`
);

// Update Play icon in the button
code = code.replace(
  /<Play size=\{16\} \/>/g,
  '<Play size={16} className={`transition-transform duration-200 ${isTesting ? \'scale-150\' : \'scale-100\'}`} />'
);

fs.writeFileSync('src/components/HapticSettings.tsx', code);
