import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(
  "const andereUid = chatData.participants.find((p: string) => p !== meineUid);",
  "// otherUid wird unten nochmal definiert, diese Zeile entfernen wir"
);

content = content.replace(
  "textTranslated = response.text.trim();",
  "textTranslated = response.text ? response.text.trim() : null;"
);

fs.writeFileSync('server.ts', content);
