import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

const newEndpoint = `
  app.post("/api/messages/mark-read", async (req, res) => {
    const { chatId, messageIds } = req.body;
    const { meineUid, fehler } = await verifiziereToken(req.headers.authorization);
    if (fehler || !meineUid) return res.status(401).json({ error: "Unauthorized" });

    try {
      const db = getFirestore();
      const chatSnap = await db.collection("chats").doc(chatId).get();
      if (!chatSnap.exists) return res.status(404).json({ error: "Chat not found" });
      const chatData = chatSnap.data();
      if (!chatData.participants.includes(meineUid)) return res.status(403).json({ error: "Forbidden" });

      const batch = db.batch();
      for (const msgId of messageIds) {
        const msgRef = db.collection("chats").doc(chatId).collection("messages").doc(msgId);
        batch.update(msgRef, { isRead: true });
      }
      await batch.commit();
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
`;

content = content.replace('// ── ENTFERNT 14.08.2026 — /api/admob-ssv', newEndpoint + '\n  // ── ENTFERNT 14.08.2026 — /api/admob-ssv');
fs.writeFileSync('server.ts', content);
