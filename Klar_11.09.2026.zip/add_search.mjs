import fs from 'fs';
let content = fs.readFileSync('src/screens/Chats.tsx', 'utf8');

// Insert Search import
content = content.replace(
  /import \{ Clock, ShieldCheck \} from "lucide-react";/,
  "import { Clock, ShieldCheck, Search } from \"lucide-react\";"
);

// Add search state and filter
content = content.replace(
  /  const \[profiles, setProfiles\] = useState\(allProfiles\);/,
  "  const [profiles, setProfiles] = useState(allProfiles);\n  const [searchQuery, setSearchQuery] = useState('');\n\n  const filteredProfiles = profiles.filter(p => \n    p.name.toLowerCase().includes(searchQuery.toLowerCase()) || \n    (p.bio && p.bio.toLowerCase().includes(searchQuery.toLowerCase()))\n  );"
);

// Add search input in JSX
content = content.replace(
  /      <div className="flex justify-between items-end mb-6">\n        <h1 className="text-3xl font-serif text-stone-900 dark:text-stone-100">Deine Verbindungen<\/h1>\n        <Link to="\/profile" className="flex items-center gap-1\.5 text-brand dark:text-brand-light text-sm font-medium bg-brand\/10 dark:bg-brand-light\/10 px-3 py-1\.5 rounded-full hover:bg-brand\/20 dark:hover:bg-brand-light\/20 transition-colors">\n          <ShieldCheck size=\{16\} \/> Verifiziert\n        <\/Link>\n      <\/div>/,
  `      <div className="flex justify-between items-end mb-6">
        <h1 className="text-3xl font-serif text-stone-900 dark:text-stone-100">Deine Verbindungen</h1>
        <Link to="/profile" className="flex items-center gap-1.5 text-brand dark:text-brand-light text-sm font-medium bg-brand/10 dark:bg-brand-light/10 px-3 py-1.5 rounded-full hover:bg-brand/20 dark:hover:bg-brand-light/20 transition-colors">
          <ShieldCheck size={16} /> Verifiziert
        </Link>
      </div>

      <div className="relative mb-6">
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          <Search className="h-5 w-5 text-stone-400" />
        </div>
        <input
          type="text"
          placeholder="Nach Namen oder Schlagworten suchen..."
          className="block w-full pl-10 pr-3 py-3 border border-stone-200 dark:border-stone-800 rounded-xl leading-5 bg-white dark:bg-stone-900 text-stone-900 dark:text-stone-100 placeholder-stone-500 focus:outline-none focus:ring-1 focus:ring-brand focus:border-brand sm:text-sm"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
        />
      </div>`
);

// Map filteredProfiles instead of profiles
content = content.replace(
  /          \{profiles\.map\(\(profile, i\) => \(/,
  "          {filteredProfiles.map((profile, i) => ("
);

fs.writeFileSync('src/screens/Chats.tsx', content);
