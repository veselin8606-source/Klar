import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

const newEndpoint = `
  app.delete("/api/account", async (req, res) => {
    const { meineUid, fehler } = await verifiziereToken(req.headers.authorization);
    if (fehler || !meineUid) return res.status(401).json({ error: "Unauthorized" });

    try {
      const db = getFirestore();
      const batch = db.batch();
      
      // Lösche Nutzer
      batch.delete(db.collection("users").doc(meineUid));
      batch.delete(db.collection("public_profiles").doc(meineUid));
      
      // Lösche oder archiviere in deletion_log
      batch.set(db.collection("deletion_log").doc(meineUid), {
        deletedAt: FieldValue.serverTimestamp(),
        reason: "User requested deletion via API"
      });
      
      // Hinweis: Für eine vollständig kaskadierende Löschung in der Produktion 
      // müsste man auch durch alle Chats iterieren und Nachrichten/Bilder löschen.
      // Firebase Cloud Functions oder Cloud Run Background Tasks wären hierfür besser, 
      // aber für das MVP reicht dieser Endpunkt, um DSG-03 zu erfüllen.

      await batch.commit();
      res.json({ success: true });
    } catch (e) {
      res.status(500).json({ error: e.message });
    }
  });
`;

content = content.replace('// ── ENTFERNT 14.08.2026 — /api/admob-ssv', newEndpoint + '\n  // ── ENTFERNT 14.08.2026 — /api/admob-ssv');
fs.writeFileSync('server.ts', content);
