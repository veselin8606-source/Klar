import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace(/  \);\s*\}\s*\}\s*$/g, '  );\n}\n');
fs.writeFileSync('src/screens/ChatView.tsx', content);
