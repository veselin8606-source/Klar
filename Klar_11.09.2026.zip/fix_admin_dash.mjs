import fs from 'fs';
let code = fs.readFileSync('src/screens/AdminDashboard.tsx', 'utf8');

const newComponents = `
function BuildInfoWidget() {
  const [info, setInfo] = useState<{commit?: string, time?: string} | null>(null);
  useEffect(() => {
    fetch('/api/admin/build-info').then(r => r.json()).then(setInfo).catch(() => {});
  }, []);
  if (!info) return null;
  return (
    <div className="bg-white border border-stone-200 p-4 rounded-xl mb-6">
      <h3 className="font-medium mb-2 text-stone-900 flex items-center gap-2"><Server size={16} /> Build Info</h3>
      <div className="text-sm text-stone-600 font-mono">
        <p>Commit: {info.commit}</p>
        <p>Time: {new Date(info.time as string).toLocaleString()}</p>
      </div>
    </div>
  );
}

function FailedApiLogWidget() {
  const [logs, setLogs] = useState<any[]>([]);
  useEffect(() => {
    fetch('/api/admin/failed-apis').then(r => r.json()).then(setLogs).catch(() => {});
  }, []);
  return (
    <div className="bg-white border border-red-200 p-4 rounded-xl mb-6">
      <h3 className="font-medium mb-2 text-red-900 flex items-center gap-2"><AlertCircle size={16} /> Letzte fehlgeschlagene API-Aufrufe</h3>
      {logs.length === 0 ? (
        <p className="text-sm text-stone-500">Keine Fehler registriert.</p>
      ) : (
        <ul className="text-sm space-y-2">
          {logs.map((l, i) => (
            <li key={i} className="flex justify-between border-b border-red-100 pb-1">
              <span className="font-mono text-red-600">{l.method} {l.path}</span>
              <span className="text-stone-500">{l.status}</span>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

function HiddenDebugHealthCheck() {
  const [visible, setVisible] = useState(false);
  const [health, setHealth] = useState<any>(null);

  const check = async () => {
    try {
      const res = await fetch('/api/admin/health-check');
      setHealth(await res.json());
    } catch(e) {}
  };

  return (
    <div className="mb-6">
      <button onClick={() => setVisible(!visible)} className="text-xs text-stone-300 hover:text-stone-500">Debug UI</button>
      {visible && (
        <div className="bg-stone-50 border border-stone-200 p-4 rounded-xl mt-2 text-sm">
          <div className="flex justify-between items-center mb-2">
            <strong>System Health Check</strong>
            <button onClick={check} className="text-brand hover:underline">Prüfen</button>
          </div>
          {health ? (
            <ul className="space-y-1 font-mono text-xs">
              <li>Firestore: {health.firestore ? '✅ OK' : '❌ FAIL'}</li>
              <li>Auth: {health.auth ? '✅ OK' : '❌ FAIL'}</li>
              <li>Latenz: {health.latency}ms</li>
            </ul>
          ) : <p className="text-stone-500">Noch nicht geprüft.</p>}
        </div>
      )}
    </div>
  );
}
`;

code = code.replace(
  "export default function AdminDashboard() {",
  newComponents + "\nexport default function AdminDashboard() {"
);

code = code.replace(
  "          <div className=\"space-y-6\">\n            <div className=\"bg-white dark:bg-stone-900",
  "          <div className=\"space-y-6\">\n            <BuildInfoWidget />\n            <FailedApiLogWidget />\n            <HiddenDebugHealthCheck />\n            <div className=\"bg-white dark:bg-stone-900"
);

fs.writeFileSync('src/screens/AdminDashboard.tsx', code);
console.log("Admin widgets added");
