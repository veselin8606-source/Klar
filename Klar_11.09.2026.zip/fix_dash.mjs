import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

content = content.replace(
  /import \{ LiveTranslationChartWidget \} from "\.\.\/components\/LiveTranslationChartWidget";/,
  `import { LiveTranslationChartWidget } from "../components/LiveTranslationChartWidget";\nimport { ActivityChartWidget } from "../components/ActivityChartWidget";`
);

content = content.replace(
  /      <BeiSicht><LiveTranslationChartWidget \/>\n            <MiniDiaryWidget \/><\/BeiSicht>/,
  `      <BeiSicht>
        <LiveTranslationChartWidget />
      </BeiSicht>
      <BeiSicht>
        <ActivityChartWidget />
      </BeiSicht>
      <BeiSicht>
        <MiniDiaryWidget />
      </BeiSicht>`
);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
