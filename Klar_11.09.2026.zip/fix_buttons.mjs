import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace(
  /onClick=\{toggleRecording\}/g,
  "onClick={isRecording ? stopRecording : startRecording}"
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
