import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  "const db = require('firebase-admin/firestore').getFirestore();",
  "const db = require('./src/server/db').getDb();"
);
code = code.replace(
  "require('firebase-admin/firestore').FieldValue.serverTimestamp()",
  "require('firebase-admin/firestore').FieldValue.serverTimestamp()" // Keep this for now, but maybe it throws? Let's check FieldValue
);

fs.writeFileSync('server.ts', code);
