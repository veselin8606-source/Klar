import fs from 'fs';

const code = fs.readFileSync('server.ts', 'utf8');

const replacement = `export async function startServer() {
  try {
    const app = await baueApp();
    try {
      await (await import("./src/server/db")).initServerDb();
    } catch (dbErr) {
      console.error("CRITICAL: DB Init failed:", dbErr);
      app.use('*', (req, res) => res.status(500).send('DB INIT ERROR: ' + (dbErr?.message || String(dbErr)) + '\\n' + (dbErr?.stack || '')));
      app.listen(PORT, "0.0.0.0", () => console.log(\`Error Server running on http://localhost:\${PORT}\`));
      return;
    }
    app.listen(PORT, "0.0.0.0", () => {
      console.log(\`Server running on http://localhost:\${PORT}\`);
    });
  } catch (err) {
    console.error("CRITICAL: startServer failed:", err);
    import('express').then((express) => {
      const crashApp = express.default();
      crashApp.use('*', (req, res) => res.status(500).send('STARTUP CRASH: ' + (err?.message || String(err)) + '\\n' + (err?.stack || '')));
      crashApp.listen(PORT, "0.0.0.0", () => console.log(\`Crash Server running on http://localhost:\${PORT}\`));
    });
  }
}`;

const target = `export async function startServer() {
  const app = await baueApp();
  await (await import("./src/server/db")).initServerDb();
  app.listen(PORT, "0.0.0.0", () => {
    console.log(\`Server running on http://localhost:\${PORT}\`);
  });
}`;

if (code.includes(target)) {
  fs.writeFileSync('server.ts', code.replace(target, replacement));
  console.log("Patched successfully.");
} else {
  console.error("Target not found!");
}
