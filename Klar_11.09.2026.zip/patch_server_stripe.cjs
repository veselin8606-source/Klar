const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const importStr = `import { createCheckoutSession, handleStripeWebhook } from "./src/server/stripeService";\n`;
if (!code.includes('createCheckoutSession')) {
  code = code.replace(`import express from "express";`, `import express from "express";\n${importStr}`);
}

const target = `  app.post("/api/subscribe-klar-plus", (_req, res) => {
    res.status(501).json({
      error: "Klar Plus ist noch nicht buchbar. Die Zahlungsanbindung fehlt.",
    });
  });`;

const replace = `  // Webhook needs raw body for signature verification
  app.post("/api/webhooks/stripe", express.raw({ type: 'application/json' }), async (req, res) => {
    try {
      const signature = req.headers['stripe-signature'] as string;
      const result = await handleStripeWebhook(req.body, signature);
      res.json(result);
    } catch (err: any) {
      console.error('Stripe Webhook Error:', err.message);
      res.status(400).send(\`Webhook Error: \${err.message}\`);
    }
  });

  app.post("/api/subscribe-klar-plus", express.json(), async (req, res) => {
    try {
      const { userId, returnUrl } = req.body;
      if (!userId || !returnUrl) return res.status(400).send("Missing parameters");
      
      const checkoutUrl = await createCheckoutSession(userId, returnUrl);
      res.json({ url: checkoutUrl });
    } catch (e: any) {
      console.error(e);
      if (e.message?.includes('STRIPE_SECRET_KEY')) {
         return res.status(501).json({ error: "Stripe ist noch nicht konfiguriert (STRIPE_SECRET_KEY fehlt)." });
      }
      res.status(500).json({ error: "Checkout fehlgeschlagen" });
    }
  });`;

if (code.includes('app.post("/api/subscribe-klar-plus", (_req, res) => {')) {
  code = code.replace(target, replace);
  fs.writeFileSync('server.ts', code);
}
