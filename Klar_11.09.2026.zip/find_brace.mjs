import fs from 'fs';
const content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
let balance = 0;
const lines = content.split('\n');
for (let i = 0; i < lines.length; i++) {
  const line = lines[i];
  for (let j = 0; j < line.length; j++) {
    if (line[j] === '{') balance++;
    if (line[j] === '}') balance--;
  }
}
console.log('Balance:', balance);
if (balance > 0) {
    fs.appendFileSync('src/screens/ChatView.tsx', '}\n');
}
