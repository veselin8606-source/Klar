import fs from 'fs';
let content = fs.readFileSync('src/components/GlobalErrorOverlay.tsx', 'utf8');

content = content.replace(
  `window.addEventListener('error', handleError);`,
  `window.addEventListener('error', handleError);\n    const handleAppError = (e: any) => {\n      setHasError(true);\n      setErrorMessage(e.detail?.zusatz?.message || "Ein Fehler ist aufgetreten.");\n    };\n    window.addEventListener('app-error', handleAppError);`
);

content = content.replace(
  `window.removeEventListener('error', handleError);`,
  `window.removeEventListener('error', handleError);\n      window.removeEventListener('app-error', handleAppError as any);`
);

fs.writeFileSync('src/components/GlobalErrorOverlay.tsx', content);
