#!/bin/bash
sed -i "s/import { describe, it, expect, vi, beforeEach } from 'vitest';/import { describe, it, expect, vi, beforeEach } from 'vitest';\nimport '@testing-library\/jest-dom';/g" src/components/LanguageSwitcher.test.tsx
