import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf-8');

const newEndpoint = `
  // ── Epic: Activity Summary Dashboard (Gesendete Kontakte / Verbindungen) ──
  app.get("/api/stats/activity", requireAuth, async (req, res) => {
    try {
      const { uid: meineUid } = (req as any).user || (req as any).auth;
      const db = getFirestore();
      
      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const limitDateStr = sevenDaysAgo.toISOString().split('T')[0];

      // 1. Gesendete Kontakte (fromUid == meineUid, tag >= limitDateStr)
      // Wir holen alle Kontakte der letzten 7 Tage im Speicher und filtern,
      // da fromUid + tag evtl. einen Composite Index bräuchte, den wir nicht garantieren können.
      const contactsSnap = await db.collection("contacts")
        .where("fromUid", "==", meineUid)
        .get();
        
      let contactsSent = 0;
      contactsSnap.forEach(doc => {
        const data = doc.data();
        if (data.tag && data.tag >= limitDateStr) {
          contactsSent++;
        }
      });

      // 2. Erfolgreiche Verbindungen (Chats in denen ich bin, createdAt >= 7 days)
      const chatsSnap = await db.collection("chats")
        .where("participants", "array-contains", meineUid)
        .get();
        
      let connectionsMade = 0;
      chatsSnap.forEach(doc => {
        const data = doc.data();
        // Eine erfolgreiche Verbindung liegt vor, wenn beide das Icebreaker-Gate absolviert haben
        const ansA = data.gateAntwortenA || 0;
        const ansB = data.gateAntwortenB || 0;
        
        // Nutze createdAt als Zeitfenster
        let inTimeframe = true;
        if (data.createdAt) {
          // createdAt ist ein ISO String
          const createdDate = data.createdAt.split('T')[0];
          if (createdDate < limitDateStr) {
            inTimeframe = false;
          }
        }

        if (inTimeframe && ansA >= 2 && ansB >= 2) {
          connectionsMade++;
        }
      });

      return res.json({
        contactsSent,
        connectionsMade
      });
    } catch (error) {
      console.error("Activity Stats Error:", error);
      return res.status(500).json({ error: "Fehler beim Laden der Statistiken." });
    }
  });

`;

const target = 'app.post("/api/messages/send"';
if (code.includes(target)) {
  code = code.replace(target, newEndpoint + target);
  fs.writeFileSync('server.ts', code);
  console.log("Patched server.ts successfully.");
} else {
  console.log("Could not find the target code in server.ts.");
}
