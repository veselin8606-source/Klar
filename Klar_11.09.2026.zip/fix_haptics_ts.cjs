const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = window\.location\.origin;\n/g, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

let haptics = fs.readFileSync('src/lib/haptics.ts', 'utf8');
// Fix ts error
haptics = haptics.replace(/const storedVariant = localStorage\.getItem\('haptic_variant'\);/g, "const storedVariant = localStorage.getItem('haptic_variant') || 'subtle';");
// Fix array map error
haptics = haptics.replace(/if \(Array\.isArray\(finalPattern\)\) \{[\s\S]*?\} else \{/g, `if (Array.isArray(finalPattern)) {\n        finalPattern = (finalPattern as number[]).map((p: number) => Math.max(1, Math.floor(p * multiplier)));\n      } else {`);
fs.writeFileSync('src/lib/haptics.ts', haptics);
console.log("Types fixed");
