import fs from 'fs';

let content = fs.readFileSync('src/components/QuickThemeToggle.tsx', 'utf8');

const tReplace = `
  const umschalten = () => {
    hapticFeedback(HAPTIC_PATTERNS.LIGHT_TAP);
    if (theme === 'light') setTheme('dark');
    else if (theme === 'dark') setTheme('system');
    else setTheme('light');
  };

  return (
    <button
      onClick={umschalten}
      className="relative p-2 w-10 h-10 flex items-center justify-center rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
      aria-label={theme === 'light' ? 'Zu dunklem Aussehen wechseln' : theme === 'dark' ? 'Zu System-Aussehen wechseln' : 'Zu hellem Aussehen wechseln'}
      title={theme === 'light' ? 'Helles Aussehen' : theme === 'dark' ? 'Dunkles Aussehen' : 'System-Aussehen (Auto)'}
    >
      {theme === 'light' && <Moon size={20} />}
      {theme === 'dark' && <div className="text-[10px] font-bold leading-none tracking-tighter uppercase">Sys</div>}
      {theme === 'system' && <Sun size={20} />}
    </button>
  );
`;

content = content.replace(
  /  const umschalten = \(\) => \{[\s\S]*?    <\/button>\n  \);\n/m,
  tReplace + '\n'
);

fs.writeFileSync('src/components/QuickThemeToggle.tsx', content);
