import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  "const db = require('./src/server/db').getDb();",
  "const db = (await import('./src/server/db')).getDb();"
);

code = code.replace(
  "require('firebase-admin/firestore').FieldValue.serverTimestamp()",
  "(await import('firebase-admin/firestore')).FieldValue.serverTimestamp()"
);

code = code.replace(
  "const db = require('firebase-admin').firestore();",
  "const db = (await import('./src/server/db')).getDb();"
);

code = code.replace(
  "require('firebase-admin').firestore.FieldValue.serverTimestamp()",
  "(await import('firebase-admin/firestore')).FieldValue.serverTimestamp()"
);

code = code.replace(
  "const { trackEvent } = require(\"./src/server/analytics\");",
  "const { trackEvent } = await import(\"./src/server/analytics\");"
);

code = code.replace(
  "require('firebase-admin/firestore').getFirestore()",
  "(await import('./src/server/db')).getDb()"
);


fs.writeFileSync('server.ts', code);
