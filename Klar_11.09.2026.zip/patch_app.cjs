const fs = require('fs');
let content = fs.readFileSync('src/App.tsx', 'utf8');

// The instructions require ErrorBoundary
// We have created src/components/GlobalErrorBoundary.tsx
// Let's insert it inside the router so it wraps the app
if (!content.includes('GlobalErrorBoundary')) {
  content = content.replace(
    /import \{ BrowserRouter as Router, Routes, Route, Navigate \} from 'react-router';/,
    "import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router';\nimport { GlobalErrorBoundary } from './components/GlobalErrorBoundary';"
  );
  content = content.replace(
    /<AuthProvider>/,
    "<GlobalErrorBoundary>\n        <AuthProvider>"
  );
  content = content.replace(
    /<\/AuthProvider>/,
    "</AuthProvider>\n        </GlobalErrorBoundary>"
  );
  fs.writeFileSync('src/App.tsx', content);
}

console.log("App patched with GlobalErrorBoundary");
