import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace(/const ChatView: React\.FC = \(\) => \{/, 'export default function ChatView() {');
fs.writeFileSync('src/screens/ChatView.tsx', content);
