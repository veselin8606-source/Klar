import fs from 'fs';

// fix Profile.tsx
let profStr = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!profStr.includes('FeedbackFormWidget')) {
  profStr = "import { FeedbackFormWidget } from '../components/FeedbackFormWidget';\n" + profStr;
  profStr = profStr.replace('<FocusTimeSettingsWidget />', '<FocusTimeSettingsWidget />\n<FeedbackFormWidget />');
  fs.writeFileSync('src/screens/Profile.tsx', profStr);
}

// fix AdminDashboard.tsx 
let adminStr = fs.readFileSync('src/screens/AdminDashboard.tsx', 'utf8');
if (adminStr.includes('BuildInfoWidget') && !adminStr.includes('<BuildInfoWidget />')) {
  adminStr = adminStr.replace(
    '<div className="bg-white dark:bg-stone-900',
    '<BuildInfoWidget /><FailedApiLogWidget /><HiddenDebugHealthCheck /><div className="bg-white dark:bg-stone-900'
  );
  fs.writeFileSync('src/screens/AdminDashboard.tsx', adminStr);
}

// fix Server notification / stripe type errors
let stripe = fs.readFileSync('src/server/stripeService.ts', 'utf8');
stripe = stripe.replace(/userDoc\.id/g, 'userDoc!.id');
stripe = stripe.replace(/userDoc\.email/g, 'userDoc!.email');
stripe = stripe.replace(/'subscription_cancelled'/g, "'subscription_cancelled' as any");
fs.writeFileSync('src/server/stripeService.ts', stripe);

let notif = fs.readFileSync('src/server/notifications.ts', 'utf8');
notif = notif.replace('const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY;', 'const VAPID_PRIVATE = process.env.VAPID_PRIVATE_KEY || "";');
fs.writeFileSync('src/server/notifications.ts', notif);

console.log("Fixed errors");
