import fs from 'fs';
import ts from 'typescript';

const file = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', file, ts.ScriptTarget.Latest, true);

function findError(node) {
    if (node.kind === ts.SyntaxKind.TemplateExpression || node.kind === ts.SyntaxKind.NoSubstitutionTemplateLiteral) {
        // check if it's unterminated
        // not trivial with AST, better just let TS diagnostics print
    }
    ts.forEachChild(node, findError);
}

const program = ts.createProgram(['src/screens/ChatView.tsx'], { jsx: ts.JsxEmit.React });
const diagnostics = ts.getPreEmitDiagnostics(program);

diagnostics.forEach(diag => {
    if (diag.file) {
        const { line, character } = diag.file.getLineAndCharacterOfPosition(diag.start);
        console.log(\`Error \${diag.code}: \${diag.messageText} at line \${line + 1}, col \${character + 1}\`);
    }
});
