import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

if (!content.includes('localStorage.getItem(`klar_draft_${id}`)')) {
  // Add useEffect to load draft
  content = content.replace(/const \[msgText, setMsgText\] = useState\(''\);/, 
`const [msgText, setMsgText] = useState('');

  useEffect(() => {
    if (id) {
      const draft = localStorage.getItem(\`klar_draft_\${id}\`);
      if (draft) setMsgText(draft);
    }
  }, [id]);

  useEffect(() => {
    if (id) {
      if (msgText.trim()) {
        localStorage.setItem(\`klar_draft_\${id}\`, msgText);
      } else {
        localStorage.removeItem(\`klar_draft_\${id}\`);
      }
    }
  }, [msgText, id]);
`);

  // Clear draft on send
  content = content.replace(/setMsgText\(''\);/g, `setMsgText('');\n    localStorage.removeItem(\`klar_draft_\${id}\`);`);
  
  fs.writeFileSync('src/screens/ChatView.tsx', content);
}
