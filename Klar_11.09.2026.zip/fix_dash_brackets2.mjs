import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
content = content.replace(/    return \(\n      \{selectedProfile && <ProfileDetailModal profile=\{selectedProfile\} onClose=\{\(\) => setSelectedProfile\(null\)\} \/>\}\n\)/g, "    return ()");
fs.writeFileSync('src/screens/Dashboard.tsx', content);
