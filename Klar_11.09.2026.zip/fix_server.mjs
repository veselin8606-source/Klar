import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');
content = content.replace('import { translateText } from "./src/server/translationService";', '');
content = content.replace('const receiverId = participants.find((uid) => uid !== senderId) || senderId;', 'const receiverId = participants.find((uid: string) => uid !== senderId) || senderId;');
content = content.replace('const data = await response.json();', 'const data = (await response.json()) as any;');
content = content.replace('const messageData = {', 'const messageData: any = {');
fs.writeFileSync('server.ts', content, 'utf8');
