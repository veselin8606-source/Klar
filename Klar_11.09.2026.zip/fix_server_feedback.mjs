import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');
code = code.replace(
  "app.post('/api/report', requireAuth,",
  `app.post('/api/feedback', requireAuth, (req, res) => { res.json({ status: 'ok' }); });\n  app.post('/api/report', requireAuth,`
);
fs.writeFileSync('server.ts', code);
