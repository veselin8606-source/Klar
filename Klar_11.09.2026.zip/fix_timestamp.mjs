import fs from 'fs';
let code = fs.readFileSync('src/components/MessageBubble.tsx', 'utf8');

const tsLogic = `
  const original = msg.originalText || msg.text;
  const hasTranslation = !!msg.textTranslated;
  const [showOriginal, setShowOriginal] = useState(false);
  const displayString = (hasTranslation && !showOriginal) ? msg.textTranslated : original;

  let timeString = '';
  if (msg.timestamp) {
    const d = new Date(msg.timestamp);
    const today = new Date();
    if (d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()) {
      timeString = d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } else {
      timeString = d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
  }
`;

code = code.replace(
  `  // Use textOriginal if available, fallback to legacy text
  const original = msg.originalText || msg.text;
  
  // Is this message translated by the backend?
  const hasTranslation = !!msg.textTranslated;
  
  // Zustand A (übersetzt) / Zustand B (Original)
  const [showOriginal, setShowOriginal] = useState(false);
  const displayString = (hasTranslation && !showOriginal) ? msg.textTranslated : original;`,
  tsLogic
);

code = code.replace(
  `      {isUser && (
        <div className="flex justify-end mt-1">
          <CheckCheck size={14} className={msg.isRead ? "text-blue-500" : "text-brand-light/70 dark:text-brand/50"} />
        </div>
      )}`,
  `      <div className="flex justify-end items-center mt-1 gap-1">
        <span className="text-[10px] opacity-70">{timeString}</span>
        {isUser && <CheckCheck size={12} className={msg.isRead ? "text-blue-500" : "text-brand-light/70 dark:text-brand/50"} />}
      </div>`
);

fs.writeFileSync('src/components/MessageBubble.tsx', code);
console.log("Timestamp logic added");
