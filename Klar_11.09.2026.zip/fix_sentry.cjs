const fs = require('fs');

let main = fs.readFileSync('src/main.tsx', 'utf8');

// I accidentally duplicated Sentry initialization because I didn't see it was already there. 
// The existing init was carefully constructed with `sendDefaultPii: false` and GDPR rules.
// My patched version was added at the top. Let's remove the one I added.
main = main.replace(/Sentry\.init\(\{\n  dsn: import\.meta\.env\.VITE_SENTRY_DSN \|\| "https:\/\/examplePublicKey@o0\.ingest\.sentry\.io\/0",\n  integrations: \[\n    Sentry\.browserTracingIntegration\(\),\n    Sentry\.replayIntegration\(\),\n  \],\n  tracesSampleRate: 1\.0,\n  replaysSessionSampleRate: 0\.1,\n  replaysOnErrorSampleRate: 1\.0,\n\}\);\n\ncreateRoot\(document\.getElementById\('root'\)!\)\.render\(/, "createRoot(document.getElementById('root')!).render(");

fs.writeFileSync('src/main.tsx', main);
console.log("Restored original Sentry init");
