import fs from 'fs';

let content = fs.readFileSync('src/screens/Profile.tsx', 'utf8');

const privacyCard = `
            {/* Privacy Visibility Settings */}
            <div className="mt-6">
              <h4 className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-3 flex items-center gap-2">
                <ShieldCheck size={18} className="text-stone-500" />
                Datenschutz & Sichtbarkeit
              </h4>
              <div className="bg-stone-50 dark:bg-stone-800/50 rounded-xl p-4 border border-stone-200 dark:border-stone-700">
                <p className="text-xs text-stone-500 mb-4">Lege fest, welche Profilinformationen für andere Nutzer sichtbar sind.</p>
                <div className="space-y-3">
                  {[
                    { id: 'showAge', label: 'Alter anzeigen' },
                    { id: 'showLocation', label: 'Standort anzeigen' },
                    { id: 'showInterests', label: 'Interessen anzeigen' },
                    { id: 'showBio', label: 'Bio anzeigen' }
                  ].map(setting => {
                    const isChecked = profileData?.visibilitySettings?.[setting.id] ?? true;
                    return (
                      <div key={setting.id} className="flex items-center justify-between">
                        <span className="text-sm text-stone-700 dark:text-stone-300">{setting.label}</span>
                        <button
                          onClick={() => {
                            const newSettings = { ...profileData?.visibilitySettings, [setting.id]: !isChecked };
                            updateProfileData({ visibilitySettings: newSettings }).catch(console.error);
                          }}
                          className={\`w-10 h-6 rounded-full transition-colors relative \${isChecked ? 'bg-brand dark:bg-brand-light' : 'bg-stone-300 dark:bg-stone-600'}\`}
                        >
                          <span className={\`absolute top-1 left-1 w-4 h-4 rounded-full bg-white transition-transform \${isChecked ? 'translate-x-4' : ''}\`} />
                        </button>
                      </div>
                    );
                  })}
                </div>
              </div>
            </div>
`;

content = content.replace(
  '<h4 className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-3 flex items-center gap-2">',
  privacyCard + '\n            <h4 className="text-sm font-medium text-stone-700 dark:text-stone-300 mb-3 flex items-center gap-2">'
);

fs.writeFileSync('src/screens/Profile.tsx', content);
