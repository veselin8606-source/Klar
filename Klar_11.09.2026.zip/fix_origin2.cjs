const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
// Replace the block setting origin
profile = profile.replace(/let origin = \{ y: 0\.6, x: 0\.5 \};\n\s*if \(buttonRef\.current\) \{\n\s*const rect = buttonRef\.current\.getBoundingClientRect\(\);\n\s*origin = \{\n\s*x: \(rect\.left \+ rect\.width \/ 2\) \/ window\.innerWidth,\n\s*y: \(rect\.top \+ rect\.height \/ 2\) \/ window\.innerHeight\n\s*\};\n\s*\}/g, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

console.log("Fixed unused origin block");
