import fs from 'fs';
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf-8');

if (!code.includes('Languages')) {
  code = code.replace('Settings, Download', 'Settings, Download, Languages');
}

// Add profileData to useAuth call
const authTarget = 'const { logOut, updateProfileData } = useAuth();';
const authReplacement = 'const { logOut, updateProfileData, profileData } = useAuth();';

if (code.includes(authTarget)) {
  code = code.replace(authTarget, authReplacement);
  console.log("Patched profileData");
}

fs.writeFileSync('src/screens/Profile.tsx', code);
console.log("Patched Profile.tsx imports.");
