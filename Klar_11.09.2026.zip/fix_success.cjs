const fs = require('fs');

let successContent = fs.readFileSync('src/components/SuccessDashboardWidget.tsx', 'utf8');
successContent = successContent.replace(/if \(!isInitialLoad && prevDateCount\.current !== null && displayDates > prevDateCount\.current\) \{\n\s*\}\);\n/g, 'if (!isInitialLoad && prevDateCount.current !== null && displayDates > prevDateCount.current) {\n');
fs.writeFileSync('src/components/SuccessDashboardWidget.tsx', successContent);

console.log("SuccessDashboard fixed.");
