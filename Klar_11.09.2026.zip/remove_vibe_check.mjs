import fs from 'fs';
let code = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

code = code.replace(/import \{ MoodDiaryReminder \} from "\.\.\/components\/MoodDiaryReminder";\n/, '');
code = code.replace(/import \{ DailyVibeCheckWidget \} from "\.\.\/components\/DailyVibeCheckWidget";\n/, '');

code = code.replace(/      <MoodDiaryReminder \/>\n/, '');

code = code.replace(
`        <div className="min-w-[85%] max-w-md snap-center shrink-0 empty:hidden">
          <DailyVibeCheckWidget />
        </div>\n`, '');

fs.writeFileSync('src/screens/Dashboard.tsx', code);
console.log('Removed widgets');
