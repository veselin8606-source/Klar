import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

// Wait... in the first replace, we didn't add the `</>` fragment correctly at the end. 
content = content.replace(/              <\/div>\n            <\/motion\.div>\n              \)\}\n      <\/AnimatePresence>/g, 
  "              </div>\n            </motion.div>\n            </>\n          )}\n      </AnimatePresence>");

content = content.replace(/\{smartKontaktDetailProfile && \(\n                  <motion\.div /g, "{smartKontaktDetailProfile && (\n          <>\n          <motion.div ");

fs.writeFileSync('src/screens/Dashboard.tsx', content);
