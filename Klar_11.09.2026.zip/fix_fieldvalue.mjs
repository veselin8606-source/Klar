import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/\(await import\('firebase-admin\/firestore'\)\)\.FieldValue\.serverTimestamp\(\)/g, 'FieldValue.serverTimestamp()');

fs.writeFileSync('server.ts', content);
