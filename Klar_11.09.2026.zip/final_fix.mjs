import fs from 'fs';

// App.tsx
let app = fs.readFileSync('src/App.tsx', 'utf8');
if (!app.includes('import { useNavigate }')) {
  app = app.replace('import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router";', 'import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from "react-router";');
  app = app.replace('import { Route, Routes, Navigate, useNavigate } from "react-router";', 'import { Route, Routes, Navigate, useNavigate } from "react-router";'); // dedupe if needed
}
fs.writeFileSync('src/App.tsx', app);

// Profile.tsx
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!prof.match(/<ProfileFeedback \/>/)) {
  prof = prof.replace(
    /<\/main>\n\s*<\/div>\n\s*\);\n\}/,
    '  <ProfileFeedback />\n      </main>\n    </div>\n  );\n}'
  );
}
fs.writeFileSync('src/screens/Profile.tsx', prof);

// Tips.tsx
let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
tips = tips.replace(/<h3 className="font-serif text-xl md:text-2xl text-brand dark:text-brand-light mb-2">\{p.title\}<\/h3>/g, 
  `<div className="flex justify-between items-start mb-2">
     <h3 className="font-serif text-xl md:text-2xl text-brand dark:text-brand-light">{p.title}</h3>
     <button onClick={() => toggleFavorite(p.id)} className="text-stone-400 hover:text-amber-500 transition-colors">
       <Star size={24} className={favorites.includes(p.id) ? "fill-amber-500 text-amber-500" : ""} />
     </button>
   </div>`
);
fs.writeFileSync('src/screens/Tips.tsx', tips);

