import fs from 'fs';
let code = fs.readFileSync('src/components/ConsistencyStreakWidget.tsx', 'utf8');

code = code.replace(
  `Urlaub ({vacationDaysLeft}T)`,
  `<Coffee size={12} className="inline mr-1" /> Pausiert ({vacationDaysLeft}T)`
);

fs.writeFileSync('src/components/ConsistencyStreakWidget.tsx', code);
console.log("Done");
