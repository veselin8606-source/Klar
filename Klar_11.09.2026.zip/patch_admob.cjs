const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  app.post("/api/subscribe-klar-plus", (_req, res) => {`;

const replace = `  // ── TASK 1.2: AdMob SSV Callback ──────────────────────────────────────────
  // Der Callback verifiziert den Nutzer und schreibt die Extra-Kontakte in den Ledger.
  app.get("/api/ads/callback", async (req, res) => {
    try {
      const { user_id, reward_amount, reward_item, transaction_id, signature, key_id } = req.query;
      
      if (!user_id || !transaction_id || !signature || !key_id) {
        return res.status(400).send('Missing parameters');
      }

      // HIER FINDET DIE VERIFIKATION STATT:
      // 1. Hole Googles public keys via https://gstatic.com/admob/reward/verifier-keys.json
      // 2. Suche den Key passend zu \`key_id\`
      // 3. Verifiziere \`signature\` via ECDSA-SHA-256 über den restlichen Query-String.
      // (Wir simulieren dies für das Startup Launch Pad als erfolgreich, da wir noch keinen echten AdMob Account haben, 
      // aber die Architektur steht).
      const isValid = true; 

      if (!isValid) {
        return res.status(403).send('Invalid signature');
      }

      const db = require('firebase-admin').firestore();
      
      // Idempotenz prüfen
      const ledgerRef = db.collection('users').doc(user_id).collection('quota_ledger').doc(transaction_id);
      
      await db.runTransaction(async (t) => {
        const docSnap = await t.get(ledgerRef);
        if (docSnap.exists) {
          // Bereits verarbeitet
          return;
        }
        
        // Transaktion erfassen
        t.set(ledgerRef, {
          type: 'grant',
          amount: parseInt(reward_amount || '3', 10),
          reason: 'admob_reward',
          transaction_id: transaction_id,
          timestamp: require('firebase-admin').firestore.FieldValue.serverTimestamp()
        });
      });

      // Google erwartet HTTP 200 OK als Bestätigung
      res.status(200).send('OK');
    } catch (error) {
      console.error('/api/ads/callback', error);
      res.status(500).send('Internal Server Error');
    }
  });

  app.post("/api/subscribe-klar-plus", (_req, res) => {`;

code = code.replace(target, replace);
fs.writeFileSync('server.ts', code);
