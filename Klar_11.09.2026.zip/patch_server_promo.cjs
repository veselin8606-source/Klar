const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  app.post("/api/einwilligung", handleEinwilligung);`;

const replace = `  app.post("/api/einwilligung", handleEinwilligung);

  app.post("/api/claim-launch-promo", express.json(), async (req, res) => {
    try {
      const { userId } = req.body;
      if (!userId) return res.status(400).send("Missing userId");

      const db = require('firebase-admin/firestore').getFirestore();
      const promoRef = db.collection('system').doc('launch_promo');
      const userRef = db.collection('users').doc(userId);

      const result = await db.runTransaction(async (t) => {
        const userSnap = await t.get(userRef);
        if (!userSnap.exists) throw new Error("User not found");
        
        const userData = userSnap.data();
        if (userData.launchPromoClaimed || userData.launchPromoMissed) {
           return { status: 'already_claimed' };
        }

        const promoSnap = await t.get(promoRef);
        let claimedCount = 0;
        if (promoSnap.exists) {
          claimedCount = promoSnap.data().claimedCount || 0;
        }

        if (claimedCount >= 100) {
          t.update(userRef, { launchPromoMissed: true });
          return { status: 'missed' };
        }

        const isTop10 = claimedCount < 10;
        const monthsFree = isTop10 ? 3 : 1;
        
        // Let's grant the user 'plus' status.
        t.set(promoRef, { claimedCount: claimedCount + 1 }, { merge: true });
        t.update(userRef, {
          plan: 'plus',
          launchPromoClaimed: true,
          launchPromoMonths: monthsFree,
          launchPromoAt: require('firebase-admin/firestore').FieldValue.serverTimestamp()
        });

        return { status: 'success', months: monthsFree, count: claimedCount + 1 };
      });

      res.json(result);
    } catch (e) {
      console.error('Promo error:', e);
      res.status(500).json({ error: "Fehler beim Einlösen" });
    }
  });`;

if (!code.includes('/api/claim-launch-promo')) {
  code = code.replace(target, replace);
  fs.writeFileSync('server.ts', code);
}
