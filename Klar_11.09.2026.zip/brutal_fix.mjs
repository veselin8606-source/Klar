import fs from 'fs';

// 1. App.tsx
let app = fs.readFileSync('src/App.tsx', 'utf8');
if (!app.includes('import { useNavigate }')) {
    app = 'import { useNavigate } from "react-router";\n' + app;
}
fs.writeFileSync('src/App.tsx', app);

// 2. Profile.tsx
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
prof = prof.replace(/function ProfileFeedback\(\) \{/, 'export function ProfileFeedback() {');
prof = prof.replace('import { ChevronRight } from "lucide-react";', 'import { ChevronRight, Heart, MessageSquare, Star } from "lucide-react";');
if (!prof.includes('MessageSquare')) {
    prof = 'import { Heart, MessageSquare, Star } from "lucide-react";\n' + prof;
}
// Force use ProfileFeedback
if (!prof.includes('<ProfileFeedback />')) {
  prof = prof.replace(/<\/main>/, '  <ProfileFeedback />\n      </main>');
}
fs.writeFileSync('src/screens/Profile.tsx', prof);

// 3. Tips.tsx
let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
if (!tips.includes('Star } from "lucide-react"')) {
    tips = 'import { Star } from "lucide-react";\n' + tips;
}
fs.writeFileSync('src/screens/Tips.tsx', tips);
