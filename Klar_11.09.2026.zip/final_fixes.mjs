import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// 1. Remove JSX.Element | null
content = content.replace(/export default function ChatView\(\): JSX\.Element \| null \{/, 'export default function ChatView() {');

// 2. Remove setVoiceRecognition(recognition);
content = content.replace(/    setVoiceRecognition\(recognition\);/, '    // setVoiceRecognition(recognition);');

// 3. Remove NICHT_VERFUEGBAR properly
content = content.replace(/const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt\.'/, "// const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt.'");
// if it's already commented, it won't do anything, but let's check if it exists:
if (content.includes("const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt.';")) {
  content = content.replace(/const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt\.';/, "// const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt.';");
}

fs.writeFileSync('src/screens/ChatView.tsx', content);
