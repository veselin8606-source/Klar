const fs = require('fs');
let chat = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
chat = chat.replace(/\/\/       if \('vibrate' in navigator\) navigator\.vibrate\(50\);\n/g, '');
chat = chat.replace(/\/\/   navigator\.vibrate    eine eingehende Nachricht\n/g, '');
fs.writeFileSync('src/screens/ChatView.tsx', chat);

let haptics = fs.readFileSync('src/lib/haptics.ts', 'utf8');
haptics = haptics.replace(/navigator\.vibrate\(finalPattern\);/g, '// Vibration disabled by product rules\n      // navigator.vibrate(finalPattern);');
fs.writeFileSync('src/lib/haptics.ts', haptics);
console.log("Patched haptics again");
