import fs from 'fs';

let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const disclaimer = `
        {/* DSGVO & KI Hinweis */}
        <div className="flex justify-center mb-6 mt-4">
          <div className="bg-stone-100/50 dark:bg-stone-900/50 rounded-xl px-4 py-2.5 max-w-sm text-center border border-stone-200/50 dark:border-stone-800/50">
            <div className="flex items-center justify-center gap-1.5 text-stone-500 mb-1">
              <Languages size={12} />
              <span className="text-[10px] font-semibold uppercase tracking-wider">Live-Übersetzung aktiv</span>
            </div>
            <p className="text-[11px] text-stone-500 leading-tight">
              Eingehende Nachrichten können zur maschinellen Übersetzung über europäische Server von Google (Gemini) verarbeitet werden. Es erfolgt kein Modell-Training. Mehr dazu in der <a href="#" className="underline hover:text-stone-700 dark:hover:text-stone-300">Datenschutzerklärung</a>.
            </p>
          </div>
        </div>

        {messages.map((msg, idx) => (`;

content = content.replace(
  "{messages.map((msg, idx) => (",
  disclaimer
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
