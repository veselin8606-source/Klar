import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace("sourceLang?: string;", "sourceLang?: string;\n  sourceLanguage?: string;");
fs.writeFileSync('src/screens/ChatView.tsx', content, 'utf8');
