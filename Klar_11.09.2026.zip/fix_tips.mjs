import fs from 'fs';
let code = fs.readFileSync('src/screens/Tips.tsx', 'utf8');

if (!code.includes('import { Star')) {
  code = code.replace('import { Bookmark, BookmarkCheck }', 'import { Bookmark, BookmarkCheck, Star }');
}

const favLogic = `
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('klar_tips_favorites') || '[]');
    } catch {
      return [];
    }
  });

  const toggleFavorite = (id: string) => {
    setFavorites(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id];
      localStorage.setItem('klar_tips_favorites', JSON.stringify(next));
      return next;
    });
  };
`;

code = code.replace(/const principles = \[/, favLogic + '\n  const principles = [');

code = code.replace(
  /<h4 className="font-medium text-lg text-stone-900 dark:text-stone-100 mb-2">\{p.title\}<\/h4>/g,
  `<div className="flex justify-between items-start mb-2">
     <h4 className="font-medium text-lg text-stone-900 dark:text-stone-100">{p.title}</h4>
     <button onClick={() => toggleFavorite(p.id)} className="text-stone-400 hover:text-amber-500 transition-colors">
       <Star size={20} className={favorites.includes(p.id) ? "fill-amber-500 text-amber-500" : ""} />
     </button>
   </div>`
);

fs.writeFileSync('src/screens/Tips.tsx', code);
