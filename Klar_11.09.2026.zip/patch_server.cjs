const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `    keyGenerator: (req) => {
      // IPv4/IPv6-sichere IP-Extraktion
      return req.headers['x-forwarded-for']?.toString().split(',')[0].trim() || req.ip || 'unknown';
    }`;

const replace = `    validate: { xForwardedForHeader: false }, // Vermeidet ERR_ERL_KEY_GEN_IPV6 bei eigenen IP-Extraktionen
    keyGenerator: (req) => {
      return req.headers['x-forwarded-for']?.toString().split(',')[0].trim() || req.ip || 'unknown';
    }`;

code = code.replace(target, replace);
fs.writeFileSync('server.ts', code);
