const fs = require('fs');
let code = fs.readFileSync('src/screens/Dashboard.tsx', 'utf-8');

const importTarget = `import { useUsageAnalytics } from "../lib/useUsageAnalytics";`;
const importReplace = `import { useUsageAnalytics } from "../lib/useUsageAnalytics";\nimport LaunchPromoWidget from "../components/LaunchPromoWidget";`;
if (!code.includes('import LaunchPromoWidget')) {
  code = code.replace(importTarget, importReplace);
  fs.writeFileSync('src/screens/Dashboard.tsx', code);
}
