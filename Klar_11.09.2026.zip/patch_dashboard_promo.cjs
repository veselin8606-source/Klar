const fs = require('fs');
let code = fs.readFileSync('src/screens/Dashboard.tsx', 'utf-8');

const importTarget = `import { useUsageAnalytics } from "../lib/analytics";`;
const importReplace = `import { useUsageAnalytics } from "../lib/analytics";\nimport LaunchPromoWidget from "../components/LaunchPromoWidget";`;
code = code.replace(importTarget, importReplace);

const renderTarget = `      <AppTour />`;
const renderReplace = `      <LaunchPromoWidget />\n      <AppTour />`;
code = code.replace(renderTarget, renderReplace);

fs.writeFileSync('src/screens/Dashboard.tsx', code);
