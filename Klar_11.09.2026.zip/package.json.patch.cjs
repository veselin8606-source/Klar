const fs = require('fs');
let pkg = JSON.parse(fs.readFileSync('package.json', 'utf8'));
pkg.scripts['check:guardrails'] = 'node scripts/check-guardrails.mjs';
pkg.scripts['verify'] = pkg.scripts['verify'].replace('npm run check:kontrast', 'npm run check:guardrails && npm run check:kontrast');
fs.writeFileSync('package.json', JSON.stringify(pkg, null, 2));
