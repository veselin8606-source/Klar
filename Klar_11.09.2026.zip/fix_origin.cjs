const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = [^\n]*\n/, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

console.log("Fixed unused origin");
