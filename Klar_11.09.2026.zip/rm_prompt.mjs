import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

content = content.replace(
  /        <div className="min-w-\[85%\] max-w-md snap-center shrink-0 empty:hidden">\n          <DailyPromptWidget \/>\n        <\/div>\n/g,
  ""
);

content = content.replace(
  /import \{ DailyPromptWidget \} from "\.\.\/components\/DailyPromptWidget";\n/g,
  ""
);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
