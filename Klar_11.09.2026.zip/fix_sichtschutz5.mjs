import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');

// I am just going to rewrite the file completely to be absolutely sure.
const fullCode = `import React, { useEffect, useState, useRef } from 'react';
import { Eye, EyeOff } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

export const SICHTSCHUTZ_EIN = 'klar:sichtschutz';

export function aktiviereSichtschutz(): void {
  window.dispatchEvent(new Event(SICHTSCHUTZ_EIN));
}

export function SichtschutzKnopf() {
  const [menuOpen, setMenuOpen] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = () => {
    pressTimer.current = setTimeout(() => {
      setMenuOpen(true);
    }, 500);
  };

  const cancelPress = () => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
  };

  const handlePause = () => {
    localStorage.setItem('sichtschutz_paused_until', String(Date.now() + 5 * 60 * 1000));
    setMenuOpen(false);
  };

  return (
    <div className="relative">
      <button
        onPointerDown={startPress}
        onPointerUp={cancelPress}
        onPointerLeave={cancelPress}
        onClick={() => {
          if (!menuOpen) aktiviereSichtschutz();
        }}
        className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
        aria-label="Bildschirm verdecken"
        title="Bildschirm verdecken"
      >
        <EyeOff size={20} />
      </button>

      <AnimatePresence>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-stone-900 rounded-xl shadow-lg border border-stone-200 dark:border-stone-800 z-50 overflow-hidden"
            >
              <button
                onClick={handlePause}
                className="w-full text-left px-4 py-3 text-sm text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                Für 5 Minuten pausieren
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}

export function Sichtschutz() {
  const [aktiv, setAktiv] = useState(false);
  const istPausiert = () => {
    const pausedUntil = localStorage.getItem('sichtschutz_paused_until');
    if (!pausedUntil) return false;
    if (Date.now() < parseInt(pausedUntil, 10)) return true;
    localStorage.removeItem('sichtschutz_paused_until');
    return false;
  };

  const entsperrenRef = useRef<HTMLButtonElement | null>(null);

  useEffect(() => {
    const ein = () => { if (!istPausiert()) setAktiv(true); };

    const beiSichtwechsel = () => {
      if (document.visibilityState === 'hidden' && !istPausiert()) setAktiv(true);
    };

    window.addEventListener(SICHTSCHUTZ_EIN, ein);
    document.addEventListener('visibilitychange', beiSichtwechsel);
    return () => {
      window.removeEventListener(SICHTSCHUTZ_EIN, ein);
      document.removeEventListener('visibilitychange', beiSichtwechsel);
    };
  }, []);

  useEffect(() => {
    if (aktiv) entsperrenRef.current?.focus();
  }, [aktiv]);

  if (!aktiv) return null;

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-label="Bildschirm verdeckt"
      className="fixed inset-0 z-[300] bg-stone-900 flex flex-col items-center justify-center p-8 text-center"
    >
      <div className="w-16 h-16 rounded-full bg-stone-800 flex items-center justify-center mb-5">
        <EyeOff size={28} className="text-stone-300" />
      </div>

      <h2 className="text-xl font-serif text-white mb-2">Bildschirm verdeckt</h2>

      <p className="text-sm text-stone-300 max-w-xs mb-1">
        Niemand sieht, was du gerade liest.
      </p>
      <p className="text-xs text-stone-400 max-w-xs mb-8">
        Ein Tipp genügt zum Aufdecken — das schützt vor fremden Blicken,
        nicht vor jemandem, der dein entsperrtes Gerät in der Hand hat.
      </p>

      <button
        ref={entsperrenRef}
        onClick={() => setAktiv(false)}
        className="px-8 py-3 bg-brand text-white rounded-full font-medium shadow-lg flex items-center gap-2"
      >
        <Eye size={18} /> Wieder anzeigen
      </button>
    </div>
  );
}
`;

fs.writeFileSync('src/components/Sichtschutz.tsx', fullCode);
