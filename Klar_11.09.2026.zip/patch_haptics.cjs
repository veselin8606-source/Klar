const fs = require('fs');
let content = fs.readFileSync('src/lib/haptics.ts', 'utf8');

// The product concept strictly says: "Keine Bewegung über 200 ms. Kein Konfetti, kein Klang, keine Vibration."
// So we completely disable haptic feedback to enforce this rule.
content = content.replace(
  /if \(typeof window !== 'undefined' && 'vibrate' in navigator\) \{/g,
  `if (false && typeof window !== 'undefined' && 'vibrate' in navigator) {`
);

fs.writeFileSync('src/lib/haptics.ts', content);
console.log("Haptics disabled.");
