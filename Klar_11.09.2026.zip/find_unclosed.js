const fs = require('fs');
const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const stack = [];
const lines = code.split('\n');

for (let i = 0; i < lines.length; i++) {
  const line = lines[i].replace(/\/\/.*$/, ''); // ignore comments
  for (let j = 0; j < line.length; j++) {
    if (line[j] === '{') {
      stack.push({ line: i + 1, col: j + 1 });
    } else if (line[j] === '}') {
      stack.pop();
    }
  }
}

console.log("Unclosed braces:");
for (const b of stack) {
  console.log(`Line ${b.line}, Col ${b.col}`);
}
