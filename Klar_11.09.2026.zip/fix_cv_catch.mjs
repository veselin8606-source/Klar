import fs from 'fs';
let cv = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
cv = cv.replace(/console\.warn\('Gate status error:', e\);/g, `console.warn('Gate status error');`);
fs.writeFileSync('src/screens/ChatView.tsx', cv);
