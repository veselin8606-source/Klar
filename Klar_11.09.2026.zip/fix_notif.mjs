import fs from 'fs';
let code = fs.readFileSync('src/server/notifications.ts', 'utf8');
code = code.replace(
  'failedTokens.push(tokens[idx]);',
  'if (tokens[idx]) failedTokens.push(tokens[idx] as string);'
);
fs.writeFileSync('src/server/notifications.ts', code);
console.log('Fixed notifications');
