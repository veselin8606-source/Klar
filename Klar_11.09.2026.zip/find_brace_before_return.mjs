import fs from 'fs';
const content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const lines = content.split('\n');
let balance = 0;
for (let i = 0; i < 1126; i++) {
  const line = lines[i];
  for (let j = 0; j < line.length; j++) {
    if (line[j] === '{') balance++;
    if (line[j] === '}') balance--;
  }
}
console.log('Balance before return:', balance);
