const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

server = server.replace(/const transcription = result\.text;/g, 'const transcription = result.text || "";');

fs.writeFileSync('server.ts', server);
console.log("Fixed transcription type");
