const fs = require("fs");
let content = fs.readFileSync("server.ts", "utf8");

const routes = `
  app.post("/api/gemini/dating-readiness", async (req, res) => {
    try {
      const { goals, recentActivity } = req.body;
      if (!process.env.GEMINI_API_KEY) {
        return res.status(503).json({ error: "KI nicht verfügbar" });
      }
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const antwort = await beantworte("/api/gemini/dating-readiness", () => ai.models.generateContent({
        model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
        contents: [{ role: "user", parts: [{ text: \`Goals: \${goals}\nRecent Activity: \${recentActivity}\` }] }],
        config: {
          systemInstruction: "You are a dating coach. Provide a daily wisdom and actionable advice based on the user's goals and recent activity.",
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              wisdom: { type: "string", description: "A short inspiring dating wisdom for the day" },
              actionableAdvice: { type: "string", description: "One practical actionable advice" }
            }
          }
        }
      }));
      res.status(antwort.status).json(antwort.koerper);
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Internal error" });
    }
  });

  app.post("/api/gemini/daily-coach-insight", async (req, res) => {
    try {
      const { userGoals, recentActivity } = req.body;
      if (!process.env.GEMINI_API_KEY) {
        return res.status(503).json({ error: "KI nicht verfügbar" });
      }
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const antwort = await beantworte("/api/gemini/daily-coach-insight", () => ai.models.generateContent({
        model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
        contents: [{ role: "user", parts: [{ text: \`Goals: \${userGoals}\nRecent Activity: \${recentActivity}\` }] }],
        config: {
          systemInstruction: "You are a dating coach. Provide a short, actionable daily insight for the user.",
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              insight: { type: "string", description: "A 1-2 sentence tip tailored to the user's situation" }
            }
          }
        }
      }));
      res.status(antwort.status).json(antwort.koerper);
    } catch (e) {
      console.error(e);
      res.status(500).json({ error: "Internal error" });
    }
  });
`;

content = content.replace('  app.post("/api/messages/mark-read"', routes + '\n  app.post("/api/messages/mark-read"');
fs.writeFileSync("server.ts", content);
