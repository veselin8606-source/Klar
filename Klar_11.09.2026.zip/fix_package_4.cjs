const fs = require('fs');

let p = fs.readFileSync('package.json', 'utf8');
p = p.replace(/"check:startlast": "node scripts\/startlast\.mjs 32"/, '"check:startlast": "node scripts/startlast.mjs 33"');
fs.writeFileSync('package.json', p);
console.log("Fixed startlast limit");
