import fs from 'fs';
let content = fs.readFileSync('src/lib/AuthContext.tsx', 'utf8');

// 1. Add imports
content = content.replace(
  'signInAnonymously, GoogleAuthProvider, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword',
  'signInAnonymously, GoogleAuthProvider, signOut, signInWithEmailAndPassword, createUserWithEmailAndPassword, setPersistence, browserLocalPersistence'
);

// 2. Auth loop check
const loopCheck = `  useEffect(() => {
    // Auth redirect loop prevention check
    const currentUrl = new URL(window.location.href);
    const hasRedirectResult = currentUrl.hash.includes('firebase_auth');
    if (hasRedirectResult) {
      console.log('Detected auth redirect loop return', currentUrl.href);
      if (!currentUrl.href.startsWith(window.location.origin)) {
        console.error('Auth loop trigger: mismatch origin', window.location.origin, currentUrl.href);
      }
    }
  }, []);
`;
content = content.replace('  useEffect(() => {\n    const unsubscribe = onAuthStateChanged', loopCheck + '  useEffect(() => {\n    const unsubscribe = onAuthStateChanged');

// 3. setPersistence
const oldSignIn = `  const signInWithGoogle = async () => {
    // KEIN \`provider.addScope(...)\`. Die Anmeldung fragt nur, was sie zum
    // Anmelden braucht. Siehe den Block am Anfang dieser Datei.
    const provider = new GoogleAuthProvider();
    try {
      await signInWithPopup(auth, provider);
      return;
    }`;
const newSignIn = `  const signInWithGoogle = async () => {
    // KEIN \`provider.addScope(...)\`. Die Anmeldung fragt nur, was sie zum
    // Anmelden braucht. Siehe den Block am Anfang dieser Datei.
    const provider = new GoogleAuthProvider();
    try {
      await setPersistence(auth, browserLocalPersistence);
      await signInWithPopup(auth, provider);
      return;
    }`;
content = content.replace(oldSignIn, newSignIn);

fs.writeFileSync('src/lib/AuthContext.tsx', content);
