import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');

const regex = /      transition=\{\{ duration: 0\.1 \}\}[\s\S]*?\n\}\n/;
content = content.replace(regex, "");

fs.writeFileSync('src/components/Sichtschutz.tsx', content);
