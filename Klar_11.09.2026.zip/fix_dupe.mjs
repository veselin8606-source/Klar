import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const oldRegex = /      reader\.readAsDataURL\(blob\);\n    } catch \(e\) \{\n      console\.error\('Audio send error', e\);\n    \} finally \{\n      setIsProcessingAudio\(false\);\n    \}\n  \};\n\n\n\n  \n\n  \n      reader\.readAsDataURL\(blob\);\n    \} catch \(e\) \{\n      console\.error\('Audio send error', e\);\n    \} finally \{\n      setIsProcessingAudio\(false\);\n    \}\n  \};/;

content = content.replace(oldRegex, 
  "      reader.readAsDataURL(blob);\n    } catch (e) {\n      console.error('Audio send error', e);\n    } finally {\n      setIsProcessingAudio(false);\n    }\n  };"
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
