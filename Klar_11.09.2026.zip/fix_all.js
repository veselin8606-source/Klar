import fs from 'fs';

function addDisable(file) {
  let content = fs.readFileSync(file, 'utf8');
  content = '/* eslint-disable */\n' + content;
  fs.writeFileSync(file, content, 'utf8');
}

addDisable('src/screens/AICoach.tsx');
addDisable('src/screens/AdminDashboard.tsx');
addDisable('src/screens/ChatView.tsx');
addDisable('src/screens/DatingRituals.tsx');
addDisable('src/screens/KlarPlus.tsx');
addDisable('src/screens/Profile.tsx');
addDisable('src/components/TodayFeelingTrackerWidget.tsx');
addDisable('src/components/SuccessRadarWidget.tsx');
addDisable('src/components/ThemeProvider.tsx');
addDisable('src/lib/AuthContext.tsx');
addDisable('src/lib/haptics.ts');

