const fs = require('fs');
let content = fs.readFileSync('src/lib/haptics.ts', 'utf8');

// The typescript error is about map. Let's fix that map explicit type
content = content.replace(/finalPattern\.map\(p => Math\.max/g, 'finalPattern.map((p: number) => Math.max');

fs.writeFileSync('src/lib/haptics.ts', content);
