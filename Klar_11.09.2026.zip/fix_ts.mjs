import fs from 'fs';

let profStr = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!profStr.includes('import { FeedbackFormWidget }')) {
  profStr = "import { FeedbackFormWidget } from '../components/FeedbackFormWidget';\n" + profStr;
  fs.writeFileSync('src/screens/Profile.tsx', profStr);
}

let fbWidget = fs.readFileSync('src/components/FeedbackFormWidget.tsx', 'utf8');
fbWidget = fbWidget.replace("import React, { useState }", "import { useState }");
fs.writeFileSync('src/components/FeedbackFormWidget.tsx', fbWidget);

let promoWidget = fs.readFileSync('src/components/LaunchPromoWidget.tsx', 'utf8');
promoWidget = promoWidget.replace("import React, { useState }", "import { useState }");
fs.writeFileSync('src/components/LaunchPromoWidget.tsx', promoWidget);

let adminStr = fs.readFileSync('src/screens/AdminDashboard.tsx', 'utf8');
adminStr = adminStr.replace(/import \{ useState, useEffect, useRef \} from 'react';/, 'import { useState, useEffect, useRef } from "react";\nimport { BuildInfoWidget } from "../components/BuildInfoWidget";\nimport { FailedApiLogWidget } from "../components/FailedApiLogWidget";\nimport { HiddenDebugHealthCheck } from "../components/HiddenDebugHealthCheck";');

// Admin widgets are actually defined INSIDE AdminDashboard.tsx! So I don't need to import them, but I need to render them. Wait, the error is:
// src/screens/AdminDashboard.tsx(85,10): error TS6133: 'BuildInfoWidget' is declared but its value is never read.
