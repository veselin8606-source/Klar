import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// Insert imports if not present
if (!code.includes('import { Mic')) {
  code = code.replace('import { ArrowLeft, Send', 'import { ArrowLeft, Send, Mic, Square');
}

// Add state for recording
const stateLogic = `
  const [isRecording, setIsRecording] = useState(false);
  const [audioBlob, setAudioBlob] = useState<Blob | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  
  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      mediaRecorderRef.current = recorder;
      const chunks: BlobPart[] = [];
      
      recorder.ondataavailable = e => {
        if (e.data.size > 0) chunks.push(e.data);
      };
      
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: 'audio/webm' });
        // Normally upload to Firebase Storage:
        // const storageRef = ref(getStorage(), \`voice/\${Date.now()}.webm\`);
        // await uploadBytes(storageRef, blob);
        // const url = await getDownloadURL(storageRef);
        // Send message with url...
        // For now, we just create a local URL to play it
        const url = URL.createObjectURL(blob);
        // Add to messages...
        const newMsg = {
          id: Date.now().toString(),
          senderId: 'current-user',
          text: '',
          audioUrl: url,
          timestamp: new Date().toISOString(),
          status: 'sent',
          type: 'audio'
        };
        setMessages(prev => [...prev, newMsg]);
      };
      
      recorder.start();
      setIsRecording(true);
    } catch(err) {
      console.error("Mic access denied", err);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
      mediaRecorderRef.current.stream.getTracks().forEach(t => t.stop());
    }
  };
`;

code = code.replace(/const \[messages, setMessages\] = useState<any\[\]>\(\[\]\);/, 'const [messages, setMessages] = useState<any[]>([]);\n' + stateLogic);

// Add Mic button to input area
code = code.replace(
  /<button\s+onClick=\{handleSend\}\s+disabled=\{!newMessage\.trim\(\)\}/,
  `<button onClick={isRecording ? stopRecording : startRecording} className={\`p-3 rounded-xl flex items-center justify-center transition-colors \${isRecording ? 'bg-red-500 text-white animate-pulse' : 'bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-brand'}\`}>
    {isRecording ? <Square size={20} className="fill-current" /> : <Mic size={20} />}
  </button>
  <button 
    onClick={handleSend} 
    disabled={!newMessage.trim()}`
);

// Add audio player to message renderer
code = code.replace(
  /<p className="text-\[15px\] leading-relaxed whitespace-pre-wrap break-words">\{msg\.text\}<\/p>/g,
  `{msg.audioUrl ? (
    <audio controls src={msg.audioUrl} className="max-w-[200px] h-10 rounded" />
  ) : (
    <p className="text-[15px] leading-relaxed whitespace-pre-wrap break-words">{msg.text}</p>
  )}`
);

fs.writeFileSync('src/screens/ChatView.tsx', code);
