const fs = require('fs');
let code = fs.readFileSync('src/screens/DatingRituals.tsx', 'utf-8');

const targetLogic = `    const markRitualCompleted = () => {
    try {
      const saved = localStorage.getItem('klar_rituals_streak');
      let count = 1;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (saved) {
        const data = JSON.parse(saved);
        const lastDate = new Date(data.lastDate);
        lastDate.setHours(0, 0, 0, 0);
        
        const diffTime = today.getTime() - lastDate.getTime();
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) {
          return; // Already completed today
        } else if (diffDays === 1) {
          count = data.count + 1;
        }
      }
      
      localStorage.setItem('klar_rituals_streak', JSON.stringify({ count, lastDate: today.toISOString() }));
      window.dispatchEvent(new Event('klar_ritual_completed'));
    } catch(e) {}
  };`;

const replaceLogic = `    const markRitualCompleted = () => {
    try {
      const saved = localStorage.getItem('klar_rituals_streak');
      let count = 1;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (saved) {
        const data = JSON.parse(saved);
        const lastDate = new Date(data.lastDate);
        lastDate.setHours(0, 0, 0, 0);
        
        const diffTime = today.getTime() - lastDate.getTime();
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        const isOnVacation = data.vacationUntil && new Date(data.vacationUntil) >= today;
        
        if (diffDays === 0) {
          return; // Already completed today
        } else if (diffDays === 1 || isOnVacation) {
          count = data.count + 1;
        }
      }
      
      localStorage.setItem('klar_rituals_streak', JSON.stringify({ count, lastDate: today.toISOString() }));
      window.dispatchEvent(new Event('klar_ritual_completed'));
    } catch(e) {}
  };`;

if (code.includes('if (diffDays === 1) {') && !code.includes('isOnVacation')) {
  code = code.replace(targetLogic, replaceLogic);
  fs.writeFileSync('src/screens/DatingRituals.tsx', code);
}
