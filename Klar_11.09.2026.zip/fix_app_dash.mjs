import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

if (!content.includes('import { ProfileDetailModal }')) {
  content = content.replace("import { melde } from '../lib/fehler';", "import { melde } from '../lib/fehler';\nimport { ProfileDetailModal } from '../components/ProfileDetailModal';");
  
  content = content.replace(/const \[profiles, setProfiles\] = useState/g, "const [selectedProfile, setSelectedProfile] = useState<any>(null);\n  const [profiles, setProfiles] = useState");
  
  content = content.replace(/<div className="absolute inset-0 bg-gradient-to-t/g, 
  `<div className="absolute inset-0 bg-transparent z-10 cursor-pointer" onClick={() => setSelectedProfile(profile)} />\n            <div className="absolute inset-0 bg-gradient-to-t`);
  
  content = content.replace("return (", 
  `return (
    <>
      {selectedProfile && <ProfileDetailModal profile={selectedProfile} onClose={() => setSelectedProfile(null)} />}
`);
  content = content.replace(/  \);\n\}$/, "    </>\n  );\n}");

  fs.writeFileSync('src/screens/Dashboard.tsx', content);
}
