const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

code = code.replace(
  /const apiLimiter = rateLimit\(\{[\s\S]*?legacyHeaders: false,\n\s+validate: \{ xForwardedForHeader: false \},\n\s+\}\);/,
  `const apiLimiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 500,
    keyGenerator: (req) => {
      const x = req.headers["x-forwarded-for"] || req.headers["forwarded"];
      const ip = (Array.isArray(x) ? x[0] : (x ? x.split(",")[0] : req.ip));
      return ipKeyGenerator(ip ?? "");
    },
    message: { error: "Zu viele Anfragen. Bitte versuche es später erneut." },
    standardHeaders: true,
    legacyHeaders: false,
    validate: { xForwardedForHeader: false },
  });`
);

fs.writeFileSync('server.ts', code);
