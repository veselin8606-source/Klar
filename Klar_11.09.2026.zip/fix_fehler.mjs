import fs from 'fs';
let content = fs.readFileSync('src/lib/fehler.ts', 'utf8');
content = content.replace(
  `  if (import.meta.env.DEV) console.error(\`[\${stelle}]\`, e, zusatz ?? '');`,
  `  if (import.meta.env.DEV) console.error(\`[\${stelle}]\`, e, zusatz ?? '');\n  // Fehler im UI sichtbar machen (für GlobalErrorOverlay)\n  window.dispatchEvent(new CustomEvent('app-error', { detail: { stelle, e, zusatz } }));`
);
fs.writeFileSync('src/lib/fehler.ts', content);
