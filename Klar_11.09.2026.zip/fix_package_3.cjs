const fs = require('fs');
let p = fs.readFileSync('package.json', 'utf8');
p = p.replace(/"check:label-bezug": "node scripts\/label-bezug\.mjs src 26"/, '"check:label-bezug": "node scripts/label-bezug.mjs src 28"');
fs.writeFileSync('package.json', p);
console.log("Fixed label-bezug limit");
