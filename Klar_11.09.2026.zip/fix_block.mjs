import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const lines = content.split('\n');
for (let i = 450; i < 464; i++) {
  if (!lines[i].startsWith('//')) {
    lines[i] = '// ' + lines[i];
  }
}
fs.writeFileSync('src/screens/ChatView.tsx', lines.join('\n'));
