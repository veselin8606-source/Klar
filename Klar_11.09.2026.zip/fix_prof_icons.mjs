import fs from 'fs';
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!prof.includes('MessageSquare')) {
  prof = prof.replace('import { ChevronRight', 'import { ChevronRight, MessageSquare, Star, Heart');
}
fs.writeFileSync('src/screens/Profile.tsx', prof);
