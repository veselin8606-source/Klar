const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');
server = server.replace(/\/api\/gemini\//g, '/api/');
fs.writeFileSync('server.ts', server);

let kiPolitik = fs.readFileSync('src/server/kiPolitik.ts', 'utf8');
kiPolitik = kiPolitik.replace(/\/api\/gemini\//g, '/api/');
fs.writeFileSync('src/server/kiPolitik.ts', kiPolitik);

let coach = fs.readFileSync('src/components/DailyCoachInsightWidget.tsx', 'utf8');
coach = coach.replace(/\/api\/gemini\//g, '/api/');
fs.writeFileSync('src/components/DailyCoachInsightWidget.tsx', coach);

let readi = fs.readFileSync('src/components/DatingReadinessWidget.tsx', 'utf8');
readi = readi.replace(/\/api\/gemini\//g, '/api/');
fs.writeFileSync('src/components/DatingReadinessWidget.tsx', readi);

let inspi = fs.readFileSync('src/components/DateInspirationTab.tsx', 'utf8');
inspi = inspi.replace(/\/api\/gemini\//g, '/api/');
fs.writeFileSync('src/components/DateInspirationTab.tsx', inspi);

console.log("Replaced /api/gemini/ with /api/");
