const fs = require('fs');

let content = fs.readFileSync('src/components/DashboardOnboarding.tsx', 'utf8');
content = content.replace(/Keine Endlos-Swipes\./g, 'Keine Endlos-Listen.');
content = content.replace(/Weniger Swipes, mehr Fokus/g, 'Weniger Scrollen, mehr Fokus');
fs.writeFileSync('src/components/DashboardOnboarding.tsx', content);

let pure = fs.readFileSync('src/server/pure.ts', 'utf8');
pure = pure.replace(/Nicht Swipes,/g, 'Nicht oberflächliches Wischen,');
fs.writeFileSync('src/server/pure.ts', pure);

console.log("Patched text.");
