const fs = require('fs');
const ts = require('typescript');

const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);

function visit(node) {
  if (node.kind === ts.SyntaxKind.FunctionDeclaration) {
    if (node.name && node.name.text === 'ChatView') {
      console.log('Found ChatView!');
    }
  }
  ts.forEachChild(node, visit);
}
visit(sourceFile);
console.log('Parsed successfully!');
