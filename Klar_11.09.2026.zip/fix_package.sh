#!/bin/bash
sed -i 's/"dev": "tsx server.ts"/"dev": "npm run build \&\& NODE_ENV=production tsx server.ts"/g' package.json
