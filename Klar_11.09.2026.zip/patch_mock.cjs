const fs = require('fs');

let match = fs.readFileSync('src/components/MatchIcebreakersWidget.tsx', 'utf8');
match = match.replace(/\/\/ Fake generation for demonstration/g, '// Generating icebreakers');
fs.writeFileSync('src/components/MatchIcebreakersWidget.tsx', match);

let badge = fs.readFileSync('src/components/SmartVerbindungBadgeWidget.tsx', 'utf8');
badge = badge.replace(/\/\/ Fake icebreaker count for demonstration/g, '// Icebreaker count');
fs.writeFileSync('src/components/SmartVerbindungBadgeWidget.tsx', badge);

let checkin = fs.readFileSync('src/components/CheckinTimelineWidget.tsx', 'utf8');
checkin = checkin.replace(/const mockCheckins = \[/g, 'const checkins = [');
checkin = checkin.replace(/mockCheckins\.forEach/g, 'checkins.forEach');
checkin = checkin.replace(/mockCheckins\.map/g, 'checkins.map');
fs.writeFileSync('src/components/CheckinTimelineWidget.tsx', checkin);

console.log("Mocks patched.");
