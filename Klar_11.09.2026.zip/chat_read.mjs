import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const importReplacement = `import { doc, getDoc, setDoc, updateDoc, collection, onSnapshot, writeBatch } from "firebase/firestore";\nimport { db } from "../lib/firebase";`;
content = content.replace(
  /import \{ auth \} from "\.\.\/lib\/firebase";/,
  `import { auth } from "../lib/firebase";\n${importReplacement}`
);

const hook = `
  useEffect(() => {
    if (istBeispielGespraech || !id || !auth.currentUser) return;
    const messagesRef = collection(db, \`chats/\${id}/messages\`);
    
    const unsubscribe = onSnapshot(messagesRef, (snapshot) => {
      const updates = {};
      const batch = writeBatch(db);
      let hasUnread = false;

      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        if (data.senderId !== auth.currentUser?.uid && !data.isRead) {
          batch.update(docSnap.ref, { isRead: true });
          hasUnread = true;
        }
        updates[docSnap.id] = data.isRead;
      });

      if (hasUnread) {
        batch.commit().catch(e => console.error("Error updating read status", e));
      }

      setMessages(prev => prev.map(m => {
        if (m.id && updates[m.id] !== undefined && updates[m.id] !== m.isRead) {
          return { ...m, isRead: updates[m.id] };
        }
        return m;
      }));
    }, (err) => console.error("Firestore read sync error", err));

    return () => unsubscribe();
  }, [id, istBeispielGespraech, auth.currentUser]);
`;

content = content.replace(
  /  const \[showQualityChart, setShowQualityChart\] = useState\(false\);/,
  hook + "\n  const [showQualityChart, setShowQualityChart] = useState(false);"
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
