const fs = require('fs');
const glob = require('glob');

const files = glob.sync('src/**/*.{ts,tsx}');

files.forEach(file => {
  let content = fs.readFileSync(file, 'utf8');
  let originalContent = content;

  // Replace common Math.random() expressions used for fake data with 0 or null
  content = content.replace(/Math\.random\(\) \* [0-9]+/g, '0');
  content = content.replace(/Math\.random\(\) > [0-9.]+/g, 'false');
  content = content.replace(/Math\.random\(\)/g, '0');
  content = content.replace(/Math\.floor\(0\)/g, '0');
  
  if (content !== originalContent) {
    fs.writeFileSync(file, content);
    console.log(`Patched fake metrics in ${file}`);
  }
});
