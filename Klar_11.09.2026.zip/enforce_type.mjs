import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

content = content.replace(/export default function ChatView\(\) \{/, 'const ChatView: React.FC = () => {');
content = content + '\nexport default ChatView;\n';

fs.writeFileSync('src/screens/ChatView.tsx', content);
