const fs = require('fs');

let politik = fs.readFileSync('src/server/kiPolitik.ts', 'utf8');
politik = politik.replace(/'\/api\/check-safety': 'kein_ersatz',/g, "'/api/check-safety': 'kein_ersatz',\n  '/api/messages/send-audio': 'kein_ersatz',");
fs.writeFileSync('src/server/kiPolitik.ts', politik);

let matrix = fs.readFileSync('KI-ERSATZ-MATRIX.md', 'utf8');
matrix = matrix.replace(/\| `\/api\/check-safety`/g, "| `/api/messages/send-audio` | `kein_ersatz` | Kein Ersatz für echte Transkription | Dürfte unmöglich simuliert werden |\n| `/api/check-safety`");
fs.writeFileSync('KI-ERSATZ-MATRIX.md', matrix);

console.log("Fixed kiPolitik");
