const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  app.post("/api/subscribe-klar-plus", express.json(), async (req, res) => {`;

const replace = `  app.post("/api/device-token", express.json(), async (req, res) => {
    try {
      const { userId, token } = req.body;
      if (!userId || !token) return res.status(400).send("Missing parameters");
      
      const db = require('firebase-admin/firestore').getFirestore();
      await db.collection('users').doc(userId).collection('fcmTokens').doc(token).set({
         createdAt: require('firebase-admin/firestore').FieldValue.serverTimestamp(),
         platform: 'web'
      }, { merge: true });
      
      res.json({ ok: true });
    } catch (e) {
      console.error(e);
      res.status(500).send("Error");
    }
  });

  app.post("/api/subscribe-klar-plus", express.json(), async (req, res) => {`;

if (!code.includes('/api/device-token')) {
  code = code.replace(target, replace);
  fs.writeFileSync('server.ts', code);
}
