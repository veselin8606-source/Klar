  app.get("/api/stats/klar-insights", async (req, res) => {
    try {
      const { uid: meineUid } = (req as any).user || (req as any).auth;
      const db = getFirestore();

      const userDoc = await db.collection("users").doc(meineUid).get();
      const einwilligung = userDoc.data()?.einwilligung;
      const darfKiAuswerten = zweckErlaubt(einwilligung, "ki_auswertung");

      const sevenDaysAgo = new Date();
      sevenDaysAgo.setDate(sevenDaysAgo.getDate() - 7);
      const limitDateStr = sevenDaysAgo.toISOString().split('T')[0] ?? '';

      const chatsSnap = await db.collection("chats")
        .where("participants", "array-contains", meineUid)
        .get();

      let connectionsMade = 0;
      let recentIcebreakers: string[] = [];

      const gatePromises: Promise<void>[] = [];

      chatsSnap.forEach((doc: any) => {
        const data = doc.data();
        const ansA = data.gateAntwortenA || 0;
        const ansB = data.gateAntwortenB || 0;

        let inTimeframe = true;
        if (data.createdAt) {
          const createdDate = data.createdAt.split('T')[0];
          if (createdDate < limitDateStr) {
            inTimeframe = false;
          }
        }

        if (inTimeframe && ansA >= 2 && ansB >= 2) {
          connectionsMade++;
        }

        if (darfKiAuswerten && inTimeframe) {
          gatePromises.push(
            doc.ref.collection("gate_answers")
              .where("uid", "==", meineUid)
              .get()
              .then((ansSnap: any) => {
                ansSnap.forEach((ansDoc: any) => {
                  if (ansDoc.data().antwort) {
                    recentIcebreakers.push(ansDoc.data().antwort);
                  }
                });
              })
          );
        }
      });

      await Promise.all(gatePromises);

      let icebreakerScore = null;
      let icebreakerFeedback = null;

      if (darfKiAuswerten && recentIcebreakers.length > 0) {
         const prompt = `Bewerte die Qualität der folgenden Icebreaker-Antworten (Skala 1-5).\nEine hohe Qualität bedeutet: authentisch, einladend, respektvoll und auf echten Austausch fokussiert.\nAntworten:\n${recentIcebreakers.map(ib => `- "${ib}"`).join("\n")}`;
         const antwort = await beantworte(
          "/api/stats/klar-insights",
          (_s) => ai.models.generateContent({
             model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
             contents: prompt,
             config: {
               systemInstruction: "Du bist ein erfahrener Kommunikationscoach. Bewerte die Icebreaker neutral und präzise. Formuliere exakt 1-2 kurze Sätze (feedback) und vergib einen Score (1-5).",
               responseMimeType: "application/json",
               responseSchema: {
                 type: Type.OBJECT,
                 properties: {
                   score: { type: Type.NUMBER },
                   feedback: { type: Type.STRING }
                 },
                 required: ["score", "feedback"]
               }
             }
          }),
          { kuratiert: { score: null, feedback: "Konnte nicht bewertet werden (Offline/Ersatz)." } }
         );
         
         if (antwort.status === 200) {
            icebreakerScore = antwort.koerper.score ?? null;
            icebreakerFeedback = antwort.koerper.feedback ?? null;
         }
      }

      res.json({
         connectionsMade,
         icebreakerScore,
         icebreakerFeedback,
         kiErlaubt: darfKiAuswerten
      });
    } catch (error) {
      console.error("Insights Error:", error);
      res.status(500).json({ error: "Fehler beim Laden der KlarInsights." });
    }
  });
