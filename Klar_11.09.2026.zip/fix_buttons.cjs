const fs = require('fs');

let profileModal = fs.readFileSync('src/components/ProfileDetailModal.tsx', 'utf8');
profileModal = profileModal.replace(/<button \n              onClick=\{onClose\}\n              className="absolute top-4 right-4/g, '<button \n              aria-label="Schließen"\n              onClick={onClose}\n              className="absolute top-4 right-4');
fs.writeFileSync('src/components/ProfileDetailModal.tsx', profileModal);

let profile = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
profile = profile.replace(/<button\n                          onClick=\{\(\) => \{/g, '<button\n                          aria-label={setting.label}\n                          role="switch"\n                          aria-checked={isChecked}\n                          onClick={() => {');
fs.writeFileSync('src/screens/Profile.tsx', profile);

let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
tips = tips.replace(/<button onClick=\{\(\) => toggleFavorite\(p\.id\)\} className="text-stone-400 hover:text-amber-500 transition-colors">/g, '<button aria-label="Tipp merken" onClick={() => toggleFavorite(p.id)} className="text-stone-400 hover:text-amber-500 transition-colors">');
fs.writeFileSync('src/screens/Tips.tsx', tips);

console.log("Fixed buttons");
