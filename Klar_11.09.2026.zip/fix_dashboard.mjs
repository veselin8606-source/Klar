import fs from 'fs';
let dashboard = fs.readFileSync('src/screens/Dashboard.tsx', 'utf-8');

// Fix uniqueLocations map
dashboard = dashboard.replace(
  /{uniqueLocations\.map/g,
  '{(uniqueLocations || []).map'
);

// Fix searchHistory map
dashboard = dashboard.replace(
  /{searchHistory\.map/g,
  '{(searchHistory || []).map'
);

fs.writeFileSync('src/screens/Dashboard.tsx', dashboard);
