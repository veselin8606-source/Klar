import fs from 'fs';
import ts from 'typescript';

const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);

function visit(node) {
  if (node.kind === ts.SyntaxKind.FunctionDeclaration && node.name && node.name.text === 'ChatView') {
    console.log('ChatView is at', node.getStart(sourceFile), node.getEnd());
    console.log('Return statements inside ChatView:');
    function findReturns(n) {
      if (n.kind === ts.SyntaxKind.ReturnStatement) {
        const text = code.substring(n.getStart(sourceFile), n.getEnd());
        if (text === "return;") {
          console.log('Bare Return at', n.getStart(sourceFile), code.substring(n.getStart(sourceFile), n.getStart(sourceFile) + 40).replace(/\n/g, ' '));
        }
      }
      ts.forEachChild(n, findReturns);
    }
    findReturns(node);
  }
  ts.forEachChild(node, visit);
}
visit(sourceFile);
