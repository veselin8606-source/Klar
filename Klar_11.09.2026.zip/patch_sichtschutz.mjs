import fs from 'fs';

let code = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf-8');

// Add import if not exists
if (!code.includes('import { motion }')) {
  code = code.replace(
    `import { EyeOff, Eye } from 'lucide-react';`,
    `import { EyeOff, Eye } from 'lucide-react';\nimport { motion } from 'motion/react';`
  );
}

// Replace button with motion.button
const targetRegex = /export function SichtschutzKnopf\(\) \{\n  return \(\n    <button\n      onClick=\{aktiviereSichtschutz\}\n      className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"\n      aria-label="Bildschirm verdecken"\n      title="Bildschirm verdecken"\n    >\n      <EyeOff size=\{20\} \/>\n    <\/button>\n  \);\n\}/;

const replacement = `export function SichtschutzKnopf() {
  return (
    <motion.button
      whileTap={{ scale: 0.9 }}
      transition={{ duration: 0.1 }}
      onClick={aktiviereSichtschutz}
      className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
      aria-label="Bildschirm verdecken"
      title="Bildschirm verdecken"
    >
      <EyeOff size={20} />
    </motion.button>
  );
}`;

code = code.replace(targetRegex, replacement);

fs.writeFileSync('src/components/Sichtschutz.tsx', code);
console.log("Patched Sichtschutz.tsx");
