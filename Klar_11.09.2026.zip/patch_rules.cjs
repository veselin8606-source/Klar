const fs = require('fs');
let code = fs.readFileSync('firestore.rules', 'utf-8');

const target = `!request.resource.data.keys().hasAny(['isVerified', 'trustScore', 'plan', 'roles',
                                                             'isAdult', 'geburtsdatum', 'alterGeprueftAm',
                                                             'einwilligung']);`;

const replace = `!request.resource.data.keys().hasAny(['isVerified', 'verificationStatus', 'verificationGeste', 'trustScore', 'plan', 'roles',
                                                             'contactDay', 'contactCount', 'quotaLedger',
                                                             'isAdult', 'geburtsdatum', 'alterGeprueftAm',
                                                             'einwilligung']);`;

code = code.replace(target, replace);
fs.writeFileSync('firestore.rules', code);
