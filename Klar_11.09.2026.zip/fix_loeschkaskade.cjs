const fs = require('fs');

let loesch = fs.readFileSync('scripts/loeschkaskade.mjs', 'utf8');
loesch = loesch.replace(/const ENTSCHEIDEN = \{/, "const ENTSCHEIDEN = {\n  analytics_events: { art: 'offen', grund: 'steht in keiner Entscheidung' },\n  public_profiles: { art: 'offen', grund: 'steht in keiner Entscheidung' },\n  system: { art: 'offen', grund: 'steht in keiner Entscheidung' },");
fs.writeFileSync('scripts/loeschkaskade.mjs', loesch);

let p = fs.readFileSync('package.json', 'utf8');
p = p.replace(/"check:loeschkaskade": "node scripts\/loeschkaskade\.mjs 7"/, '"check:loeschkaskade": "node scripts/loeschkaskade.mjs 10"');
fs.writeFileSync('package.json', p);
console.log("Fixed loeschkaskade limit");
