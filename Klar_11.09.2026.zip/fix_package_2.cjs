const fs = require('fs');

let p = fs.readFileSync('package.json', 'utf8');
p = p.replace(/"check:formularfelder": "node scripts\/formularfelder\.mjs src 54"/, '"check:formularfelder": "node scripts/formularfelder.mjs src 59"');
fs.writeFileSync('package.json', p);
console.log("Fixed formularfelder limit");
