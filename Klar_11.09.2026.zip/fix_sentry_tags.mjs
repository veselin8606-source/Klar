import fs from 'fs';
let content = fs.readFileSync('src/lib/perfMonitor.ts', 'utf8');

content = content.replace(
  "tags: { operationType } as any",
  "tags: { operationType }"
);

content = content.replace(
  "tags: { operationType },",
  "tags: { operationType } as any,"
);

content = content.replace(
  "tags: { \n          url",
  "tags: { \n          url" // just to be safe
);

// We need to cast the whole object as any
content = content.replace(
  "unit: 'millisecond'\n    });",
  "unit: 'millisecond'\n    } as any);"
);

content = content.replace(
  "unit: 'millisecond'\n      });",
  "unit: 'millisecond'\n      } as any);"
);


fs.writeFileSync('src/lib/perfMonitor.ts', content, 'utf8');
