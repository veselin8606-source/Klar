import fs from 'fs';
let content = fs.readFileSync('src/lib/authFetch.ts', 'utf8');

const replacement = `
import { monitoredFetch } from './perfMonitor';

// ═══════════════════════════════════════════════════════════════════════════`;

content = content.replace('// ═══════════════════════════════════════════════════════════════════════════', replacement);

const originalReplacement = `const antwort = await monitoredFetch(input, { ...init, headers });`;
content = content.replace('const antwort = await original(input, { ...init, headers });', originalReplacement);

fs.writeFileSync('src/lib/authFetch.ts', content, 'utf8');
