import fs from 'fs';
import ts from 'typescript';

const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);

function visit(node) {
  if (node.kind === ts.SyntaxKind.VariableDeclaration && node.name && node.name.text === 'ChatView') {
    const stmts = node.initializer.body.statements;
    const last = stmts[stmts.length - 1];
    console.log("Last statement is", ts.SyntaxKind[last.kind]);
    console.log(code.substring(last.getStart(sourceFile), last.getStart(sourceFile) + 150));
  }
  ts.forEachChild(node, visit);
}
visit(sourceFile);
