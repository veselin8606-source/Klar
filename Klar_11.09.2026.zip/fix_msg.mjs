import fs from 'fs';
let code = fs.readFileSync('src/components/MessageBubble.tsx', 'utf8');

code = code.replace(
  "const displayString = (hasTranslation && !showOriginal) ? msg.textTranslated : original;",
  `const displayString = (hasTranslation && !showOriginal) ? msg.textTranslated : original;
  
  let timeString = '';
  if ((msg as any).timestamp) {
    const d = new Date((msg as any).timestamp);
    const today = new Date();
    if (d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()) {
      timeString = d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } else {
      timeString = d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
  }`
);
fs.writeFileSync('src/components/MessageBubble.tsx', code);
console.log("msg fixed");
