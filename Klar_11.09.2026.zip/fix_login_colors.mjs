import fs from 'fs';
let content = fs.readFileSync('src/screens/Login.tsx', 'utf8');

content = content.replace(
  /bg-red-50 dark:bg-red-900\/20 border border-red-200 dark:border-red-800 text-red-600 dark:text-red-400/g,
  "bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 text-amber-700 dark:text-amber-400"
);

fs.writeFileSync('src/screens/Login.tsx', content);
