import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');

// The user wants to long press the SichtschutzKnopf to disable the Sichtschutz for 5 minutes.
// So we will add a local storage flag + a timeout to re-enable it.
const newKnopf = `
import { AnimatePresence } from 'framer-motion';

export function SichtschutzKnopf() {
  const [menuOpen, setMenuOpen] = useState(false);
  const pressTimer = useRef<NodeJS.Timeout | null>(null);

  const startPress = () => {
    pressTimer.current = setTimeout(() => {
      setMenuOpen(true);
      if (window.navigator && window.navigator.vibrate) {
        window.navigator.vibrate(50);
      }
    }, 500); // 500ms long press
  };

  const cancelPress = () => {
    if (pressTimer.current) clearTimeout(pressTimer.current);
  };

  const handlePause = () => {
    localStorage.setItem('sichtschutz_paused_until', String(Date.now() + 5 * 60 * 1000));
    setMenuOpen(false);
  };

  return (
    <div className="relative">
      <motion.button
        whileTap={{ scale: 0.9 }}
        transition={{ duration: 0.1 }}
        onPointerDown={startPress}
        onPointerUp={cancelPress}
        onPointerLeave={cancelPress}
        onClick={() => {
          if (!menuOpen) aktiviereSichtschutz();
        }}
        className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"
        aria-label="Bildschirm verdecken"
        title="Bildschirm verdecken"
      >
        <EyeOff size={20} />
      </motion.button>

      <AnimatePresence>
        {menuOpen && (
          <>
            <div className="fixed inset-0 z-40" onClick={() => setMenuOpen(false)} />
            <motion.div
              initial={{ opacity: 0, scale: 0.95, y: 10 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.95, y: 10 }}
              className="absolute right-0 top-full mt-2 w-48 bg-white dark:bg-stone-900 rounded-xl shadow-lg border border-stone-200 dark:border-stone-800 z-50 overflow-hidden"
            >
              <button
                onClick={handlePause}
                className="w-full text-left px-4 py-3 text-sm text-stone-700 dark:text-stone-300 hover:bg-stone-100 dark:hover:bg-stone-800"
              >
                Für 5 Minuten pausieren
              </button>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  );
}
`;

content = content.replace(/export function SichtschutzKnopf\(\) \{[\s\S]*?\}\n/m, newKnopf);

content = content.replace("const [aktiv, setAktiv] = useState(false);", 
`const [aktiv, setAktiv] = useState(false);
  const istPausiert = () => {
    const pausedUntil = localStorage.getItem('sichtschutz_paused_until');
    if (!pausedUntil) return false;
    if (Date.now() < parseInt(pausedUntil, 10)) return true;
    localStorage.removeItem('sichtschutz_paused_until');
    return false;
  };
`);

content = content.replace(/const ein = \(\) => setAktiv\(true\);/, "const ein = () => { if (!istPausiert()) setAktiv(true); };");

fs.writeFileSync('src/components/Sichtschutz.tsx', content);
