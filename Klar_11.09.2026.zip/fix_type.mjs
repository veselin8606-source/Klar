import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace(
  "  originalText?: string;",
  "  originalText?: string;\n  textOriginal?: string;\n  translationStatus?: 'pending' | 'completed' | 'failed' | 'none';"
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
