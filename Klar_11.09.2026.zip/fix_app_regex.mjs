import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf8');

content = content.replace(/},\s*\[navigate\]\);\s*return null;\s*\}/, 
`
}

function NotFoundHandler() {
  const navigate = useNavigate();
  useEffect(() => {
    navigate('/', { replace: true });
  }, [navigate]);
  return null;
}
`);
fs.writeFileSync('src/App.tsx', content);
