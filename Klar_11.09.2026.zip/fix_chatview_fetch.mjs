import fs from 'fs';

let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

content = content.replace(
  "        auth.currentUser.getIdToken().then(token => {\n          fetch('/api/messages/send', {\n        fetch('/api/messages/send', {",
  "        auth.currentUser.getIdToken().then(token => {\n          fetch('/api/messages/send', {"
);
// it might have different indentation or newlines
content = content.replace(
  /fetch\('\/api\/messages\/send', \{\s*fetch\('\/api\/messages\/send', \{/,
  "fetch('/api/messages/send', {"
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
