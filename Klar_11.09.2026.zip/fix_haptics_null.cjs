const fs = require('fs');

let haptics = fs.readFileSync('src/lib/haptics.ts', 'utf8');
// Replace strict parsing that fails on TS
haptics = haptics.replace(/const storedIntensity = localStorage\.getItem\('klar_haptic_intensity'\);\n\s*let intensity = 100;\n\s*if \(storedIntensity !== null\) \{\n\s*intensity = parseInt\(storedIntensity, 10\);\n\s*\}/g, "const storedIntensity = localStorage.getItem('klar_haptic_intensity');\n      let intensity = 100;\n      if (storedIntensity !== null) {\n        intensity = parseInt(storedIntensity as string, 10);\n      }");

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = window\.location\.origin;\n/g, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

fs.writeFileSync('src/lib/haptics.ts', haptics);
console.log("Fixed.");
