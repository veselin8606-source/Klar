# Spezifikation: Live-Übersetzung (Real-Time Translation)

## 1. Technische Architektur-Spezifikation

### Systemübersicht
Die Live-Übersetzung nutzt eine asynchrone Event-Architektur, um die Kern-Latenz des Chats bei 0 zu halten. Der Client persistiert Nachrichten im Firestore wie gewohnt. Parallel triggert der Client einen Node.js-Endpunkt, der die Gemini API asynchron aufruft und das Ergebnis im Firestore in das bestehende Dokument einbettet ("Patching").

### Datenstruktur (Firestore)
Erweiterung der Dokumente unter `chats/{chatId}/messages/{messageId}`:
```json
{
  "id": "msg-123",
  "senderId": "user_a",
  "text": "Echt schöner Abend gestern!", // Original-Nachricht
  "timestamp": "2026-09-04T12:00:00Z",
  "translation": {
    "targetLanguage": "en",
    "text": "Really nice evening yesterday!",
    "status": "completed" // "pending" | "completed" | "failed"
  }
}
```

### JSON-Kommunikation (Client -> Server)
**Endpunkt**: `POST /api/chat/translate`
**Request-Body**:
```json
{
  "chatId": "chat-456",
  "messageId": "msg-123",
  "text": "Echt schöner Abend gestern!",
  "targetLanguage": "en"
}
```
**Response (synchrones Acknowledge)**:
```json
{
  "status": "processing",
  "messageId": "msg-123"
}
```

### Serverseitige Endpunkte (Express `server.ts`)
1. **POST `/api/chat/translate`**: 
   - Validiert die Authentifizierung.
   - Entfernt PII (z.B. Regex-Stripping von Telefonnummern vorab).
   - Ruft `ai.models.generateContent` der `@google/genai` API (Modell: `gemini-2.5-flash`) auf.
   - Patcht das Firestore-Dokument `chats/{chatId}/messages/{messageId}` mit der Übersetzung.

---

## 2. Compliance-Spezifikation (DSGVO)

Um den Datenschutz und die DSGVO-Konformität bei der Verarbeitung sensibler Chat-Inhalte (Art. 9 DSGVO) durch KI zu garantieren, werden folgende Richtlinien implementiert:

### A. Anonymisierung vor Übertragung (Data Minimization)
Das Backend implementiert einen leichten Sanitizer vor dem Gemini-Aufruf:
- Erkennung und Maskierung von Telefonnummern, E-Mail-Adressen und IBANs per Regex.
- Das KI-Modell erhält ausschließlich den semantischen Kontext, keine harten Identifikatoren.

### B. "Zero Data Retention" & Region Binding
- Die Gemini API wird strikt über einen dedizierten Google Cloud Account angesprochen, bei dem die Speicherung von Prompt-Historien zur Modellverbesserung **deaktiviert** (Opt-Out / Enterprise Terms) ist.
- Alle API-Requests werden über europäische Endpunkte (`europe-west3`) geroutet.

### C. Nutzertransparenz & Einwilligung
- **Onboarding / UI-Hinweis**: Bei der ersten Aktivierung des Features wird ein Disclaimer angezeigt: *"Deine Nachrichten werden zur Live-Übersetzung temporär maschinell durch KI verarbeitet. Es erfolgt keine dauerhafte Speicherung oder ein Training der Modelle mit deinen Chat-Inhalten."*
- **Sprachwahl**: Standardmäßig ist die Übersetzung inaktiv (`targetLanguage: null`). Der Nutzer muss aktiv eine Zielsprache (Englisch, Deutsch, Spanisch, etc.) auswählen.

---

## 3. UI/UX Design

- **Original First**: Der Originaltext wird immer angezeigt, um Verfälschungen vorzubeugen.
- **Dezenter Toggle**: Ein "Translate"-Button unterhalb der Nachricht toggelt den asynchron geladenen, übersetzten Text ein und aus.
- **Nahtlose Integration**: `motion.div` Layout-Animationen (framer-motion) sorgen dafür, dass die Chat-Blase weich nach unten aufklappt, wenn die Übersetzung eintrifft.
