import * as Sentry from '@sentry/react';

interface FetchOptions extends RequestInit {
  timeout?: number;
}

/**
 * Enterprise-grade lightweight fetch wrapper measuring API latency
 * and capturing metrics for P95/P99 monitoring without mutating payload/response.
 */
export async function monitoredFetch(input: RequestInfo | URL, init?: FetchOptions): Promise<Response> {
  const startTime = performance.now();
  const url = typeof input === 'string' ? input : (input instanceof URL ? input.toString() : input.url);
  const method = init?.method || 'GET';

  try {
    const response = await fetch(input, init);
    const duration = performance.now() - startTime;
    
    // Log performance metrics to Sentry as custom measurements
    Sentry.metrics.distribution('api.latency', duration, {
      tags: { 
        url: new URL(url, window.location.origin).pathname, // Group by path, ignore query strings
        method,
        status: String(response.status)
      },
      unit: 'millisecond'
    });

    return response;
  } catch (error) {
    const duration = performance.now() - startTime;
    
    Sentry.metrics.distribution('api.latency', duration, {
      tags: { 
        url: new URL(url, window.location.origin).pathname,
        method,
        status: 'error'
      },
      unit: 'millisecond'
    });

    throw error;
  }
}
