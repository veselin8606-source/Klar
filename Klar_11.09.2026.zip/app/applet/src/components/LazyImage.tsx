import { useState } from 'react';
import { ImageOff } from 'lucide-react';

interface LazyImageProps extends React.ImgHTMLAttributes<HTMLImageElement> {
  fallback?: React.ReactNode;
  containerClassName?: string;
}

export function LazyImage({ 
  src, 
  alt, 
  className = '', 
  containerClassName = '', 
  fallback,
  ...props 
}: LazyImageProps) {
  const [isLoaded, setIsLoaded] = useState(false);
  const [hasError, setHasError] = useState(false);

  if (hasError) {
    return (
      <div className={`flex items-center justify-center bg-stone-100 dark:bg-stone-800 rounded-full ${containerClassName} ${className}`}>
        {fallback || <ImageOff className="w-1/2 h-1/2 text-stone-400" aria-label="Bild konnte nicht geladen werden" />}
      </div>
    );
  }

  return (
    <div className={`relative overflow-hidden ${containerClassName}`}>
      {/* Skeleton loader shown while image is not yet loaded */}
      {!isLoaded && (
        <div 
          className={`absolute inset-0 bg-stone-200 dark:bg-stone-700 animate-pulse ${className}`} 
          aria-hidden="true"
        />
      )}
      <img
        src={src}
        alt={alt}
        loading="lazy"
        onLoad={() => setIsLoaded(true)}
        onError={() => setHasError(true)}
        className={`${className} ${isLoaded ? 'opacity-100' : 'opacity-0'} transition-opacity duration-300`}
        {...props}
      />
    </div>
  );
}
