import { monitoredFetch } from '../src/lib/apiMonitor';
import * as Sentry from '@sentry/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';

vi.mock('@sentry/react', () => ({
  metrics: {
    distribution: vi.fn(),
  },
}));

describe('monitoredFetch', () => {
  const originalFetch = global.fetch;
  const originalPerformanceNow = performance.now;

  beforeEach(() => {
    vi.clearAllMocks();
    let time = 0;
    performance.now = vi.fn(() => {
      time += 100;
      return time;
    });
  });

  afterEach(() => {
    global.fetch = originalFetch;
    performance.now = originalPerformanceNow;
  });

  it('measures latency and reports to Sentry on success', async () => {
    global.fetch = vi.fn().mockResolvedValue(new Response('ok', { status: 200 }));
    
    await monitoredFetch('/api/test', { method: 'POST' });
    
    expect(global.fetch).toHaveBeenCalledWith('/api/test', { method: 'POST' });
    expect(Sentry.metrics.distribution).toHaveBeenCalledWith(
      'api.latency',
      100, // 200 - 100
      {
        tags: { url: '/api/test', method: 'POST', status: '200' },
        unit: 'millisecond',
      }
    );
  });

  it('measures latency and reports to Sentry on network error', async () => {
    const error = new Error('Network error');
    global.fetch = vi.fn().mockRejectedValue(error);
    
    await expect(monitoredFetch('/api/error')).rejects.toThrow('Network error');
    
    expect(Sentry.metrics.distribution).toHaveBeenCalledWith(
      'api.latency',
      100,
      {
        tags: { url: '/api/error', method: 'GET', status: 'error' },
        unit: 'millisecond',
      }
    );
  });
});
