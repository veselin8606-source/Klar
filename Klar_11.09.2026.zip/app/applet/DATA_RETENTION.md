# Data Retention & Privacy-by-Design Policy

Diese Richtlinie definiert die strikten Datenlebenszyklen (Time-to-Live / TTL) für das Projekt **Klar**. 
Als Dating-App verarbeitet Klar besondere Kategorien personenbezogener Daten (Art. 9 DSGVO). Dem Grundsatz der Speicherbegrenzung (Art. 5 Abs. 1 lit. e DSGVO) wird durch automatisierte Löschroutinen (Firestore TTL Policies) Genüge getan.

## Firestore TTL (Time-To-Live) Konfiguration

Firestore bietet native TTL-Policies. Diese bereinigen Dokumente automatisch, wenn der in einem konfigurierten Timestamp-Feld (`expiresAt`) festgelegte Zeitpunkt überschritten ist. 
Die Einrichtung erfolgt nicht über `firestore.rules`, sondern über die Google Cloud Console oder gcloud CLI.

### 1. Konversations-Logs & Nachrichten (`/messages`)
- **Feld:** `expiresAt`
- **Frist:** 90 Tage nach Versand (sofern der Chat nicht durch eine Moderationsmeldung "eingefroren" wurde).
- **Setup:** `gcloud firestore fields ttls update expiresAt --collection-group=messages --enable-ttl`

### 2. KI-Zwischenspeicher (`/users/{userId}/ki_zwischenspeicher/{id}`)
- **Feld:** `expiresAt`
- **Frist:** 36 Stunden nach Erstellung. Dient ausschließlich der Überbrückung von API-Ausfällen.
- **Setup:** `gcloud firestore fields ttls update expiresAt --collection-group=ki_zwischenspeicher --enable-ttl`

### 3. Fehlgeschlagene Altersverifikationen (`/age_attempts`)
- **Feld:** `expiresAt`
- **Frist:** 24 Stunden nach Erstellung. Dient nur dem Rate-Limiting und der Betrugsprävention (Brute-Force auf das Geburtsdatum).
- **Setup:** `gcloud firestore fields ttls update expiresAt --collection-group=age_attempts --enable-ttl`

### 4. Gelöschte Konten / Deletion Logs (`/deletion_log`)
- **Feld:** `expiresAt`
- **Frist:** 30 Tage. Kaskadierende Löschvorgänge schreiben ein Audit-Log, um im Fehlerfall Inkonsistenzen aufzuspüren.
- **Setup:** `gcloud firestore fields ttls update expiresAt --collection-group=deletion_log --enable-ttl`

## Security Rules Architektur (Least Privilege)
Die `firestore.rules` (siehe Datei) sind nach dem Prinzip "Default Deny" aufgebaut. 
Schreibzugriffe erfolgen fast ausschließlich über den Server (Admin SDK) in Transaktionen, um Idempotenz und Validierung zu garantieren.
Client-seitige Schreibzugriffe sind blockiert (`allow write: if false;`), um Manipulationen von Zählern, Swipes oder Metriken (z.B. Kontingente) unmöglich zu machen.
