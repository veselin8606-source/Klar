const fs = require('fs');
let app = fs.readFileSync('src/App.tsx', 'utf8');
app = "import * as Sentry from '@sentry/react';\n" + app;
fs.writeFileSync('src/App.tsx', app);

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = window\.location\.origin;\n/g, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

console.log("App Sentry import fixed.");
