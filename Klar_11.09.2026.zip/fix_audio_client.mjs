import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

content = content.replace(
  /        if \(res\.ok\) \{\n           \/\/ Rely on firestore snapshot listener to update it, or reload\n        \}/,
  `        if (res.ok) {
           const data = await res.json();
           setMessages(prev => prev.map(m => m.id === tempId ? { ...m, audioTranscription: data.transcription || 'Transkription abgeschlossen' } : m));
        }`
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
