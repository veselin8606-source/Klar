import fs from 'fs';
let content = fs.readFileSync('src/server/db.ts', 'utf8');

content = content.replace(/constructor\(private db: any\)/g, "db: any;\n  constructor(db: any) { this.db = db; }");
content = content.replace(/constructor\(private db: any, private pathStr: string\)/g, "db: any;\n  pathStr: string;\n  constructor(db: any, pathStr: string) { this.db = db; this.pathStr = pathStr; }");
content = content.replace(/constructor\(private db: any, private q: any\)/g, "db: any;\n  q: any;\n  constructor(db: any, q: any) { this.db = db; this.q = q; }");
content = content.replace(/constructor\(_db: any, private t: any\)/g, "t: any;\n  constructor(_db: any, t: any) { this.t = t; }");
content = content.replace(/constructor\(private b: any\)/g, "b: any;\n  constructor(b: any) { this.b = b; }");

fs.writeFileSync('src/server/db.ts', content);
