const fs = require('fs');
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

// Add jsPDF import
const importTarget = `import { Languages, Moon, HeartPulse, ArrowLeft, Sparkles, Send, CalendarDays, Clock, X, CheckCheck, History, Activity, Flag, AlertTriangle, Bookmark, Brain, ListChecks, MapPin, Bell, BellOff, Minimize2, Mic, MessageSquare } from "lucide-react";`;
const importReplace = `import { Languages, Moon, HeartPulse, ArrowLeft, Sparkles, Send, CalendarDays, Clock, X, CheckCheck, History, Activity, Flag, AlertTriangle, Bookmark, Brain, ListChecks, MapPin, Bell, BellOff, Minimize2, Mic, MessageSquare, Download } from "lucide-react";\nimport { jsPDF } from "jspdf";`;

if (!code.includes('import { jsPDF }')) {
  code = code.replace(importTarget, importReplace);
}

// Add the exportPDF function inside ChatView
const funcTarget = `const handleSend = async (forceSend = false) => {`;
const funcReplace = `  const [isExporting, setIsExporting] = useState(false);

  const exportPDF = () => {
    if (messages.length === 0) return;
    setIsExporting(true);
    try {
      const doc = new jsPDF();
      doc.setFont("helvetica");
      doc.setFontSize(20);
      doc.text(\`Chat mit \${profile?.name || 'Unbekannt'}\`, 14, 22);
      
      doc.setFontSize(10);
      doc.setTextColor(100);
      doc.text(\`Exportiert am: \${new Date().toLocaleDateString('de-DE')}\`, 14, 30);
      
      let currentY = 40;
      doc.setTextColor(0);
      doc.setFontSize(12);
      
      messages.forEach((msg, idx) => {
        if (currentY > 270) {
          doc.addPage();
          currentY = 20;
        }
        
        const sender = msg.isMine ? "Ich" : (profile?.name || "Match");
        const time = new Date(msg.timestamp).toLocaleTimeString('de-DE', { hour: '2-digit', minute:'2-digit' });
        
        doc.setFont("helvetica", "bold");
        doc.text(\`\${sender} (\${time}):\`, 14, currentY);
        currentY += 6;
        
        doc.setFont("helvetica", "normal");
        const splitText = doc.splitTextToSize(msg.text, 180);
        doc.text(splitText, 14, currentY);
        currentY += (splitText.length * 6) + 4;
      });
      
      doc.save(\`Klar_Chat_\${profile?.name || 'Match'}.pdf\`);
    } catch (e) {
      console.error("PDF Export error:", e);
    } finally {
      setIsExporting(false);
    }
  };

  const handleSend = async (forceSend = false) => {`;

if (!code.includes('const exportPDF = ()')) {
  code = code.replace(funcTarget, funcReplace);
}

// Add the button in the header
const buttonTarget = `          <button 
            onClick={() => setShowReportModal(true)}
            className="p-2 bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-red-500 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
            title="Nutzer melden"
          >
            <Flag size={20} />
          </button>`;

const buttonReplace = `          <button 
            onClick={exportPDF}
            disabled={isExporting}
            className="p-2 bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-brand dark:hover:text-brand-light rounded-full transition-colors disabled:opacity-50"
            title="Chat als PDF sichern"
          >
            <Download size={20} />
          </button>
          <button 
            onClick={() => setShowReportModal(true)}
            className="p-2 bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-red-500 rounded-full hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
            title="Nutzer melden"
          >
            <Flag size={20} />
          </button>`;

if (!code.includes('onClick={exportPDF}')) {
  code = code.replace(buttonTarget, buttonReplace);
}

fs.writeFileSync('src/screens/ChatView.tsx', code);
