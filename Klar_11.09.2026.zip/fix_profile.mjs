import fs from 'fs';
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
code = code.replace(
  "import { SmartPause } from '../components/SmartPause';",
  "import { SmartPause } from '../components/SmartPause';\nimport { FeedbackFormWidget } from '../components/FeedbackFormWidget';"
);
code = code.replace(
  "<FocusTimeSettingsWidget />",
  "<FocusTimeSettingsWidget />\n        <FeedbackFormWidget />"
);
fs.writeFileSync('src/screens/Profile.tsx', code);
