#!/bin/bash
sed -i -e '/{[/]\* P1: Verifizierung — ohne sie lehnt jede Regel jeden Kontakt ab. \*[/]}/,/<\/Link>/c\
            {/* P1: Verifizierung — ohne sie lehnt jede Regel jeden Kontakt ab. */}\
            <div className="mt-4 p-4 rounded-xl border border-stone-200 dark:border-stone-700 bg-white dark:bg-stone-800/50">\
              <div className="flex items-center justify-between mb-2">\
                <span className="text-sm font-medium text-stone-700 dark:text-stone-300">\
                  Verifizierungsstufe\
                </span>\
                {verifizierung === "bestaetigt" ? (\
                  <span className="px-2.5 py-1 text-xs font-bold rounded-full border bg-green-100 text-green-700 border-green-200 dark:bg-green-900/30 dark:text-green-400 dark:border-green-800/50 flex items-center gap-1.5">\
                    <ShieldCheck size={14} /> Fully Verified\
                  </span>\
                ) : profileData?.isVerified ? (\
                  <span className="px-2.5 py-1 text-xs font-bold rounded-full border bg-brand/10 text-brand border-brand/20 dark:bg-brand-light/10 dark:text-brand-light dark:border-brand-light/20 flex items-center gap-1.5">\
                    <ShieldCheck size={14} /> Verified\
                  </span>\
                ) : (\
                  <span className="px-2.5 py-1 text-xs font-bold rounded-full border bg-stone-100 text-stone-600 border-stone-200 dark:bg-stone-700 dark:text-stone-400 dark:border-stone-600">\
                    Basic\
                  </span>\
                )}\
              </div>\
              <p className="text-xs text-stone-500 dark:text-stone-400 mb-3">\
                {verifizierung === "bestaetigt"\
                  ? "Deine Identität und Fotos sind vollständig geprüft."\
                  : profileData?.isVerified\
                  ? "Dein Konto ist bestätigt, aber noch nicht durch Foto-Identifikation verifiziert."\
                  : "Basis-Konto ohne erweiterte Verifizierung."}\
              </p>\
              \
              <Link\
                to="/verifizierung"\
                className="w-full flex items-center justify-between p-3 bg-stone-50 hover:bg-stone-100 dark:bg-stone-800 dark:hover:bg-stone-700 rounded-lg transition-colors"\
              >\
                <span className="text-sm text-stone-700 dark:text-stone-300">\
                  {verifizierung === "bestaetigt" ? "Verifizierung ansehen" : \
                   verifizierung === "in_pruefung" ? "Verifizierung läuft ..." : "Jetzt verifizieren"}\
                </span>\
                <ChevronRight size={18} className="text-stone-400" />\
              </Link>\
            </div>\
' src/screens/Profile.tsx
