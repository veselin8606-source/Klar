import fs from 'fs';

let content = fs.readFileSync('src/components/MessageBubble.tsx', 'utf8');

const audioUI = `
      <div className="relative">
        {msg.audioUrl ? (
          <div className="mb-2">
            <audio controls src={msg.audioUrl} className="w-full max-w-[200px] h-8 rounded-full bg-stone-100 dark:bg-stone-800" />
            <p className="mt-2 text-[13px] italic text-stone-600 dark:text-stone-300 leading-relaxed border-l-2 border-brand/50 pl-2">
              {msg.audioTranscription || 'Wird transkribiert...'}
            </p>
          </div>
        ) : (
          <p className="text-[15px] leading-relaxed">{original}</p>
        )}
`;

content = content.replace(
  '<div className="relative">\n        <p className="text-[15px] leading-relaxed">{original}</p>',
  audioUI
);

fs.writeFileSync('src/components/MessageBubble.tsx', content);
