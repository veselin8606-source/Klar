import fs from 'fs';
import ts from 'typescript';

const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);

function visit(node) {
  if (node.kind === ts.SyntaxKind.VariableDeclaration && node.name && node.name.text === 'ChatView') {
    let found = false;
    node.initializer.body.statements.forEach(stmt => {
      if (stmt.kind === ts.SyntaxKind.ReturnStatement) {
        console.log("Found top-level return statement!");
        found = true;
      }
    });
    if (!found) {
      console.log("NO TOP-LEVEL RETURN STATEMENT FOUND!");
      console.log("Statements inside ChatView:", node.initializer.body.statements.map(s => ts.SyntaxKind[s.kind]).join(", "));
    }
  }
  ts.forEachChild(node, visit);
}
visit(sourceFile);
