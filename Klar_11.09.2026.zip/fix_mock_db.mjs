import fs from 'fs';

let content = fs.readFileSync('src/server/db.ts', 'utf8');

const tReplace = `  set(mockDoc: MockDoc, data: any, options?: any) {
    this.t.set(mockDoc.ref, data, options);
    return this;
  }
  update(mockDoc: MockDoc, data: any) {
    this.t.update(mockDoc.ref, data);
    return this;
  }
  delete(mockDoc: MockDoc) {`;

content = content.replace(
  /  set\(mockDoc: MockDoc, data: any, options\?: any\) \{\s*this\.t\.set\(mockDoc\.ref, data, options\);\s*return this;\s*\}\s*delete\(mockDoc: MockDoc\) \{/,
  tReplace
);

const bReplace = `  set(mockDoc: MockDoc, data: any, options?: any) {
    this.b.set(mockDoc.ref, data, options);
    return this;
  }
  update(mockDoc: MockDoc, data: any) {
    this.b.update(mockDoc.ref, data);
    return this;
  }`;

content = content.replace(
  /  set\(mockDoc: MockDoc, data: any, options\?: any\) \{\s*this\.b\.set\(mockDoc\.ref, data, options\);\s*return this;\s*\}/,
  bReplace
);

fs.writeFileSync('src/server/db.ts', content);
