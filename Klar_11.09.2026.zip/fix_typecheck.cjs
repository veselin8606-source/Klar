const fs = require('fs');

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = window\.location\.origin;\n/, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

let haptics = fs.readFileSync('src/lib/haptics.ts', 'utf8');
// Fix ts error
haptics = haptics.replace(/Argument of type 'string | null' is not assignable to parameter of type 'string'/, '');
// the error says: src/lib/haptics.ts(13,30): error TS2345: Argument of type 'string | null' is not assignable to parameter of type 'string'.
// meaning we need to handle null.
haptics = haptics.replace(/const storedVariant = localStorage\.getItem\('haptic_variant'\);/g, "const storedVariant = localStorage.getItem('haptic_variant') || 'subtle';");

// Fix map error on number | number[]
haptics = haptics.replace(/const scaledPattern = Array\.isArray\(finalPattern\) \? finalPattern\.map\(\(p: number\) => Math\.round\(p \* intensityMultiplier\)\) : Math\.round\(finalPattern \* intensityMultiplier\);/g, "const scaledPattern = Array.isArray(finalPattern) ? finalPattern.map((p: number) => Math.round(p * intensityMultiplier)) : Math.round((finalPattern as number) * intensityMultiplier);");
// Wait, the error is Property 'map' does not exist on type 'number | number[]'. We need to check if Array.isArray(finalPattern).
