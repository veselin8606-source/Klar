import fs from 'fs';
let code = fs.readFileSync('src/screens/Chats.tsx', 'utf8');

if (!code.includes('import { motion')) {
  code = code.replace('import { Link } from "react-router";', 'import { Link } from "react-router";\nimport { motion, AnimatePresence } from "motion/react";\nimport { useState } from "react";\nimport { Archive, Trash2 } from "lucide-react";');
}

const swipeableComponent = `
function SwipeableChat({ profile, idx, onRemove }: any) {
  return (
    <motion.div
      layout
      initial={{ opacity: 1, height: "auto" }}
      exit={{ opacity: 0, height: 0, overflow: "hidden", marginBottom: 0 }}
      className="relative rounded-2xl mb-4"
    >
      <div className="absolute inset-0 bg-red-500 rounded-2xl flex justify-end items-center px-6">
        <Trash2 className="text-white" size={24} />
      </div>
      <motion.div
        drag="x"
        dragConstraints={{ left: -100, right: 0 }}
        onDragEnd={(e, { offset, velocity }) => {
          if (offset.x < -80 || velocity.x < -500) {
            onRemove(profile.id);
          }
        }}
        className="relative bg-white dark:bg-stone-900 rounded-2xl shadow-sm border border-stone-200 dark:border-stone-800"
      >
        <Link to={\`/chat/\${profile.id}\`} className="flex items-center gap-4 p-4 hover:border-brand/50 dark:hover:border-brand-light/50 transition-colors group">
          <div className="relative">
            <img src={profile.photoUrl} alt={profile.name} className="w-16 h-16 rounded-full object-cover border border-stone-100 dark:border-stone-800" />
            <div className="absolute -bottom-1 -right-1 w-4 h-4 bg-green-500 border-2 border-white dark:border-stone-900 rounded-full"></div>
          </div>
          <div className="flex-1">
            <div className="flex justify-between items-start mb-1">
              <h3 className="font-medium text-lg text-stone-900 dark:text-stone-100">{profile.name}</h3>
              <span className="text-xs text-stone-400 dark:text-stone-500">{idx + 1}h</span>
            </div>
            <p className="text-stone-500 dark:text-stone-400 text-sm mb-2 truncate">Tippe, um ein Gespräch zu beginnen...</p>
            <div className="flex items-center gap-1 text-[10px] font-medium text-amber-600 dark:text-amber-500 uppercase tracking-wider">
              <Clock size={12} />
              <span>Verfällt in {72 - (idx * 2)}h</span>
            </div>
          </div>
          <div className="flex flex-col items-center justify-center">
             <div className="w-12 h-12 relative flex items-center justify-center">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
                  <path
                    className="text-stone-100 dark:text-stone-800"
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                  />
                  <path
                    className="text-brand dark:text-brand-light"
                    strokeDasharray={\`\${75 + idx * 5}, 100\`}
                    d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="3"
                  />
                </svg>
                <span className="absolute text-[10px] font-bold text-stone-700 dark:text-stone-300">{75 + idx * 5}%</span>
             </div>
             <span className="text-[8px] text-stone-500 font-medium uppercase mt-1">Fit</span>
          </div>
        </Link>
      </motion.div>
    </motion.div>
  );
}
`;

// Inject SwipeableChat
code = code.replace(/export default function Chats\(\) \{/, swipeableComponent + '\nexport default function Chats() {');

// Add state to Chats
code = code.replace(/export default function Chats\(\) \{/, 'export default function Chats() {\n  const [profiles, setProfiles] = useState(allProfiles);\n  const handleRemove = (id: string) => setProfiles(p => p.filter(x => x.id !== id));\n');

// Replace mapping loop
const oldLoop = /<div className="space-y-4">[\s\S]*?<\/div>\s*<\/div>\s*\);\s*\}/;
const newLoop = `<div className="">
        <AnimatePresence>
          {profiles.map((profile, i) => (
            <SwipeableChat key={profile.id} profile={profile} idx={i} onRemove={handleRemove} />
          ))}
        </AnimatePresence>
      </div>
    </div>
  );
}`;
code = code.replace(oldLoop, newLoop);

fs.writeFileSync('src/screens/Chats.tsx', code);
