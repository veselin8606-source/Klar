import fs from 'fs';
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');

// The regex replace in brutal_fix might have failed if the imports were on multiple lines.
// Let's just blindly inject the imports at the top of the file after standard react imports.
if (!prof.includes('import { Heart, MessageSquare, Star } from "lucide-react";')) {
    prof = prof.replace(
        /import React, \{ useState \} from 'react';\n/,
        "import React, { useState } from 'react';\nimport { Heart, MessageSquare, Star } from 'lucide-react';\n"
    );
}

// Ensure the other ones (lucide-react imports that were already there) aren't completely broken
if (!prof.includes('Heart, MessageSquare, Star')) {
    // If it still doesn't have it, just shove it at the absolute top
    prof = "import { Heart, MessageSquare, Star } from 'lucide-react';\n" + prof;
}

fs.writeFileSync('src/screens/Profile.tsx', prof);
