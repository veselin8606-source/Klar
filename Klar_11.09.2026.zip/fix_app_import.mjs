import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf8');
if (!content.includes('import { DashboardOnboarding }')) {
  content = content.replace("import { Sichtschutz } from './components/Sichtschutz';", "import { Sichtschutz } from './components/Sichtschutz';\nimport { DashboardOnboarding } from './components/DashboardOnboarding';");
  fs.writeFileSync('src/App.tsx', content);
}
