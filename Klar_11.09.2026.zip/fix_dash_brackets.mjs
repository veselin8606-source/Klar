import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
content = content.replace(/    \n      \{selectedProfile && <ProfileDetailModal profile=\{selectedProfile\} onClose=\{\(\) => setSelectedProfile\(null\)\} \/>\}\n/, "");
content = content.replace("  const [selectedProfile, setSelectedProfile] = useState<any>(null);\n", "");
content = content.replace(/<div className="absolute inset-0 bg-transparent z-10 cursor-pointer" onClick=\{\(\) => setSelectedProfile\(profile\)\} \/>\n            <div className="absolute inset-0 bg-gradient-to-t/g, `<div className="absolute inset-0 bg-gradient-to-t`);
content = content.replace(/    <>\n/g, "");
content = content.replace(/    <\/>\n/g, "");
fs.writeFileSync('src/screens/Dashboard.tsx', content);
