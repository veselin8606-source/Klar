import fs from 'fs';
let code = fs.readFileSync('src/screens/DatingRituals.tsx', 'utf8');
if (!code.includes('ConsistencyStreakWidget')) {
  console.log("No widget usage?");
} else if (!code.includes("import { ConsistencyStreakWidget")) {
  code = code.replace(
    "import { ArrowLeft", 
    "import { ConsistencyStreakWidget } from '../components/ConsistencyStreakWidget';\nimport { ArrowLeft"
  );
  fs.writeFileSync('src/screens/DatingRituals.tsx', code);
  console.log("Import added.");
}
