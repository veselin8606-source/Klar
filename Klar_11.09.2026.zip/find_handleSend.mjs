import fs from 'fs';
const text = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const lines = text.split('\n');
let balance = 0;
for (let i = 751; i < 882; i++) {
  let line = lines[i];
  let stripped = line.replace(/\/\/.*$/, ''); 
  for (let j = 0; j < stripped.length; j++) {
    if (stripped[j] === '{') balance++;
    if (stripped[j] === '}') balance--;
  }
}
console.log("Balance of handleSend at line 882:", balance);
