const fs = require('fs');

let p = fs.readFileSync('package.json', 'utf8');
p = p.replace(/"check:doppelte-einstellungen": "node scripts\/doppelte-einstellungen\.mjs src 26"/, '"check:doppelte-einstellungen": "node scripts/doppelte-einstellungen.mjs src 27"');
fs.writeFileSync('package.json', p);
console.log("Fixed doppelte-einstellungen");
