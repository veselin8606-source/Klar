import fs from 'fs';

let content = fs.readFileSync('server.ts', 'utf8');

const audioEndpoint = `
  app.post("/api/messages/send-audio", express.json({limit: '10mb'}), async (req, res) => {
    try {
      const db = (await import('./src/server/db')).getDb();
      const authHeader = req.headers.authorization;
      if (!authHeader) return res.status(401).send("Unauthorized");
      const token = authHeader.split(" ")[1];
      const { getAuth } = await import('firebase-admin/auth');
      const decoded = await getAuth().verifyIdToken(token);
      const meineUid = decoded.uid;

      const { chatId, audioBase64, mimeType } = req.body;
      if (!chatId || !audioBase64) return res.status(400).send("Missing fields");

      // For this prototype, we store base64 inline or simulate upload by returning a mock URL
      // Since we want to transcribe, let's call Gemini API directly
      let transcription = "Transkription nicht verfügbar.";
      const audioDataUri = \`data:\${mimeType || 'audio/webm'};base64,\${audioBase64}\`;

      if (process.env.GEMINI_API_KEY) {
        try {
          const { GoogleGenAI } = await import("@google/genai");
          const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
          
          // Using inline data for Gemini
          const response = await ai.models.generateContent({
             model: 'gemini-2.5-flash',
             contents: [
               "Bitte transkribiere diese Sprachnachricht in der Originalsprache.",
               {
                 inlineData: {
                   data: audioBase64,
                   mimeType: mimeType || 'audio/webm'
                 }
               }
             ]
          });
          if (response.text) {
             transcription = response.text.trim();
          }
        } catch (e) {
          console.error("Gemini Transcription error:", e);
        }
      }

      const messageId = "msg_" + Date.now();
      const messageRef = db.collection("chats").doc(chatId).collection("messages").doc(messageId);
      const chatRef = db.collection("chats").doc(chatId);
      const { FieldValue } = await import('./src/server/db');
      const createdAt = FieldValue.serverTimestamp();

      const batch = db.batch();
      batch.set(messageRef, {
        chatId,
        senderId: meineUid,
        text: 'Sprachnachricht',
        audioUrl: audioDataUri, // Using Data URI for prototype playback
        audioTranscription: transcription,
        createdAt,
        translationStatus: 'none'
      });
      batch.update(chatRef, {
        lastMessage: '🎙️ Sprachnachricht',
        lastMessageAt: createdAt
      });
      await batch.commit();

      res.status(200).json({ success: true, messageId, transcription });
    } catch (e: any) {
      console.error('Audio message error:', e);
      res.status(500).json({ error: "Fehler beim Senden" });
    }
  });
`;

content = content.replace(
  '  app.post("/api/messages/send", express.json(), async (req, res) => {',
  audioEndpoint + '\n  app.post("/api/messages/send", express.json(), async (req, res) => {'
);

fs.writeFileSync('server.ts', content);
