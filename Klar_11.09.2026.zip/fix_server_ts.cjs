const fs = require('fs');
let server = fs.readFileSync('server.ts', 'utf8');

// fix imports line 46-56
server = server.replace(/import \{\n\s*COACH_IMPULS[\s\S]*?BIO_WERTE_HINWEISE,\n\} from ".\/src\/server\/kuratiert";/, '');
server = server.replace(/import \{ lies als liesSpeicher, schreibe als schreibeSpeicher \} from ".\/src\/server\/zwischenspeicher";/, '');

// remove unused isQuotaExceeded
server = server.replace(/function isQuotaExceeded\(e: unknown\): boolean \{[\s\S]*?return false;\n\}\n/g, '');

// fix compatibility-radar meineUid
server = server.replace(/const meineUid = \(req as any\)\.user\?\.uid as string;\n\s*const \{ userInterests/g, 'const { userInterests');

// fix prompt -> String(message) in /api/gemini/daily-coach-insight
server = server.replace(/encryptedInput: encryptLog\(prompt\),/g, 'encryptedInput: encryptLog(String(req.body.message)),');

// fix chatId in send
server = server.replace(/const \{ chatId, text,/g, 'const { text,');

// fix send-audio
server = server.replace(/const \{ chatId, audioBase64,/g, 'const { audioBase64,');
server = server.replace(/const model = genai\.getGenerativeModel\(\{ model: "gemini-1\.5-pro" \}\);\n\s*const result = await model\.generateContent\(\[\n\s*"Transkribiere diese Sprachnachricht wortgetreu auf Deutsch\. Gib nur das Transkript ohne weitere Erklärungen zurück\.",\n\s*\{ inlineData: \{ mimeType: mimeType \|\| "audio\/webm", data: audioBase64 \} \}\n\s*\]\);/g, 
`const result = await ai.models.generateContent({
        model: "gemini-3.5-flash-lite",
        contents: [
          "Transkribiere diese Sprachnachricht wortgetreu auf Deutsch. Gib nur das Transkript ohne weitere Erklärungen zurück.",
          { inlineData: { mimeType: mimeType || "audio/webm", data: audioBase64 } }
        ]
      });`);
// fix genai import or references? 

// fix verifiziereToken
server = server.replace(/app\.post\("\/api\/messages\/mark-read", async \(req, res\) => \{\n\s*const \{ chatId, messageIds \} = req\.body;\n\s*const \{ meineUid, fehler \} = await verifiziereToken\(req\.headers\.authorization\);\n\s*if \(fehler \|\| !meineUid\) return res\.status\(401\)\.json\(\{ error: "Unauthorized" \}\);/g,
`app.post("/api/messages/mark-read", requireAuth, async (req, res) => {
    const { chatId, messageIds } = req.body;
    const meineUid = (req as any).user.uid;`);
server = server.replace(/app\.delete\("\/api\/account", async \(req, res\) => \{\n\s*const \{ meineUid, fehler \} = await verifiziereToken\(req\.headers\.authorization\);\n\s*if \(fehler \|\| !meineUid\) return res\.status\(401\)\.json\(\{ error: "Unauthorized" \}\);/g,
`app.delete("/api/account", requireAuth, async (req, res) => {
    const meineUid = (req as any).user.uid;`);

// fix error unknown in mark-read
server = server.replace(/\} catch \(e\) \{\n\s*res\.status\(500\)\.json\(\{ error: e\.message \}\);\n\s*\}/g,
`} catch (e) {
      res.status(500).json({ error: (e as Error).message });
    }`);

fs.writeFileSync('server.ts', server);

let zwischen = fs.readFileSync('src/server/zwischenspeicher.ts', 'utf8');
zwischen = zwischen.replace(/\.ts"/g, '"');
fs.writeFileSync('src/server/zwischenspeicher.ts', zwischen);
console.log("TS fixed");
