import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const regex = /const batch = writeBatch\(db\);[\s\S]*?if \(hasUnread\) \{[\s\S]*?\}/m;

const replacement = `
      const unreadIds: string[] = [];
      snapshot.forEach(docSnap => {
        const data = docSnap.data();
        if (data.senderId !== auth.currentUser?.uid && !data.isRead) {
          unreadIds.push(docSnap.id);
        }
        updates[docSnap.id] = data.isRead;
      });

      if (unreadIds.length > 0) {
        auth.currentUser.getIdToken().then(token => {
          fetch('/api/messages/mark-read', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json', 'Authorization': \`Bearer \${token}\` },
            body: JSON.stringify({ chatId: id, messageIds: unreadIds })
          }).catch(e => {
            // Error wird hier nur geloggt, UI sollte nicht blockieren
          });
        });
      }
`;

content = content.replace(regex, replacement.trim());
// Wait, I should double check what I replaced.
// "const updates: Record<string, boolean> = {};" is before it.
fs.writeFileSync('src/screens/ChatView.tsx', content);
