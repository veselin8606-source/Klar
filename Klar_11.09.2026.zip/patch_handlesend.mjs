import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

const target = `    setInput('');
    setMessages(prev => [...prev, {
      role: 'user',
      text: input,
      isRead: false
    }]);
    setInput("");
    localStorage.removeItem(\`klar_chat_draft_\${id}\`);`;

const replacement = `    setInput('');
    
    // Optimistic UI
    setMessages(prev => [...prev, {
      role: 'user',
      text: input,
      isRead: false
    }]);
    setInput("");
    localStorage.removeItem(\`klar_chat_draft_\${id}\`);

    // Epic 2 & 3: API call for real chats
    if (!istBeispielGespraech && auth.currentUser) {
      auth.currentUser.getIdToken().then(token => {
        fetch('/api/messages/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': \`Bearer \${token}\`
          },
          body: JSON.stringify({ chatId: id, text: input })
        }).catch(err => {
          console.error("Failed to send message via API", err);
        });
      });
    }`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/screens/ChatView.tsx', code);
  console.log("Patched ChatView.tsx successfully.");
} else {
  console.log("Could not find the target code in ChatView.tsx.");
}
