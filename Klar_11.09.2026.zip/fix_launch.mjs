import fs from 'fs';
let code = fs.readFileSync('src/components/LaunchPromoWidget.tsx', 'utf8');

code = code.replace(
  `} catch (e) {
      console.error(e);
      setResult({ status: 'error' });
    } finally {`,
  `} catch (e: any) {
      setResult({ status: 'error', months: 0 });
    } finally {`
);

code = code.replace(
  `  if (result?.status === 'success') {`,
  `  if (result?.status === 'error') {
    return (
      <div className="bg-red-50 border border-red-200 p-4 rounded-xl mb-4 flex items-start gap-3">
        <AlertCircle className="text-red-500 shrink-0 mt-0.5" size={20} />
        <div>
          <p className="font-medium text-ink">Fehler aufgetreten</p>
          <p className="text-sm text-muted">
            Bitte versuche es später noch einmal.
          </p>
        </div>
      </div>
    );
  }

  if (result?.status === 'success') {`
);

code = code.replace(
  `bg-gradient-to-r from-accent/10 to-accent-quiet border border-accent/30 p-4 rounded-xl mb-4 relative overflow-hidden`,
  `bg-accent-quiet border border-accent/30 p-4 rounded-xl mb-4 relative overflow-hidden`
);

fs.writeFileSync('src/components/LaunchPromoWidget.tsx', code);
console.log("Done");
