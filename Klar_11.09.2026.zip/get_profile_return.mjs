import fs from 'fs';
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf-8');
const pos = code.indexOf('return (');
if (pos !== -1) {
  console.log(code.substring(pos, pos + 2000));
}
