import fs from 'fs';
let code = fs.readFileSync('firestore.rules', 'utf-8');

const oldMessageRule = `allow create: if signedIn()
                      && !istGast()
                      && request.auth.uid in get(/databases/$(database)/documents/chats/$(chatId)).data.participants 
                      && isValidMessage(request.resource.data, get(/databases/$(database)/documents/chats/$(chatId)).data);`;

const newMessageRule = `// Epic 2: Live Translation - only server creates messages now
        allow create: if false;`;

if (code.includes(oldMessageRule)) {
  code = code.replace(oldMessageRule, newMessageRule);
  fs.writeFileSync('firestore.rules', code);
  console.log("Replaced successfully.");
} else {
  console.log("Could not find the rule.");
}
