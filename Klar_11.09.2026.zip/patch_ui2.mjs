import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

const targetStr = '<div className={`flex-1 overflow-y-auto p-4 space-y-4 relative transition-colors duration-500 ${isFocusMode ? \'bg-indigo-900/5 dark:bg-indigo-400/5\' : \'\'}`}>';
if (code.includes(targetStr)) {
  code = code.replace(targetStr, `
      {gateZustand !== "offen" ? (
        <div className="flex-1 overflow-y-auto bg-stone-50 dark:bg-black relative px-4 flex flex-col items-center justify-center min-h-[50vh]">
          <div className="bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-3xl p-6 shadow-xl max-w-md w-full text-center">
            <h2 className="text-2xl font-serif text-stone-900 dark:text-stone-100 mb-2">Icebreaker-Gate</h2>
            <p className="text-sm text-stone-500 dark:text-stone-400 mb-6">
              Beide beantworten 2 Fragen. Erst danach öffnet sich der freie Chat.
            </p>
            
            {gateZustand === "lade" && (
              <div className="animate-pulse space-y-4">
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-3/4 mx-auto"></div>
                <div className="h-4 bg-stone-200 dark:bg-stone-800 rounded w-1/2 mx-auto"></div>
              </div>
            )}
            
            {gateZustand === "du_bist_dran" && (
              <div>
                <p className="font-medium text-stone-800 dark:text-stone-200 mb-4">
                  {gateDaten?.fragen?.[gateDaten?.meine || 0] || "Was macht dich wirklich glücklich?"}
                </p>
                <textarea
                  value={gateInput}
                  onChange={(e) => setGateInput(e.target.value)}
                  placeholder="Deine Antwort..."
                  className="w-full bg-stone-50 dark:bg-stone-800 border border-stone-200 dark:border-stone-700 rounded-xl p-4 text-sm mb-4 min-h-[100px] resize-none focus:outline-none focus:ring-2 focus:ring-brand"
                />
                {gateFehler && <p className="text-rose-500 text-sm mb-4">{gateFehler}</p>}
                <button
                  onClick={onGateSubmit}
                  disabled={!gateInput.trim() || gateSubmitting}
                  className="w-full bg-brand text-white font-medium rounded-full py-3 disabled:opacity-50 transition-colors hover:bg-brand-light"
                >
                  {gateSubmitting ? "Senden..." : "Antworten"}
                </button>
              </div>
            )}

            {gateZustand === "wartet_auf_andere" && (
              <div className="py-8">
                <div className="w-16 h-16 bg-stone-100 dark:bg-stone-800 rounded-full flex items-center justify-center mx-auto mb-4 animate-bounce">
                  <span className="text-2xl">⏳</span>
                </div>
                <h3 className="font-medium text-stone-800 dark:text-stone-200">Wartet auf Antwort</h3>
                <p className="text-sm text-stone-500 mt-2">Du hast deine Fragen beantwortet. Sobald die andere Person nachzieht, öffnet sich der Chat.</p>
              </div>
            )}
          </div>
        </div>
      ) : (
        <>
          <div className={\`flex-1 overflow-y-auto p-4 space-y-4 relative transition-colors duration-500 \${isFocusMode ? 'bg-indigo-900/5 dark:bg-indigo-400/5' : ''}\`}>
`);

  // Close the <> wrapper
  // The end of the main column is right before DatePrepChecklistModal
  code = code.replace('<DatePrepChecklistModal', '      </>\n      )}\n      <DatePrepChecklistModal');
}

fs.writeFileSync('src/screens/ChatView.tsx', code);
