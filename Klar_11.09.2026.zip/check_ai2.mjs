import fs from 'fs';
const text = fs.readFileSync('server.ts', 'utf8');
const lines = text.split('\n');
for(let i=0; i<lines.length; i++) {
  if (lines[i].includes('generateContent(')) {
    // peek ahead 50 lines
    let block = lines.slice(i, i+50).join('\n');
    let endIndex = block.indexOf('})');
    if (endIndex !== -1) {
      let callStr = block.substring(0, endIndex);
      if (!callStr.includes('responseSchema')) {
        console.log("Line " + (i+1) + " missing responseSchema");
      }
    }
  }
}
