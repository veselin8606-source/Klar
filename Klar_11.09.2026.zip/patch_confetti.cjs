const fs = require('fs');

function replaceInFile(filepath, regex, replacement) {
  if (fs.existsSync(filepath)) {
    let content = fs.readFileSync(filepath, 'utf8');
    content = content.replace(regex, replacement);
    fs.writeFileSync(filepath, content);
  }
}

// InsightsChart
replaceInFile('src/components/InsightsChart.tsx', /import confetti from 'canvas-confetti';\n/, '');
replaceInFile('src/components/InsightsChart.tsx', /confetti\(\{[\s\S]*?\}\);\n/, '');

// WeeklyMilestoneRevealWidget
replaceInFile('src/components/WeeklyMilestoneRevealWidget.tsx', /import \{ Confetti \} from "\.\/Confetti";\n/, '');
replaceInFile('src/components/WeeklyMilestoneRevealWidget.tsx', /<Confetti count=\{60\} \/>\n/, '');

// SuccessDashboardWidget
replaceInFile('src/components/SuccessDashboardWidget.tsx', /import\('canvas-confetti'\)\.then\(\(confetti\) => \{[\s\S]*?\}\);\n/, '');

// ProfileCheckWidget
replaceInFile('src/components/ProfileCheckWidget.tsx', /import confetti from "canvas-confetti";\n/, '');
replaceInFile('src/components/ProfileCheckWidget.tsx', /confetti\(\{[\s\S]*?\}\);\n/, '');

// DatingTimelineWidget
replaceInFile('src/components/DatingTimelineWidget.tsx', /import \{ Confetti \} from "\.\/Confetti";\n/, '');
replaceInFile('src/components/DatingTimelineWidget.tsx', /const \[showConfetti, setShowConfetti\] = useState\(false\);\n/, '');
replaceInFile('src/components/DatingTimelineWidget.tsx', /setShowConfetti\(true\);\n/, '');
replaceInFile('src/components/DatingTimelineWidget.tsx', /\{showConfetti && <Confetti  onComplete=\{.*?\} \/>\}\n/, '');

// DatingGoalRoadmapWidget
replaceInFile('src/components/DatingGoalRoadmapWidget.tsx', /import \{ Confetti \} from "\.\/Confetti";\n/, '');
replaceInFile('src/components/DatingGoalRoadmapWidget.tsx', /const \[showConfetti, setShowConfetti\] = useState\(false\);\n/, '');
replaceInFile('src/components/DatingGoalRoadmapWidget.tsx', /setShowConfetti\(true\);\n/, '');
replaceInFile('src/components/DatingGoalRoadmapWidget.tsx', /\{showConfetti && <Confetti count=\{100\} duration=\{4000\} onComplete=\{.*?\} \/>\}\n/, '');

// Dashboard
replaceInFile('src/screens/Dashboard.tsx', /import \{ Confetti \} from "\.\.\/components\/Confetti";\n/, '');
replaceInFile('src/screens/Dashboard.tsx', /const \[showConfetti, setShowConfetti\] = useState\(false\);\n/, '');
replaceInFile('src/screens/Dashboard.tsx', /setShowConfetti\(true\);\s*setTimeout\(\(\) => setShowConfetti\(false\), 3000\);/g, '');
replaceInFile('src/screens/Dashboard.tsx', /\{showConfetti && <Confetti count=\{100\} \/>\}\n/g, '');

// MeilensteineAlle
replaceInFile('src/screens/MeilensteineAlle.tsx', /import \{ Confetti \} from '\.\.\/components\/Confetti';\n/, '');
replaceInFile('src/screens/MeilensteineAlle.tsx', /const \[showConfetti, setShowConfetti\] = useState\(false\);\n/, '');
replaceInFile('src/screens/MeilensteineAlle.tsx', /\{showConfetti && <Confetti \/>\}\n/g, '');
replaceInFile('src/screens/MeilensteineAlle.tsx', /setShowConfetti\(true\);\s*setTimeout\(\(\) => setShowConfetti\(false\), 3000\);/g, '');

// Haptics & Vibration 
replaceInFile('src/components/DatingTimelineWidget.tsx', /if \(typeof navigator !== 'undefined' && navigator\.vibrate\) navigator\.vibrate\(\[[0-9, ]+\]\);\n/g, '');
replaceInFile('src/components/DatingTimelineWidget.tsx', /if \(typeof navigator !== 'undefined' && navigator\.vibrate\) \{[\s\S]*?\}\n/g, '');
replaceInFile('src/components/DatingTimelineWidget.tsx', /if \(typeof navigator !== 'undefined' && navigator\.vibrate\) navigator\.vibrate\([0-9]+\);\n/g, '');

replaceInFile('src/components/DatingGoalRoadmapWidget.tsx', /if \(typeof navigator !== 'undefined' && navigator\.vibrate\) navigator\.vibrate\([0-9]+\);\n/g, '');
replaceInFile('src/components/MiniCalendarWidget.tsx', /if \(typeof navigator !== 'undefined' && navigator\.vibrate\) navigator\.vibrate\([0-9]+\);\n/g, '');

replaceInFile('src/screens/Dashboard.tsx', /if \("vibrate" in navigator\) \{[\s\S]*?\}\n/g, '');
replaceInFile('src/screens/ChatView.tsx', /\/\/       if \('vibrate' in navigator\) navigator\.vibrate\(50\);\n/g, '');

console.log("Done patching.");
