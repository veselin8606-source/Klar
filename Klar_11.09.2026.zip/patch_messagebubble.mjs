import fs from 'fs';

const code = `
import { useState } from 'react';
import { CheckCheck, AlertTriangle, Languages } from 'lucide-react';
import type { ChatMessage } from '../screens/ChatView';

interface MessageBubbleProps {
  msg: ChatMessage;
}

export function MessageBubble({ msg }: MessageBubbleProps) {
  const isUser = msg.role === 'user';
  // Use textOriginal if available, fallback to legacy text
  const original = msg.originalText || msg.text;
  
  // Is this message translated by the backend?
  const hasTranslation = !!msg.textTranslated;
  
  // Zustand A (übersetzt) / Zustand B (Original)
  const [showOriginal, setShowOriginal] = useState(false);

  const displayString = (hasTranslation && !showOriginal) ? msg.textTranslated : original;

  return (
    <div className={\`max-w-[80%] rounded-2xl px-4 py-2 \${
      isUser 
        ? 'bg-brand dark:bg-brand-light text-white dark:text-stone-900 rounded-tr-sm' 
        : 'bg-white dark:bg-stone-900 border border-stone-100 dark:border-stone-800 rounded-tl-sm'
    }\`}>
      <div 
        className="text-sm"
        aria-label={hasTranslation && !showOriginal ? \`Übersetzte Nachricht: \${displayString}\` : undefined}
      >
        {displayString}
      </div>

      {hasTranslation && (
        <div className="mt-1 flex items-center justify-between">
          <button
            onClick={() => setShowOriginal(!showOriginal)}
            aria-expanded={!showOriginal}
            className="text-[10px] opacity-70 hover:opacity-100 flex items-center gap-1 transition-opacity focus:outline-none focus:ring-1 focus:ring-current rounded"
          >
            <Languages size={10} aria-hidden="true" />
            <span>
              {showOriginal ? "Übersetzung anzeigen" : \`[\${(msg.sourceLang || 'AUTO').toUpperCase()}] Original\`}
            </span>
          </button>
        </div>
      )}

      {msg.translationError && (
        <div className="mt-1 flex items-center gap-1 text-[10px] text-rose-500/90" title="Übersetzung fehlgeschlagen">
          <AlertTriangle size={12} aria-hidden="true" />
        </div>
      )}

      {isUser && (
        <div className="flex justify-end mt-1">
          <CheckCheck size={14} className={msg.isRead ? "text-blue-500" : "text-brand-light/70 dark:text-brand/50"} />
        </div>
      )}
    </div>
  );
}
`;

fs.writeFileSync('src/components/MessageBubble.tsx', code);
console.log("Replaced MessageBubble.tsx");
