import fs from 'fs';

let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const audioTypes = `
  audioUrl?: string;
  audioTranscription?: string;
`;
content = content.replace(
  "translated_text?: string;",
  "translated_text?: string;\n" + audioTypes
);

const audioState = `
  const [isRecording, setIsRecording] = useState(false);
  const [mediaRecorder, setMediaRecorder] = useState<MediaRecorder | null>(null);
  const [isProcessingAudio, setIsProcessingAudio] = useState(false);

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const recorder = new MediaRecorder(stream);
      let chunks: BlobPart[] = [];
      
      recorder.ondataavailable = e => chunks.push(e.data);
      recorder.onstop = async () => {
        const blob = new Blob(chunks, { type: recorder.mimeType });
        processAudioMessage(blob, recorder.mimeType);
        stream.getTracks().forEach(t => t.stop());
      };
      
      recorder.start();
      setMediaRecorder(recorder);
      setIsRecording(true);
    } catch (e) {
      console.error('Mic error:', e);
      setSprachHinweis('Mikrofon konnte nicht gestartet werden.');
    }
  };

  const stopRecording = () => {
    if (mediaRecorder && mediaRecorder.state !== 'inactive') {
      mediaRecorder.stop();
      setIsRecording(false);
    }
  };

  const processAudioMessage = async (blob: Blob, mimeType: string) => {
    setIsProcessingAudio(true);
    try {
      const reader = new FileReader();
      reader.onloadend = async () => {
        const base64data = (reader.result as string).split(',')[1];
        const token = auth.currentUser ? await auth.currentUser.getIdToken() : '';
        
        // Show optimistic UI for audio message
        const tempId = Date.now().toString();
        const localAudioUrl = URL.createObjectURL(blob);
        setMessages(prev => [...prev, {
          id: tempId,
          role: 'user',
          text: 'Sprachnachricht',
          audioUrl: localAudioUrl,
          audioTranscription: 'Wird transkribiert...',
          isRead: false
        }]);

        const res = await fetch('/api/messages/send-audio', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': \`Bearer \${token}\`
          },
          body: JSON.stringify({ chatId: id, audioBase64: base64data, mimeType })
        });
        
        if (res.ok) {
           // Rely on firestore snapshot listener to update it, or reload
           // For prototype, just let the snapshot update it
        }
      };
      reader.readAsDataURL(blob);
    } catch (e) {
      console.error('Audio send error', e);
    } finally {
      setIsProcessingAudio(false);
    }
  };
`;

content = content.replace(
  "const [sprachHinweis, setSprachHinweis] = useState('');",
  "const [sprachHinweis, setSprachHinweis] = useState('');\n" + audioState
);

const micButton = `
            {isRecording ? (
              <button
                type="button"
                onClick={stopRecording}
                className="w-10 h-10 rounded-full flex justify-center items-center bg-red-500 text-white shrink-0 animate-pulse"
                aria-label="Aufnahme stoppen"
              >
                <div className="w-3 h-3 bg-white rounded-sm" />
              </button>
            ) : (
              <button
                type="button"
                onClick={startRecording}
                disabled={isProcessingAudio}
                className="w-10 h-10 rounded-full flex justify-center items-center bg-stone-100 dark:bg-stone-800 text-stone-500 hover:text-brand dark:hover:text-brand-light transition-colors shrink-0 disabled:opacity-50"
                aria-label="Sprachnachricht aufnehmen"
                title="Sprachnachricht aufnehmen"
              >
                <Mic size={18} />
              </button>
            )}
`;

content = content.replace(
  /<button\s*type="button"\s*onClick=\{toggleSpracheingabe\}[\s\S]*?<\/button>/m,
  "$&" + "\n" + micButton
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
