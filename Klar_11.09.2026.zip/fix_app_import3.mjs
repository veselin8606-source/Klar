import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf8');

// The regex might have failed. Let's explicitly inject it after another known import.
if (!content.includes("import { DashboardOnboarding }")) {
  content = content.replace(
    "import { Sichtschutz } from './components/Sichtschutz';", 
    "import { Sichtschutz } from './components/Sichtschutz';\nimport { DashboardOnboarding } from './components/DashboardOnboarding';"
  );
  fs.writeFileSync('src/App.tsx', content);
}
