sed -i 's/const PORT = 3000;/const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;/g' server.ts
