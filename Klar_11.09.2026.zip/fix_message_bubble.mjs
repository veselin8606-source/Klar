import fs from 'fs';

const content = `import { useState } from 'react';
import { CheckCheck, AlertTriangle, Languages, ChevronDown, ChevronUp } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import type { ChatMessage } from '../screens/ChatView';

interface MessageBubbleProps {
  msg: ChatMessage;
}

export function MessageBubble({ msg }: MessageBubbleProps) {
  const isUser = msg.role === 'user';
  // Verwende textOriginal falls vorhanden (neues System), ansonsten fallback
  const original = msg.textOriginal || msg.text;
  
  // Status check for Gemini Async Translation
  const isPending = msg.translationStatus === 'pending';
  const isFailed = msg.translationStatus === 'failed';
  const hasTranslation = !!msg.textTranslated && msg.translationStatus === 'completed';
  
  // Sichtbarkeit der Uebersetzung toggeln (Standard: true, wenn verfuegbar)
  const [showTranslation, setShowTranslation] = useState(true);

  let timeString = '';
  if ((msg as any).createdAt) {
    const d = new Date((msg as any).createdAt);
    const today = new Date();
    if (d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear()) {
      timeString = d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    } else {
      timeString = d.toLocaleDateString('de-DE', { day: '2-digit', month: '2-digit' }) + ' ' + d.toLocaleTimeString('de-DE', { hour: '2-digit', minute: '2-digit' });
    }
  }

  return (
    <div className={\`max-w-[80%] rounded-2xl px-4 py-3 \${
      isUser 
         ? 'bg-brand dark:bg-brand-light text-white dark:text-stone-900 rounded-tr-sm' 
         : 'bg-white dark:bg-stone-900 border border-stone-200 dark:border-stone-800 rounded-tl-sm text-stone-900 dark:text-stone-100'
    }\`}>
      <div className="relative">
        <p className="text-[15px] leading-relaxed">{original}</p>
        
        {isPending && !isUser && (
          <span className="inline-flex items-center mt-1 text-[10px] text-stone-400 dark:text-stone-500 animate-pulse uppercase tracking-wide font-medium">
             translating...
          </span>
        )}
        
        {isFailed && !isUser && (
          <span className="inline-flex items-center mt-1 gap-1 text-[10px] text-rose-500/90 uppercase tracking-wide font-medium" title="Übersetzung fehlgeschlagen">
             <AlertTriangle size={12} aria-hidden="true" />
             Translation Error
          </span>
        )}
      </div>

      {!isUser && hasTranslation && (
        <div className="flex flex-col relative mt-1">
          <AnimatePresence>
            {showTranslation && (
              <motion.div 
                initial={{ opacity: 0, height: 0, marginTop: 0 }}
                animate={{ opacity: 1, height: 'auto', marginTop: 8 }}
                exit={{ opacity: 0, height: 0, marginTop: 0 }}
                className="border-t border-stone-200/60 dark:border-stone-700/60 pt-2"
              >
                <div className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-wider text-stone-400 dark:text-stone-500 mb-1">
                   <Languages size={12} />
                   <span>Übersetzung (\${(msg.targetLang || 'AUTO').toUpperCase()})</span>
                </div>
                <p className="text-[15px] italic leading-relaxed text-stone-600 dark:text-stone-300">
                  {msg.textTranslated}
                </p>
              </motion.div>
            )}
          </AnimatePresence>

          <button 
            onClick={() => setShowTranslation(!showTranslation)}
            aria-label={showTranslation ? "Übersetzung ausblenden" : "Übersetzung anzeigen"}
            className="absolute -bottom-1 -right-2 translate-y-full bg-white dark:bg-stone-800 border border-stone-200 dark:border-stone-700 shadow-sm rounded-full p-1.5 text-stone-400 hover:text-stone-700 dark:hover:text-stone-200 transition-colors flex items-center gap-1 z-10"
          >
            <Languages size={12} />
            {showTranslation ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
          </button>
        </div>
      )}

      <div className="flex justify-end items-center mt-2 gap-1.5">
        <span className={\`text-[10px] \${isUser ? 'opacity-90' : 'text-stone-400'}\`}>{timeString}</span>
        {isUser && <CheckCheck size={14} className={msg.isRead ? "text-stone-100 dark:text-stone-800" : "opacity-70"} />}
      </div>
    </div>
  );
}
`;

fs.writeFileSync('src/components/MessageBubble.tsx', content);
