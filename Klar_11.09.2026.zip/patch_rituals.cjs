const fs = require('fs');
let code = fs.readFileSync('src/screens/DatingRituals.tsx', 'utf-8');

if (!code.includes('ConsistencyStreakWidget')) {
  code = code.replace(
    'import { motion, AnimatePresence } from "motion/react";',
    'import { motion, AnimatePresence } from "motion/react";\nimport { ConsistencyStreakWidget } from "../components/ConsistencyStreakWidget";'
  );
  
  // Track ritual completion
  const triggerLogic = `
  const markRitualCompleted = () => {
    try {
      const saved = localStorage.getItem('klar_rituals_streak');
      let count = 1;
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (saved) {
        const data = JSON.parse(saved);
        const lastDate = new Date(data.lastDate);
        lastDate.setHours(0, 0, 0, 0);
        
        const diffTime = today.getTime() - lastDate.getTime();
        const diffDays = Math.round(diffTime / (1000 * 60 * 60 * 24));
        
        if (diffDays === 0) {
          return; // Already completed today
        } else if (diffDays === 1) {
          count = data.count + 1;
        }
      }
      
      localStorage.setItem('klar_rituals_streak', JSON.stringify({ count, lastDate: today.toISOString() }));
      window.dispatchEvent(new Event('klar_ritual_completed'));
    } catch(e) {}
  };
`;
  
  code = code.replace(
    'const addGratitude = () => {',
    triggerLogic + '\n  const addGratitude = () => {\n    markRitualCompleted();'
  );
  
  code = code.replace(
    'const stopExercise = () => {',
    'const stopExercise = () => {\n    if (sessionTimeLeft < 150) markRitualCompleted(); // Mark complete if they did some of it'
  );
  
  code = code.replace(
    '<div className="space-y-4">',
    '<ConsistencyStreakWidget />\n        <div className="space-y-4">'
  );
  
  fs.writeFileSync('src/screens/DatingRituals.tsx', code);
}
