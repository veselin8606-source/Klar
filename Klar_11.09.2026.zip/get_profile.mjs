import fs from 'fs';
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf-8');
const pos = code.indexOf('export default function Profile');
if (pos !== -1) {
  const substr = code.substring(pos, pos + 3000);
  console.log(substr);
}
