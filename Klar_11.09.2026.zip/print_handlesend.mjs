import fs from 'fs';
import ts from 'typescript';

const code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const sourceFile = ts.createSourceFile('ChatView.tsx', code, ts.ScriptTarget.Latest, true, ts.ScriptKind.TSX);

function visit(node) {
  if (node.kind === ts.SyntaxKind.VariableDeclaration && node.name && node.name.text === 'handleSend') {
    console.log("handleSend ends at", node.getEnd());
    console.log("Source snippet around end:", code.substring(node.getEnd() - 20, node.getEnd() + 20));
  }
  ts.forEachChild(node, visit);
}
visit(sourceFile);
