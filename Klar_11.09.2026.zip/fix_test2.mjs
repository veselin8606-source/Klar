import fs from 'fs';
let content = fs.readFileSync('src/server/zwischenspeicher.ts', 'utf8');
content = content.replace("import { getDb as getFirestore } from './db';", "import { getDb as getFirestore } from './db.ts';");
content = content.replace("import { ZWISCHENSPEICHER_HOECHSTALTER_STUNDEN } from './kiPolitik';", "import { ZWISCHENSPEICHER_HOECHSTALTER_STUNDEN } from './kiPolitik.ts';");
fs.writeFileSync('src/server/zwischenspeicher.ts', content);
