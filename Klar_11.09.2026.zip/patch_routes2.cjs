const fs = require("fs");
let content = fs.readFileSync("server.ts", "utf8");

content = content.replace(
  `      const antwort = await beantworte("/api/gemini/dating-readiness", () => ai.models.generateContent({
        model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
        contents: [{ role: "user", parts: [{ text: \`Goals: \${goals}
Recent Activity: \${recentActivity}\` }] }],
        config: {
          systemInstruction: "You are a dating coach. Provide a daily wisdom and actionable advice based on the user's goals and recent activity.",
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              wisdom: { type: "string", description: "A short inspiring dating wisdom for the day" },
              actionableAdvice: { type: "string", description: "One practical actionable advice" }
            }
          }
        }
      }));`,
  `      const antwort = await beantworte(
        "/api/gemini/dating-readiness",
        () => ai.models.generateContent({
          model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
          contents: [{ role: "user", parts: [{ text: \`Goals: \${goals}\\nRecent Activity: \${recentActivity}\` }] }],
          config: {
            systemInstruction: "You are a dating coach. Provide a daily wisdom and actionable advice based on the user's goals and recent activity.",
            responseMimeType: "application/json",
            responseSchema: {
              type: "object",
              properties: {
                wisdom: { type: "string", description: "A short inspiring dating wisdom for the day" },
                actionableAdvice: { type: "string", description: "One practical actionable advice" }
              }
            }
          }
        }),
        {
          kuratiert: {
            wisdom: "Der richtige Moment ist nicht dann, wenn alles perfekt ist, sondern wenn du bereit bist, dich auf Neues einzulassen.",
            actionableAdvice: "Nimm dir heute Zeit für dich selbst, bevor du neue Kontakte knüpfst."
          }
        }
      );`
);

content = content.replace(
  `      const antwort = await beantworte("/api/gemini/daily-coach-insight", () => ai.models.generateContent({
        model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
        contents: [{ role: "user", parts: [{ text: \`Goals: \${userGoals}
Recent Activity: \${recentActivity}\` }] }],
        config: {
          systemInstruction: "You are a dating coach. Provide a short, actionable daily insight for the user.",
          responseMimeType: "application/json",
          responseSchema: {
            type: "object",
            properties: {
              insight: { type: "string", description: "A 1-2 sentence tip tailored to the user's situation" }
            }
          }
        }
      }));`,
  `      const antwort = await beantworte(
        "/api/gemini/daily-coach-insight",
        () => ai.models.generateContent({
          model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
          contents: [{ role: "user", parts: [{ text: \`Goals: \${userGoals}\\nRecent Activity: \${recentActivity}\` }] }],
          config: {
            systemInstruction: "You are a dating coach. Provide a short, actionable daily insight for the user.",
            responseMimeType: "application/json",
            responseSchema: {
              type: "object",
              properties: {
                insight: { type: "string", description: "A 1-2 sentence tip tailored to the user's situation" }
              }
            }
          }
        }),
        {
          kuratiert: {
            insight: "Geh heute offen und ohne Erwartungen in neue Gespräche – Authentizität wirkt am stärksten."
          }
        }
      );`
);

fs.writeFileSync("server.ts", content);
