const fs = require('fs');

let content = fs.readFileSync('src/App.tsx', 'utf8');
content = content.replace(/<GlobalErrorBoundary>/g, '<Sentry.ErrorBoundary>');
content = content.replace(/<\/GlobalErrorBoundary>/g, '</Sentry.ErrorBoundary>');
content = content.replace(/import \{ GlobalErrorBoundary \} from '.\/components\/GlobalErrorBoundary';\n/g, "import * as Sentry from '@sentry/react';\n");
fs.writeFileSync('src/App.tsx', content);

let profile = fs.readFileSync('src/components/ProfileCheckWidget.tsx', 'utf8');
profile = profile.replace(/const origin = window\.location\.origin;\n/g, '');
fs.writeFileSync('src/components/ProfileCheckWidget.tsx', profile);

console.log("App TS fixed.");
