import fs from 'fs';

let server = fs.readFileSync('server.ts', 'utf8');

const replacement = `
        if (empfaengerSprache) {
           targetLang = empfaengerSprache;
           try {
              if (process.env.GEMINI_API_KEY) {
                const { GoogleGenAI } = await import("@google/genai");
                const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
                
                const prompt = \`Translate this dating app message to \${targetLang}. 
Preserve the exact emotional tone, dating slang, and emojis.
Do not add explanations or quotes. Output ONLY the translated text.
Message to translate: "\${text}"\`;

                const response = await ai.models.generateContent({
                  model: "gemini-2.5-flash",
                  contents: prompt,
                });
                
                textTranslated = response.text.trim();
                sourceLang = 'auto';
                translationProvider = 'gemini';
              } else {
                textTranslated = \`[\${empfaengerSprache.toUpperCase()}] \${text}\`;
                sourceLang = 'auto';
                translationProvider = 'fallback_dummy';
              }
           } catch (e: any) {
              console.error("Gemini Translation error:", e);
              // Graceful degradation: textTranslated remains null
           }
        }
`;

server = server.replace(/if \(empfaengerSprache\) \{[\s\S]*?\}\s*\}\s*const createdAt = new Date\(\)\.toISOString\(\);/, replacement + '      }\n\n      const createdAt = new Date().toISOString();');

fs.writeFileSync('server.ts', server);
