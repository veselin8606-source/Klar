import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');
content = content.replace("import React, { useEffect, useState, useRef } from 'react';", "import { useEffect, useState, useRef } from 'react';");
fs.writeFileSync('src/components/Sichtschutz.tsx', content);
