import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/isFlagged: \{ type: Type\.BOOLEAN , responseMimeType: "application\/json", responseSchema: \{ type: Type\.OBJECT, properties: \{ text: \{ type: Type\.STRING \} \} \} \},[\s\S]*?explanation: \{ type: Type\.STRING \},[\s\S]*?\);\n/m, 
`isFlagged: { type: Type.BOOLEAN },
              explanation: { type: Type.STRING },
              suggestions: { type: Type.ARRAY, items: { type: Type.STRING } }
            }
          }
        }
      });\n`);

fs.writeFileSync('server.ts', content);
