import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
content = content.replace(
  "if (lastMsg.role === 'verbindung' && lastMsg.translationStatus === 'completed' && !lastMsg.isRead) {",
  "if (lastMsg && lastMsg.role === 'verbindung' && lastMsg.translationStatus === 'completed' && !lastMsg.isRead) {"
);
content = content.replace(
  "if (        lastMsg.role === \"verbindung\" &&        lastMsg.translationStatus === \"completed\" &&        !lastMsg.isRead      ) {",
  "if (lastMsg && lastMsg.role === 'verbindung' && lastMsg.translationStatus === 'completed' && !lastMsg.isRead) {"
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
