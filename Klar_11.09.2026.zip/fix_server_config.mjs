import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/, config: \{ responseMimeType: "application\/json", responseSchema: \{ type: Type\.OBJECT, properties: \{ notes: \{ type: Type\.STRING \} \} \} \}/g, '');
content = content.replace(/, config: \{ responseMimeType: "application\/json", responseSchema: \{ type: Type\.OBJECT, properties: \{ insight: \{ type: Type\.STRING \} \} \} \}/g, '');

fs.writeFileSync('server.ts', content);
