const fs = require('fs');
let code = fs.readFileSync('src/screens/KlarPlus.tsx', 'utf-8');

const importTarget = `import { ArrowLeft, Check, Minus } from "lucide-react";`;
const importReplace = `import { ArrowLeft, Check, Minus, Zap } from "lucide-react";
import { useState, useEffect } from "react";
import { useAuth } from "../lib/AuthContext";`;
code = code.replace(importTarget, importReplace);

const fnTarget = `export default function KlarPlus() {`;
const fnReplace = `export default function KlarPlus() {
  const { user } = useAuth();
  const [variant, setVariant] = useState<"A" | "B" | null>(null);

  useEffect(() => {
    let storedVariant = localStorage.getItem("klarplus_ab_variant");
    if (!storedVariant) {
      storedVariant = Math.random() < 0.5 ? "A" : "B";
      localStorage.setItem("klarplus_ab_variant", storedVariant);
    }
    setVariant(storedVariant as "A" | "B");

    if (user?.uid) {
      fetch("/api/analytics/ab-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.uid,
          eventName: "klarplus_page_view",
          variant: storedVariant,
          source: "KlarPlus_Landing"
        })
      }).catch(() => {});
    }
  }, [user?.uid]);

  const handleConversionClick = () => {
    if (user?.uid && variant) {
      fetch("/api/analytics/ab-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.uid,
          eventName: "klarplus_conversion_click",
          variant,
          source: "KlarPlus_Landing"
        })
      }).catch(() => {});
    }
  };`;
code = code.replace(fnTarget, fnReplace);

const textTarget = `      <p className="text-muted mb-6 leading-relaxed">
        Acht Kontakte am Tag gelten für alle — auch mit Klar+. Das Kontingent
        ist bei Klar kein Mangel, den man wegkaufen kann, sondern der Grund,
        warum die App anders funktioniert. Klar+ macht diese acht besser,
        nicht mehr.
      </p>`;

const textReplace = `      {variant === "A" || variant === null ? (
        <p className="text-muted mb-6 leading-relaxed">
          Acht Kontakte am Tag gelten für alle — auch mit Klar+. Das Kontingent
          ist bei Klar kein Mangel, den man wegkaufen kann, sondern der Grund,
          warum die App anders funktioniert. Klar+ macht diese acht besser,
          nicht mehr.
        </p>
      ) : (
        <div className="bg-accent-quiet border border-accent/20 p-5 rounded-2xl mb-6">
          <p className="text-ink font-medium mb-2 flex items-center gap-2">
            <Zap size={18} className="text-accent" />
            Für alle, die Klarheit priorisieren
          </p>
          <p className="text-muted leading-relaxed">
            Klar+ optimiert deine Zeit. Erhalte Zugriff auf erweiterte Filter, detaillierte Kompatibilitäts-Insights und ein werbefreies Erlebnis für qualitativ hochwertige Verbindungen.
          </p>
        </div>
      )}`;
code = code.replace(textTarget, textReplace);

const btnTarget = `      <div role="note" className="rounded-2xl border border-line-ui p-5">`;
const btnReplace = `      <button 
        onClick={handleConversionClick}
        className="w-full bg-accent hover:bg-accent-hover text-white font-medium py-3 rounded-xl mb-6 transition-colors shadow-sm"
      >
        Klar+ jetzt entdecken
      </button>
      <div role="note" className="rounded-2xl border border-line-ui p-5">`;
code = code.replace(btnTarget, btnReplace);

fs.writeFileSync('src/screens/KlarPlus.tsx', code);
