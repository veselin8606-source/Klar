import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const missingVars = `
  const { id } = useParams();
  const navigate = useNavigate();
  const profile = allProfiles.find(p => p.id === id);
  const istBeispielGespraech = !!profile;
`;

content = content.replace(
  "export default function ChatView() {\n  const [messages, setMessages] = useState<ChatMessage[]>([]);",
  "export default function ChatView() {\n" + missingVars + "  const [messages, setMessages] = useState<ChatMessage[]>([]);"
);
fs.writeFileSync('src/screens/ChatView.tsx', content);
