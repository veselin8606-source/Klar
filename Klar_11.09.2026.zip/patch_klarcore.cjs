const fs = require('fs');
let code = fs.readFileSync('src/server/klarCore.ts', 'utf-8');

const importStr = `import { trackEvent } from "./analytics";\n`;
if (!code.includes('import { trackEvent }')) {
  code = importStr + code;
}

const target = `    await db().collection('verification_events').add({
      uid: ziel,
      moderatorUid: uid(req),
      entscheidung,
      begruendung: begruendung || null,
      at: FieldValue.serverTimestamp(),
      // Aufbewahrung des Fotos: 30 Tage, solange eine Beschwerde möglich
      // sein muss. Der Auftrag steht hier, damit ihn niemand erinnern muss.
      fotoLoeschenAb: new Date(Date.now() + 30 * 86_400_000),
    });`;

const replace = `    await db().collection('verification_events').add({
      uid: ziel,
      moderatorUid: uid(req),
      entscheidung,
      begruendung: begruendung || null,
      at: FieldValue.serverTimestamp(),
      // Aufbewahrung des Fotos: 30 Tage, solange eine Beschwerde möglich
      // sein muss. Der Auftrag steht hier, damit ihn niemand erinnern muss.
      fotoLoeschenAb: new Date(Date.now() + 30 * 86_400_000),
    });
    
    if (bestaetigt) {
      await trackEvent(ziel, 'user_verified', { moderatorUid: uid(req) });
    }`;

code = code.replace(target, replace);
fs.writeFileSync('src/server/klarCore.ts', code);
