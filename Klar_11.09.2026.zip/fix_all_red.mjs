import fs from 'fs';
import path from 'path';

function fixFile(filePath) {
  let content = fs.readFileSync(filePath, 'utf8');
  content = content.replace(/bg-red-50/g, 'bg-amber-50');
  content = content.replace(/bg-red-900\/20/g, 'bg-amber-900/20');
  content = content.replace(/border-red-200/g, 'border-amber-200');
  content = content.replace(/border-red-100/g, 'border-amber-100');
  content = content.replace(/border-red-800/g, 'border-amber-800');
  content = content.replace(/border-red-900/g, 'border-amber-900');
  content = content.replace(/text-red-600/g, 'text-amber-700');
  content = content.replace(/text-red-400/g, 'text-amber-400');
  content = content.replace(/text-red-500/g, 'text-amber-500');
  fs.writeFileSync(filePath, content);
}

const files = [
  'src/components/LaunchPromoWidget.tsx',
  'src/components/KlarInsightsWidget.tsx',
  'src/components/DatingVibeCheckQuiz.tsx',
  'src/screens/Profile.tsx',
  'src/screens/AdminDashboard.tsx',
];

files.forEach(fixFile);
