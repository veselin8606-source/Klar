const fs = require('fs');

let server = fs.readFileSync('server.ts', 'utf8');

// re-add missing imports
server = server.replace(/import rateLimit, \{ ipKeyGenerator \} from "express-rate-limit";/, `import { NOGO_VORSCHLAEGE, BIO_WERTE_HINWEISE } from "./src/server/kuratiert";\nimport rateLimit, { ipKeyGenerator } from "express-rate-limit";`);

server = server.replace(/const transcription = result\.response\.text\(\);/g, 'const transcription = result.text;');

fs.writeFileSync('server.ts', server);
console.log("Fixed missing imports and result.text");
