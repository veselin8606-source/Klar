import fs from 'fs';
const file = 'tests/zwischenspeicher.spec.ts';
let code = fs.readFileSync(file, 'utf8');
code = code.replace(/import \{ db \} from '\.\.\/src\/server\/db';/g, "import { getDb as db } from '../src/server/db';");
code = code.replace(/import \{ getFirestore \} from 'firebase-admin\/firestore';/g, "import { getFirestore } from 'firebase/firestore';");
fs.writeFileSync(file, code);
