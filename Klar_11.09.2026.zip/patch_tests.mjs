import fs from 'fs';
let code = fs.readFileSync('tests/messages.spec.ts', 'utf-8');

code = code.replace(/const originalText = 'Hola';\n/g, '');
code = code.replace(/let targetLang = 'de';\n/g, '');
code = code.replace(/return new Promise\(\(resolve, reject\)/g, 'return new Promise((_resolve, reject)');
code = code.replace(/catch\(e\)/g, 'catch(_e)');
code = code.replace(/catch\(e\) \{\}/g, 'catch(_e) {}');

fs.writeFileSync('tests/messages.spec.ts', code);
console.log("Patched test file.");
