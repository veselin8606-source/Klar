const fs = require('fs');
let code = fs.readFileSync('src/screens/Profile.tsx', 'utf-8');

code = code.replace(
  /(\s+<\/button>\s+<\/div>\s+)({\/\* ── BEFUND 14\.08\.2026: HAPTIK STAND ZWEIMAL AUF DIESER SEITE ──)/,
  '$1<RitualReminderSetting />\n\n          $2'
);

fs.writeFileSync('src/screens/Profile.tsx', code);
