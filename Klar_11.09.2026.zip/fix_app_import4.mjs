import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf8');

const replacement = `import { Sichtschutz, SichtschutzKnopf } from "./components/Sichtschutz";
import { DashboardOnboarding } from "./components/DashboardOnboarding";`;

content = content.replace('import { Sichtschutz, SichtschutzKnopf } from "./components/Sichtschutz";', replacement);

fs.writeFileSync('src/App.tsx', content);
