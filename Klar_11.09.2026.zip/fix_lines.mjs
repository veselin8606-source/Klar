import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const lines = content.split('\n');
const fixedLines = [];
let i = 0;
while (i < lines.length) {
    if (i >= 411 && i <= 421) {
        // Skip these lines
    } else {
        fixedLines.push(lines[i]);
    }
    i++;
}

// Check where the extra brace is at EOF
let finalContent = fixedLines.join('\n');
if (finalContent.trim().endsWith("}\n}")) {
  finalContent = finalContent.substring(0, finalContent.lastIndexOf("}"));
}
fs.writeFileSync('src/screens/ChatView.tsx', finalContent);
