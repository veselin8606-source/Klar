import fs from 'fs';

// 1. SyncBanner unused imports
let syncCode = fs.readFileSync('src/components/SyncBanner.tsx', 'utf-8');
syncCode = syncCode.replace('import { collection, addDoc, doc, updateDoc } from \'firebase/firestore\';', 'import { doc, updateDoc } from \'firebase/firestore\';');
fs.writeFileSync('src/components/SyncBanner.tsx', syncCode);

// 2. ChatView - remove zielsprache from <MessageBubble>
let chatCode = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');
chatCode = chatCode.replace(/<MessageBubble msg=\{msg\} zielsprache=\{[^}]+\} \/>/g, '<MessageBubble msg={msg} />');
chatCode = chatCode.replace(/<MessageBubble key=\{msg\.id \?\? idx\} msg=\{msg\} zielsprache=\{[^}]+\} \/>/g, '<MessageBubble key={msg.id ?? idx} msg={msg} />');

// 3. ChatView - fix type of id assignment
chatCode = chatCode.replace(
  'newArr[newArr.length - 1] = { ...newArr[newArr.length - 1], id: tempId };',
  'newArr[newArr.length - 1] = { ...(newArr[newArr.length - 1] as any), id: tempId } as any;'
);

fs.writeFileSync('src/screens/ChatView.tsx', chatCode);

// 4. Profile.tsx - fix missing Languages import
let profCode = fs.readFileSync('src/screens/Profile.tsx', 'utf-8');
if (!profCode.includes('Languages,')) {
  profCode = profCode.replace('Settings, Download,', 'Settings, Download, Languages,');
  fs.writeFileSync('src/screens/Profile.tsx', profCode);
}

console.log("Patched errors.");
