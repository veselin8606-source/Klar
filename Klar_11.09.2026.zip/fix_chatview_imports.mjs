import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
if (content.indexOf("import { motion, AnimatePresence } from 'motion/react';") === -1) {
    content = content.replace(
        "import { useState, useEffect, useRef } from 'react';",
        "import { useState, useEffect, useRef } from 'react';\nimport { motion, AnimatePresence } from 'motion/react';"
    );
}
fs.writeFileSync('src/screens/ChatView.tsx', content);
