import fs from 'fs';

let server = fs.readFileSync('server.ts', 'utf8');

const replacement = `
      const createdAt = new Date().toISOString();
      const messageId = db.collection("chats").doc(chatId).collection("messages").doc().id;

      let targetLang = null;
      let otherUid = null;
      if (chatData.participants) {
         otherUid = chatData.participants.find((p: string) => p !== meineUid);
      }
      
      let empfaengerSprache = null;
      if (otherUid) {
        const otherUserDoc = await db.collection("users").doc(otherUid).get();
        empfaengerSprache = (otherUserDoc.data() || {}).preferredLanguage || null;
      }

      // Initial save WITHOUT translation to keep latency near 0
      const batch = db.batch();
      const messageRef = db.collection("chats").doc(chatId).collection("messages").doc(messageId);
      
      batch.set(messageRef, {
        chatId,
        senderId: meineUid,
        text: text, 
        textOriginal: text,
        createdAt,
        translationStatus: empfaengerSprache ? 'pending' : 'none'
      });
      batch.update(chatRef, {
        lastMessage: text,
        lastMessageAt: createdAt
      });
      await batch.commit();

      // Return success immediately to client
      res.status(200).json({ success: true, messageId });

      // --- ASYNC BACKGROUND TRANSLATION ---
      if (empfaengerSprache) {
         targetLang = empfaengerSprache;
         (async () => {
             try {
                let textTranslated = null;
                let sourceLang = 'auto';
                let translationProvider = 'gemini';
                
                if (process.env.GEMINI_API_KEY) {
                  const { GoogleGenAI } = await import("@google/genai");
                  const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
                  const prompt = \`Translate this dating app message to \${targetLang}. 
Preserve the exact emotional tone, dating slang, and emojis.
Do not add explanations or quotes. Output ONLY the translated text.
Message to translate: "\${text}"\`;
                  const response = await ai.models.generateContent({
                    model: "gemini-2.5-flash",
                    contents: prompt,
                  });
                  textTranslated = response.text.trim();
                } else {
                  textTranslated = \`[\${empfaengerSprache.toUpperCase()}] \${text}\`;
                  translationProvider = 'fallback_dummy';
                }

                if (textTranslated) {
                   await messageRef.update({
                      textTranslated,
                      text: textTranslated, // Override main text for UI clients that only read 'text'
                      sourceLang,
                      targetLang,
                      translationProvider,
                      translationStatus: 'completed'
                   });
                } else {
                   await messageRef.update({ translationStatus: 'failed' });
                }
             } catch (e) {
                console.error("Async Gemini Translation error:", e);
                await messageRef.update({ translationStatus: 'failed' });
             }
         })();
      }
      return; // Do not send response twice
    } catch (error) {
`;

server = server.replace(/      let textTranslated = null;[\s\S]*?res\.status\(200\)\.json\(\{ success: true, messageId, textTranslated \}\);\s*\} catch \(error\) \{/, replacement);

fs.writeFileSync('server.ts', server);
