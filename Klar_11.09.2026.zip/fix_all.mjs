import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// Fix duplicate isRecording
content = content.replace(
    /const \[isRecording, setIsRecording\] = useState\(false\);\n  const \[mediaRecorder, setMediaRecorder\] = useState<MediaRecorder \| null>\(null\);\n  const \[isProcessingAudio, setIsProcessingAudio\] = useState\(false\);/,
    ""
);
content = content.replace(
    /const startRecording = async \(\) => \{[\s\S]*?const processAudioMessage = async \(blob: Blob, mimeType: string\) => \{[\s\S]*?^\s*\};/m,
    ""
);

// Fix missing motion imports
if (content.indexOf("import { motion, AnimatePresence } from 'motion/react';") === -1) {
    content = content.replace(
        'import { useParams, useNavigate } from "react-router";',
        'import { useParams, useNavigate } from "react-router";\nimport { motion, AnimatePresence } from "motion/react";'
    );
}

// Fix missing showSentimentCheck
if (content.indexOf("const [showSentimentCheck, setShowSentimentCheck] = useState(false);") === -1) {
    content = content.replace(
        "const [showReportModal, setShowReportModal] = useState(false);",
        "const [showReportModal, setShowReportModal] = useState(false);\n  const [showSentimentCheck, setShowSentimentCheck] = useState(false);"
    );
}

// Make sure ChatView returns JSX
content = content.replace(
    /if \(\!profile\) return <div[^>]*>.*?<\/div>;/,
    "if (!profile) return (<div>Verbindung nicht gefunden</div>);"
);
// Also it complains that ChatView returns void. Let's see if there is another return.
// If we return ( <div ...> ... ); it's fine.

fs.writeFileSync('src/screens/ChatView.tsx', content);
