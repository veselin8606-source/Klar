import fs from 'fs';
const text = fs.readFileSync('server.ts', 'utf8');
const lines = text.split('\n');
const targets = [1369, 1445, 2272, 2313, 2351, 2449, 2591, 2781, 3146, 3594, 3907];
for (let line of targets) {
  let block = lines.slice(line-5, line+25).join('\n');
  console.log("--- LINE " + line + " ---");
  console.log(block);
}
