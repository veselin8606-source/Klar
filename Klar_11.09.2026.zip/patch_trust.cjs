const fs = require('fs');
let code = fs.readFileSync('src/server/trustAndSafety.ts', 'utf-8');

const importStr = `import { trackEvent } from "./analytics";\n`;
if (!code.includes('import { trackEvent }')) {
  code = importStr + code;
}

const target = `    await db.collection('deletion_log').add({
      uidHash: meineUid.slice(0, 6) + '…',
      at: FieldValue.serverTimestamp(),
      ...bericht,
    });`;

const replace = `    await db.collection('deletion_log').add({
      uidHash: meineUid.slice(0, 6) + '…',
      at: FieldValue.serverTimestamp(),
      ...bericht,
    });
    
    // Tracking fuer Unit Economics / Churn
    await trackEvent(meineUid, 'account_deleted', { 
       chats: bericht.chats, 
       kontakte: bericht.kontakte 
    });`;

code = code.replace(target, replace);
fs.writeFileSync('src/server/trustAndSafety.ts', code);
