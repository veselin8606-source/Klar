import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

const endStr = `          <DatingJournalWidget userInterests={userInterests} />
          {/* ENTFERNT: QualityConversationsChartWidget, siehe Kommentar am Import. */}
          {/* BEFUND 12.08.2026: Hier stand \`verbindungenInterests={…}\`.
              \`DailyIcebreakerWidget\` kennt diese Eigenschaft nicht — sie
              heisst \`matchesInterests\`. Der Wert wurde also verworfen, und
              das Widget schickte \`matchesInterests: undefined\` an
              /api/daily-icebreaker. Die Gespraechsanfaenge des Tages waren
              damit ohne jeden Bezug zu den Interessen der Verbindungen. */}
          <DailyIcebreakerWidget userInterests={userInterests} matchesInterests={uniqueVerbindungenInterests} />
          <SmartDatePlannerWidget location={filterLocation} />
          <BeiSicht><DateInspirationTab userInterests={userInterests} userCoords={userCoords} /></BeiSicht>
        </div>
      </div>
    </div>
  );
}
`;

content = content.replace(/          <BeiSicht><DateInspirationTab userInterests=\{userInterests\} userCoords=\{userCoords\} \/><\/BeiSicht>\n        <\/div>\n      <\/div>\n    <\/div>\n  \);\n\}[\s\S]*/, endStr);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
