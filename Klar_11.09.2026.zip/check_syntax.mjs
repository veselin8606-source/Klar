import fs from 'fs';
const content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const lines = content.split('\n');

for (let i = 2210; i < lines.length; i++) {
  console.log(`${i+1}: ${lines[i]}`);
}
