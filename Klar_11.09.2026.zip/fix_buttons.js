import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

content = content.replace(
  'Smart-Verbindung\n                </motion.div>\n              </div>',
  'Smart-Verbindung\n                </motion.div>\n              </button>'
);

content = content.replace(
  'Smart-Verbindung\n                      </motion.div>\n                    </div>',
  'Smart-Verbindung\n                      </motion.div>\n                    </button>'
);

fs.writeFileSync('src/screens/Dashboard.tsx', content, 'utf8');
