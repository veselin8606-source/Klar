import fs from 'fs';
let code = fs.readFileSync('src/screens/AdminDashboard.tsx', 'utf8');

// Remove from top
code = code.replace(/      <BuildInfoWidget \/>\n<FailedApiLogWidget \/>\n<HiddenDebugHealthCheck \/>\n/, '');

// Add to bottom (before the final closing div)
// We look for the last closing div of the main container.
// In AdminDashboard, the main return is:
// return (
//   <div className="flex-1 overflow-y-auto pb-24 p-4">
// ...
//   </div>
// );

const insertStr = `
      <div className="mt-8 pt-8 border-t border-stone-200 dark:border-stone-800">
        <HiddenDebugHealthCheck />
        <FailedApiLogWidget />
        <BuildInfoWidget />
      </div>
    </div>
  );
}
`;

code = code.replace(/    <\/div>\n  \);\n}\n?$/, insertStr);
fs.writeFileSync('src/screens/AdminDashboard.tsx', code);
console.log('Moved widgets to footer');
