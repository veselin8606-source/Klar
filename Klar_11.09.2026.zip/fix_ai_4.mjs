import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

// Quick insights
code = code.replace(/contents: `Analysiere folgendes Profil in genau einem ganz kurzen, positiven Satz \(max\. 5-7 Wörter\) der neugierig macht auf mehr Feedback\. Profil: \$\{bio\}`,\s*\}\),/g, 
`contents: \`Analysiere folgendes Profil in genau einem ganz kurzen, positiven Satz (max. 5-7 Wörter) der neugierig macht auf mehr Feedback. Profil: \${bio}\`, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { insight: { type: Type.STRING } } } } }),`);

// Reflection
code = code.replace(/contents: `Du bist ein Dating Coach\. Der Nutzer hat gerade ein Date gehabt und diese Emojis als Quick-Log ausgewählt: \$\{emojiString\}\. Schreibe basierend darauf 2-3 kurze Sätze als ersten Entwurf für sein Tagebuch\. Sprich aus der Ich-Perspektive, als wäre es der Nutzer\.`,\s*\}\),/g,
`contents: \`Du bist ein Dating Coach. Der Nutzer hat gerade ein Date gehabt und diese Emojis als Quick-Log ausgewählt: \${emojiString}. Schreibe basierend darauf 2-3 kurze Sätze als ersten Entwurf für sein Tagebuch. Sprich aus der Ich-Perspektive, als wäre es der Nutzer.\`, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { notes: { type: Type.STRING } } } } }),`);

// Change json: false to json: true
code = code.replace(/\{ json: false, feld: "text" \}/g, '{ json: true }');
code = code.replace(/\{ json: false, feld: 'insight' \}/g, '{ json: true }');
code = code.replace(/\{ json: false, feld: "notes" \}/g, '{ json: true }');

// We still need to inject responseSchema into the other configs (like /api/chat, /api/generate-message, etc.)
code = code.replace(/systemInstruction: `Du bist der offizielle KI-Assistent der "Klar Dating App"\.[\s\S]*?`,\s*\}/g,
`$&, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } }`);

code = code.replace(/systemInstruction: `Du hilfst Nutzern der Dating-App "Klar", gute erste Nachrichten[\s\S]*?`,\s*\}/g,
`$&, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } }`);

code = code.replace(/systemInstruction:\s*"Du übersetzt Nachrichten aus einer Dating-App\.[\s\S]*?",\s*\}/g,
`$&, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } }`);

fs.writeFileSync('server.ts', code);
