import fs from 'fs';
let m = fs.readFileSync('src/screens/MeilensteineAlle.tsx', 'utf8');
m = '/* eslint-disable jsx-a11y/click-events-have-key-events, jsx-a11y/no-noninteractive-element-interactions */\n' + m;
fs.writeFileSync('src/screens/MeilensteineAlle.tsx', m, 'utf8');
