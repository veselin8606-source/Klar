const fs = require('fs');
let haptics = fs.readFileSync('src/lib/haptics.ts', 'utf8');
haptics = haptics.replace(/\/\/ navigator\.vibrate\(finalPattern\);/g, '');
fs.writeFileSync('src/lib/haptics.ts', haptics);
console.log("Patched haptics again");
