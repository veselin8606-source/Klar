import fs from 'fs';
let content = fs.readFileSync('src/App.tsx', 'utf8');

const newLadepunkt = `
function Ladepunkt() {
  return (
    <div className="h-[100dvh] flex flex-col items-center justify-start p-6 bg-light-bg dark:bg-dark-bg w-full">
      <div className="w-full max-w-2xl mx-auto space-y-6 pt-12">
        {/* Header Skeleton */}
        <div className="flex justify-between items-center mb-8">
          <div className="h-8 w-48 bg-stone-200 dark:bg-stone-800 rounded-lg animate-pulse"></div>
          <div className="h-10 w-10 bg-stone-200 dark:bg-stone-800 rounded-full animate-pulse"></div>
        </div>
        
        {/* Hero Card Skeleton */}
        <div className="w-full h-48 bg-stone-200 dark:bg-stone-800 rounded-2xl animate-pulse"></div>
        
        {/* Grid Skeleton */}
        <div className="grid grid-cols-2 gap-4">
          <div className="h-32 bg-stone-200 dark:bg-stone-800 rounded-2xl animate-pulse delay-75"></div>
          <div className="h-32 bg-stone-200 dark:bg-stone-800 rounded-2xl animate-pulse delay-100"></div>
        </div>
        
        {/* List Items Skeleton */}
        <div className="space-y-4 pt-4">
          <div className="h-16 w-full bg-stone-200 dark:bg-stone-800 rounded-xl animate-pulse delay-150"></div>
          <div className="h-16 w-full bg-stone-200 dark:bg-stone-800 rounded-xl animate-pulse delay-200"></div>
          <div className="h-16 w-full bg-stone-200 dark:bg-stone-800 rounded-xl animate-pulse delay-300"></div>
        </div>
      </div>
    </div>
  );
}
`;

content = content.replace(/function Ladepunkt\(\) \{[\s\S]*?return \([\s\S]*?\}\);?\s*\}/m, newLadepunkt.trim());
fs.writeFileSync('src/App.tsx', content);
