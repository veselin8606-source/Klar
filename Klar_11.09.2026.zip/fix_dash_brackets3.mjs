import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
content = content.replace(/\{modalProfile && \(\n                  <motion\.div/g, "{modalProfile && (\n          <>\n          <motion.div");
content = content.replace(/          <\/motion\.div>\n        \)\}\n      <\/AnimatePresence>/g, "          </motion.div>\n          </>\n        )}\n      </AnimatePresence>");

content = content.replace(/\{smartKontaktDetailProfile && \(\n            <motion\.div/g, "{smartKontaktDetailProfile && (\n          <>\n          <motion.div");
content = content.replace(/            <\/motion\.div>\n          \)\}\n        <\/AnimatePresence>/g, "            </motion.div>\n            </>\n          )}\n        </AnimatePresence>");

fs.writeFileSync('src/screens/Dashboard.tsx', content);
