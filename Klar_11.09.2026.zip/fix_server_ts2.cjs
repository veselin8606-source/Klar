const fs = require('fs');
let server = fs.readFileSync('server.ts', 'utf8');

server = server.replace(/import \{ lies as liesSpeicher, schreibe as schreibeSpeicher \} from "\.\/src\/server\/zwischenspeicher";\n/g, '');

fs.writeFileSync('server.ts', server);
console.log("Fixed unused imports");
