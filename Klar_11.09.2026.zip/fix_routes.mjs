import fs from 'fs';
let code = fs.readFileSync('src/App.tsx', 'utf8');

const notFoundHandler = `
function NotFoundHandler() {
  const location = useLocation();
  const { role } = useAuth();
  
  useEffect(() => {
    if (role === 'moderator' || role === 'admin') {
      const el = document.createElement('div');
      el.className = 'fixed bottom-4 right-4 bg-red-500 text-white px-4 py-2 rounded shadow-lg z-50 animate-pulse text-sm font-mono';
      el.innerText = \`404 Router Error: \${location.pathname}\`;
      document.body.appendChild(el);
      setTimeout(() => el.remove(), 10000);
    }
  }, [location, role]);

  return (
    <div className="flex flex-col items-center justify-center h-full text-center p-6">
      <h2 className="text-xl font-bold text-stone-800 dark:text-stone-200 mb-2">Seite nicht gefunden (404)</h2>
      <p className="text-stone-500">Der Pfad <code>{location.pathname}</code> existiert nicht.</p>
    </div>
  );
}
`;

code = code.replace(
  "function AnimatedRoutes() {",
  notFoundHandler + "\nfunction AnimatedRoutes() {"
);

code = code.replace(
  '<Route path="/rechtstexte/:art" element={<PageWrapper><Rechtstexte /></PageWrapper>} />',
  '<Route path="/rechtstexte/:art" element={<PageWrapper><Rechtstexte /></PageWrapper>} />\n        <Route path="*" element={<PageWrapper><NotFoundHandler /></PageWrapper>} />'
);

fs.writeFileSync('src/App.tsx', code);
console.log("404 handler added");
