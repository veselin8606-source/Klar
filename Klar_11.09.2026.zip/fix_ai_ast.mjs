import fs from 'fs';
import ts from 'typescript';

let code = fs.readFileSync('server.ts', 'utf8');

const regex = /generateContent\(\{\s*model:(.*?),\s*contents:(.*?),\s*config:\s*\{([\s\S]*?)\}\s*\}\)/g;
// Wait, some might not have a `config` object?
