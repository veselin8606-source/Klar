import fs from 'fs';

// App.tsx
let app = fs.readFileSync('src/App.tsx', 'utf8');
if (!app.includes('useNavigate } from "react-router"')) {
  app = app.replace('import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router";', 'import { BrowserRouter as Router, Routes, Route, Navigate, useNavigate } from "react-router";');
  app = app.replace('import { Route, Routes, Navigate } from "react-router";', 'import { Route, Routes, Navigate, useNavigate } from "react-router";');
}
fs.writeFileSync('src/App.tsx', app);

// Profile.tsx
let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
if (!prof.includes('MessageSquare,')) {
    prof = prof.replace('import { Settings, ShieldCheck, Heart, MessageSquare, Star } from "lucide-react";', 'import { Settings, ShieldCheck, Heart, MessageSquare, Star, ChevronRight } from "lucide-react";'); // Just in case
    prof = prof.replace('import { Settings, ShieldCheck } from "lucide-react";', 'import { Settings, ShieldCheck, Heart, MessageSquare, Star } from "lucide-react";');
}
// ProfileFeedback is declared.
if (!prof.match(/<ProfileFeedback \/>/)) {
    prof = prof.replace(/<\/main>/, '  <ProfileFeedback />\n      </main>');
}
fs.writeFileSync('src/screens/Profile.tsx', prof);

// Tips.tsx
let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
if (!tips.includes('Star } from "lucide-react"')) {
    tips = tips.replace('import { Bookmark, BookmarkCheck } from "lucide-react";', 'import { Bookmark, BookmarkCheck, Star } from "lucide-react";');
    tips = tips.replace('import { Bookmark, BookmarkCheck, Star }', 'import { Bookmark, BookmarkCheck, Star }');
}
fs.writeFileSync('src/screens/Tips.tsx', tips);
