const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

const target = `  app.post("/api/subscribe-klar-plus", (_req, res) => {`;

const replace = `  app.post("/api/analytics/ab-test", express.json(), async (req, res) => {
    try {
      const { userId, eventName, variant, source } = req.body;
      if (!userId || !eventName) return res.status(400).send("Missing data");
      
      const { trackEvent } = require("./src/server/analytics");
      await trackEvent(userId, eventName, { variant, source });
      res.json({ ok: true });
    } catch (e) {
      console.error(e);
      res.status(500).send("Error");
    }
  });

  app.post("/api/subscribe-klar-plus", (_req, res) => {`;

code = code.replace(target, replace);
fs.writeFileSync('server.ts', code);
