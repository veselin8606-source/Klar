import fs from 'fs';
let code = fs.readFileSync('src/screens/AdminDashboard.tsx', 'utf8');

code = code.replace(
  '          <div className="space-y-6">',
  '          <div className="space-y-6">\n            <BuildInfoWidget />\n            <FailedApiLogWidget />\n            <HiddenDebugHealthCheck />'
);

fs.writeFileSync('src/screens/AdminDashboard.tsx', code);
console.log("Fixed AdminDashboard");
