import fs from 'fs';
const text = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
let level = 0;
let lines = text.split('\n');
for (let i = 226; i < 2248; i++) {
  let line = lines[i];
  let stripped = line.replace(/\/\/.*$/, ''); 
  for (let j = 0; j < stripped.length; j++) {
    if (stripped[j] === '{') level++;
    if (stripped[j] === '}') level--;
  }
}
console.log('Level at 2248:', level);
