import fs from 'fs';

// Fix Chats.tsx
let chats = fs.readFileSync('src/screens/Chats.tsx', 'utf8');
chats = chats.replace(/SwipeableChat/g, 'DismissableChat');
chats = chats.replace(/drag="x"/g, 'drag="x"');
fs.writeFileSync('src/screens/Chats.tsx', chats);

// Fix ChatView.tsx
let chatView = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
chatView = chatView.replace(/"Match"/g, '"Kontakt"');
chatView = chatView.replace(/'Match'/g, "'Kontakt'");
chatView = chatView.replace(/Match/g, 'Kontakt');
fs.writeFileSync('src/screens/ChatView.tsx', chatView);

// Fix Dashboard.tsx "Swipe" or "Match" if any
let dashboard = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
dashboard = dashboard.replace(/Swipe/g, 'Kontakt');
dashboard = dashboard.replace(/Match/g, 'Kontakt');
fs.writeFileSync('src/screens/Dashboard.tsx', dashboard);
