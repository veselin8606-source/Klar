import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

// Remove requireAuth from route definitions since it's applied globally
content = content.replace(/app\.get\('\/api\/system-health', requireAuth, nurModeration,/g, "app.get('/api/system-health', nurModeration,");
content = content.replace(/app\.get\("\/api\/stats\/klar-insights", requireAuth,/g, 'app.get("/api/stats/klar-insights",');
content = content.replace(/app\.get\("\/api\/stats\/activity", requireAuth,/g, 'app.get("/api/stats/activity",');
content = content.replace(/app\.post\("\/api\/messages\/send", requireAuth,/g, 'app.post("/api/messages/send",');

fs.writeFileSync('server.ts', content);
