import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');

// There's a trailing syntax error at the end of the file.
// The diff script introduced `<></>` wrapping inside `return (` but missed some spots.

const replacement = `
      <div className={\`flex-1 overflow-y-auto hide-scrollbar pb-24 \${activeTab === 'inspiration' ? 'block' : 'hidden'}\`}>
        <div className="flex flex-col gap-4">
          <BeiSicht><SmartVorschlaegeWidget /></BeiSicht>
          <BeiSicht><WeeklyMoodSummaryWidget /></BeiSicht>
          <BeiSicht><SafeDatePlannerWidget /></BeiSicht>
          <BeiSicht><NextDateCountdownWidget /></BeiSicht>
          <BeiSicht><PreDateChecklistWidget /></BeiSicht>
          <BeiSicht><ReflectionLogWidget /></BeiSicht>
          <KlarCompassWidget userInterests={userInterests} />
          {/* ENTFERNT: EmailSummaryWidget, siehe Kommentar am Import. */}
          <DatingJournalWidget userInterests={userInterests} />
          {/* ENTFERNT: QualityConversationsChartWidget, siehe Kommentar am Import. */}
          {/* BEFUND 12.08.2026: Hier stand \`verbindungenInterests={…}\`.
              \`DailyIcebreakerWidget\` kennt diese Eigenschaft nicht — sie
              heisst \`matchesInterests\`. Der Wert wurde also verworfen, und
              das Widget schickte \`matchesInterests: undefined\` an
              /api/daily-icebreaker. Die Gespraechsanfaenge des Tages waren
              damit ohne jeden Bezug zu den Interessen der Verbindungen. */}
          <DailyIcebreakerWidget userInterests={userInterests} matchesInterests={uniqueVerbindungenInterests} />
          <SmartDatePlannerWidget location={filterLocation} />
          <BeiSicht><DateInspirationTab userInterests={userInterests} userCoords={userCoords} /></BeiSicht>
        </div>
      </div>
    </div>
    </>
  );
}
`;

content = content.replace(/      <div className=\{\`flex-1 overflow-y-auto hide-scrollbar pb-24 \$\{activeTab === 'inspiration' \? 'block' : 'hidden'\}\`\}>[\s\S]*?\}\n/m, replacement);

fs.writeFileSync('src/screens/Dashboard.tsx', content);
