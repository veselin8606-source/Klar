import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

// Fix writeBatch unused
content = content.replace(/writeBatch, /g, '');
content = content.replace(/, writeBatch/g, '');

// Fix auth.currentUser is possibly null
content = content.replace(/auth\.currentUser\.getIdToken/g, 'auth.currentUser?.getIdToken');

// e is declared but its value is never read
content = content.replace(/\.catch\(e => \{/g, '.catch(() => {');

fs.writeFileSync('src/screens/ChatView.tsx', content);
