import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

const apiChat = `
  app.post("/api/chat", async (req, res) => {
    try {
      const { messages, userBio, userInterests, targetName, targetBio, targetInterests } = req.body;
      const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY });
      const context = \`Mein Profil:\\nBio: \${userBio}\\nInteressen: \${userInterests.join(', ')}\\n\\nMein Chatpartner (\${targetName}):\\nBio: \${targetBio}\\nInteressen: \${targetInterests.join(', ')}\`;
      
      const contents = [...messages.map((m: any) => ({
        role: m.role,
        parts: [{ text: m.content }]
      })), { role: "user", parts: [{ text: \`\\n\\nKontext:\\n\${context}\` }] }];
      
      const antwort = await beantworte(
        "/api/chat",
        (_signal) => ai.models.generateContent({
          model: process.env.GEMINI_MODEL || "gemini-3.5-flash-lite",
          contents,
          config: {
            systemInstruction: "Du bist der offizielle KI-Assistent der 'Klar Dating App'. Deine Kernaufgabe ist es, Nutzern dabei zu helfen, authentische, ehrliche und ansprechende Dating-Profile zu erstellen und respektvolle, passgenaue Konversationen mit Verbindungen zu starten. 'Klar' steht für Transparenz, Authentizität und direkte, ehrliche Kommunikation ohne Spielchen. Tonfall: Objektiv, aber empathisch. Direkt und klar (keine übertriebene Romantisierung). Respektvoll und professionell.Regeln:1. Profil-Erstellung: Formuliere flüssige, authentische Profiltexte aus Stichpunkten. Erfinde keine Hobbys (Zero-Hallucination-Policy).2. Chat-Starter: Liefere 2-3 konkrete, respektvolle Optionen basierend auf gemeinsamen Interessen oder Profilbildern.3. Feedback: Gib konstruktives Feedback zu Profilen.4. Sicherheit: Lehne explizite Inhalte, Belästigung oder PUA-Taktiken ab. Fordere nie sensible Daten.5. Antworte präzise, strukturiert.",
            responseMimeType: "application/json",
            responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } }
          }
        }),
        { json: true, feld: "text" }
      );
      res.status(antwort.status).json(antwort.koerper);
    } catch (e: unknown) {
      const antwort = ausfall("/api/chat", e);
      res.status(antwort.status).json(antwort.koerper);
    }
  });

`;

content = content.replace('  app.post("/api/check-safety", async (req, res) => {', apiChat + '  app.post("/api/check-safety", async (req, res) => {');

fs.writeFileSync('server.ts', content);
