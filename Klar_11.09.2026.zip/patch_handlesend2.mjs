import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf-8');

const target = '    localStorage.removeItem(`klar_chat_draft_${id}`);';
const replacement = `    localStorage.removeItem(\`klar_chat_draft_\${id}\`);

    // Epic 2 & 3: API call for real chats
    const msgText = input; // capture before state clears
    if (!istBeispielGespraech && auth.currentUser) {
      auth.currentUser.getIdToken().then(token => {
        fetch('/api/messages/send', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': \`Bearer \${token}\`
          },
          body: JSON.stringify({ chatId: id, text: msgText })
        }).catch(err => {
          console.error("Failed to send message via API", err);
        });
      });
    }`;

if (code.includes(target)) {
  code = code.replace(target, replacement);
  fs.writeFileSync('src/screens/ChatView.tsx', code);
  console.log("Patched successfully.");
} else {
  console.log("Could not find target.");
}
