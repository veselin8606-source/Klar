const fs = require('fs');

let content = fs.readFileSync('src/main.tsx', 'utf8');

if (!content.includes('Sentry.init')) {
  content = `import * as Sentry from "@sentry/react";\n` + content;
  content = content.replace(
    /createRoot\(document\.getElementById\('root'\)!\)\.render\(/,
    `Sentry.init({
  dsn: import.meta.env.VITE_SENTRY_DSN || "https://examplePublicKey@o0.ingest.sentry.io/0",
  integrations: [
    Sentry.browserTracingIntegration(),
    Sentry.replayIntegration(),
  ],
  tracesSampleRate: 1.0,
  replaysSessionSampleRate: 0.1,
  replaysOnErrorSampleRate: 1.0,
});

createRoot(document.getElementById('root')!).render(`
  );
  fs.writeFileSync('src/main.tsx', content);
}
console.log("Sentry patched.");
