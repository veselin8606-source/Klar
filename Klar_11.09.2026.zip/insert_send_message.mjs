import fs from 'fs';

let code = fs.readFileSync('server.ts', 'utf-8');

const newRoute = `

  // ── Epic 2: Live Translation - Central Message Endpoint ────────────────
  // Messages are no longer written by the client directly.
  app.post("/api/messages/send", requireAuth, async (req, res) => {
    try {
      const { chatId, text } = req.body;
      const { uid: meineUid } = req.user;
      
      if (!chatId || !text || typeof text !== 'string') {
        return res.status(400).json({ error: "Fehlende Parameter." });
      }

      if (text.length > 1000) {
        return res.status(400).json({ error: "Nachricht zu lang." });
      }

      const db = getFirestore();
      const chatRef = db.collection("chats").doc(chatId);
      const chatDoc = await chatRef.get();

      if (!chatDoc.exists) {
        return res.status(404).json({ error: "Chat nicht gefunden." });
      }

      const chatData = chatDoc.data();
      if (!chatData.participants || !chatData.participants.includes(meineUid)) {
        return res.status(403).json({ error: "Keine Berechtigung für diesen Chat." });
      }

      // Find other participant
      const andereUid = chatData.participants.find((p: string) => p !== meineUid);
      let textTranslated = null;
      let sourceLang = null;
      let targetLang = null;
      let translationProvider = null;

      if (andereUid) {
        const andereUserDoc = await db.collection("users").doc(andereUid).get();
        const andereUserData = andereUserDoc.data() || {};
        const empfaengerSprache = andereUserData.preferredLanguage;

        // Wenn der Empfänger eine explizite Sprache eingestellt hat
        if (empfaengerSprache) {
           targetLang = empfaengerSprache;
           
           // TODO: Epic 1 - Call python microservice here.
           // For now (Epic 2 stub), we simulate a successful call or timeout.
           try {
              // Simulierte Latenz von ca. 300ms (max 800ms)
              await new Promise(r => setTimeout(r, 300));
              
              // Dummy translation for stub:
              // Real implementation will POST to internal python service.
              textTranslated = \`[\${empfaengerSprache.toUpperCase()}] \${text}\`;
              sourceLang = 'auto'; // Model detects it
              translationProvider = 'nllb_local';
           } catch (e) {
              console.error("Translation microservice timeout/error:", e);
              // Graceful degradation: textTranslated remains null
           }
        }
      }

      const createdAt = new Date().toISOString();
      const messageId = db.collection("chats").doc(chatId).collection("messages").doc().id;

      // Firestore Batch für Message + Chat-Update
      const batch = db.batch();
      
      const messageRef = db.collection("chats").doc(chatId).collection("messages").doc(messageId);
      batch.set(messageRef, {
        chatId,
        senderId: meineUid,
        text: textTranslated || text, // Legacy support falls UI nur 'text' erwartet
        textOriginal: text,
        textTranslated: textTranslated,
        sourceLang,
        targetLang,
        translationProvider,
        createdAt
      });

      batch.update(chatRef, {
        lastMessage: text,
        lastMessageAt: createdAt
      });

      await batch.commit();

      res.status(200).json({ success: true, messageId, textTranslated });
    } catch (error) {
      console.error("Error in /api/messages/send:", error);
      res.status(500).json({ error: "Interner Serverfehler beim Senden." });
    }
  });
`;

if (!code.includes('/api/messages/send')) {
  // Insert before the first `app.post("/api/chat"`
  const pos = code.indexOf('app.post("/api/chat"');
  if (pos !== -1) {
    code = code.substring(0, pos) + newRoute + code.substring(pos);
    fs.writeFileSync('server.ts', code);
    console.log("Added /api/messages/send successfully.");
  } else {
    console.log("Could not find /api/chat");
  }
} else {
  console.log("Route already exists.");
}
