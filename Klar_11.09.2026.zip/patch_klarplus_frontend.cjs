const fs = require('fs');
let code = fs.readFileSync('src/screens/KlarPlus.tsx', 'utf-8');

const target = `  const handleConversionClick = () => {
    if (user?.uid && variant) {
      fetch("/api/analytics/ab-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.uid,
          eventName: "klarplus_conversion_click",
          variant,
          source: "KlarPlus_Landing"
        })
      }).catch(() => {});
    }
  };`;

const replace = `  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    if (urlParams.get('session_id')) {
      alert('Willkommen bei Klar+! Dein Abonnement ist nun aktiv.');
      window.history.replaceState({}, document.title, window.location.pathname);
    } else if (urlParams.get('cancel')) {
      setError('Der Bezahlvorgang wurde abgebrochen.');
      window.history.replaceState({}, document.title, window.location.pathname);
    }
  }, []);

  const handleConversionClick = async () => {
    if (!user?.uid) return;
    
    setLoading(true);
    setError(null);
    
    if (variant) {
      fetch("/api/analytics/ab-test", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.uid,
          eventName: "klarplus_conversion_click",
          variant,
          source: "KlarPlus_Landing"
        })
      }).catch(() => {});
    }
    
    try {
      const res = await fetch("/api/subscribe-klar-plus", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId: user.uid,
          returnUrl: window.location.origin + "/klar-plus"
        })
      });
      
      const data = await res.json();
      if (data.url) {
        window.location.href = data.url;
      } else {
        setError(data.error || "Ein Fehler ist aufgetreten.");
      }
    } catch (e) {
      setError("Verbindung zum Server fehlgeschlagen.");
    } finally {
      setLoading(false);
    }
  };`;

code = code.replace(target, replace);

const btnTarget = `      <button 
        onClick={handleConversionClick}
        className="w-full bg-accent hover:bg-accent-hover text-white font-medium py-3 rounded-xl mb-6 transition-colors shadow-sm"
      >
        Klar+ jetzt entdecken
      </button>
      <div role="note" className="rounded-2xl border border-line-ui p-5">`;

const btnReplace = `      {error && <p className="text-red-500 mb-4 text-sm">{error}</p>}
      <button 
        onClick={handleConversionClick}
        disabled={loading}
        className="w-full bg-accent hover:bg-accent-hover text-white font-medium py-3 rounded-xl mb-6 transition-colors shadow-sm disabled:opacity-50"
      >
        {loading ? 'Wird geladen...' : 'Klar+ jetzt entdecken'}
      </button>
      <div role="note" className="rounded-2xl border border-line-ui p-5">`;

code = code.replace(btnTarget, btnReplace);

fs.writeFileSync('src/screens/KlarPlus.tsx', code);
