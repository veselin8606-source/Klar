import fs from 'fs';
import { execSync } from 'child_process';

const historyFile = '/.aistudio/artifacts/brain/8f8ec149-4b56-40d6-a88c-fbadd2875018/.system_generated/logs/transcript.jsonl';
if (fs.existsSync(historyFile)) {
    console.log("History file exists");
} else {
    console.log("No history file to extract original source from.");
}
