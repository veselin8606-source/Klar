import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

content = content.replace(/const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt\.'/, "// const NICHT_VERFUEGBAR = 'Spracherkennung wird von deinem Browser leider nicht unterstützt.'");
content = content.replace(/const \[voiceRecognition, setVoiceRecognition\] = useState<Spracherkennung \| null>\(null\);/, "// const [voiceRecognition, setVoiceRecognition] = useState<Spracherkennung | null>(null);");

fs.writeFileSync('src/screens/ChatView.tsx', content);
