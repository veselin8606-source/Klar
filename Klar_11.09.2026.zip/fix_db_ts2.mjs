import fs from 'fs';
let content = fs.readFileSync('src/server/db.ts', 'utf8');

content = content.replace(/constructor\(db: any\) \{ this\.db = db; \} \{\}/g, "constructor(db: any) { this.db = db; }");
content = content.replace(/constructor\(db: any, pathStr: string\) \{ this\.db = db; this\.pathStr = pathStr; \} \{\}/g, "constructor(db: any, pathStr: string) { this.db = db; this.pathStr = pathStr; }");
content = content.replace(/constructor\(db: any, q: any\) \{ this\.db = db; this\.q = q; \} \{\}/g, "constructor(db: any, q: any) { this.db = db; this.q = q; }");
content = content.replace(/constructor\(_db: any, t: any\) \{ this\.t = t; \} \{\}/g, "constructor(_db: any, t: any) { this.t = t; }");
content = content.replace(/constructor\(b: any\) \{ this\.b = b; \} \{\}/g, "constructor(b: any) { this.b = b; }");

fs.writeFileSync('src/server/db.ts', content);
