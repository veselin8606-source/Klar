import fs from 'fs';
let code = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

code = code.replace(
  "import { db } from \"../lib/firebase\";", 
  "import { db } from \"../lib/firebase\";\nimport { getStorage, ref, uploadBytes, getDownloadURL } from \"firebase/storage\";"
);

code = code.replace(
  "// Normally upload to Firebase Storage:",
  "const storage = getStorage(); const storageRef = ref(storage, \`voice_messages/\${Date.now()}.webm\`);"
);
code = code.replace(
  "// const storageRef = ref(getStorage(), \\`voice/\\${Date.now()}.webm\\`);",
  "await uploadBytes(storageRef, blob);"
);
code = code.replace(
  "// await uploadBytes(storageRef, blob);",
  "const firebaseUrl = await getDownloadURL(storageRef);"
);
code = code.replace(
  "// const url = await getDownloadURL(storageRef);",
  ""
);
code = code.replace(
  "// Send message with url...",
  ""
);
code = code.replace(
  "const url = URL.createObjectURL(blob);",
  "const url = firebaseUrl;"
);

fs.writeFileSync('src/screens/ChatView.tsx', code);
