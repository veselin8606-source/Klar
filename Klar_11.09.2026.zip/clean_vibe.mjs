import fs from 'fs';

let dash = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
dash = dash.replace(/import \{ PrePostDateVibeWidget \} from "\.\.\/components\/PrePostDateVibeWidget";\n/, '');
dash = dash.replace(/import \{ SmartVibeMapWidget \} from "\.\.\/components\/SmartVibeMapWidget";\n/, '');
dash = dash.replace(/import \{ WeeklyVibesWidget \} from "\.\.\/components\/WeeklyVibesWidget";\n/, '');
dash = dash.replace(/.*<SmartVibeMapWidget \/>.*\n?/, '');
dash = dash.replace(/.*<PrePostDateVibeWidget \/>.*\n?/, '');
dash = dash.replace(/.*<WeeklyVibesWidget \/>.*\n?/, '');
// Sometimes they are wrapped in div
dash = dash.replace(/<div className="min-w-\[85%\] max-w-md snap-center shrink-0 empty:hidden">\s*<\/div>\n/g, '');
fs.writeFileSync('src/screens/Dashboard.tsx', dash);

let prof = fs.readFileSync('src/screens/Profile.tsx', 'utf8');
prof = prof.replace(/import \{ VibeSummaryPDFGenerator \} from "\.\.\/components\/VibeSummaryPDFGenerator";\n/, '');
prof = prof.replace(/import \{ DatingVibeChartWidget \} from "\.\.\/components\/DatingVibeChartWidget";\n/, '');
prof = prof.replace(/.*<DatingVibeChartWidget \/>.*\n?/, '');
prof = prof.replace(/.*<VibeSummaryPDFGenerator \/>.*\n?/, '');
fs.writeFileSync('src/screens/Profile.tsx', prof);

let tips = fs.readFileSync('src/screens/Tips.tsx', 'utf8');
tips = tips.replace(/import \{ DatingVibeCheckQuiz \} from "\.\.\/components\/DatingVibeCheckQuiz";\n/, '');
tips = tips.replace(/.*DatingVibeCheckQuiz.*\n?/g, '');
// there's a button and some state logic for 'vibecheck', let's see.
