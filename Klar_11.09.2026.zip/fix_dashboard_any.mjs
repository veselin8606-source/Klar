import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
content = content.replace(/const filtered = profiles\.filter\(p =>/g, 'const filtered = profiles.filter((p: any) =>');
content = content.replace(/\{renderKontaktCard\(profile\)\}/g, '{/* ... */}');
content = content.replace(/const renderKontaktCard = \(profile\) => \{/g, 'const renderKontaktCard = (profile: any) => {');
fs.writeFileSync('src/screens/Dashboard.tsx', content);
