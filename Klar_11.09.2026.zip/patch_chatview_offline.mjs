import fs from 'fs';

let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');

const offlineQueueHook = `
  // Offline Message Sync
  useEffect(() => {
    const syncOfflineMessages = async () => {
      if (!navigator.onLine || !auth.currentUser) return;
      const queueKey = \`klar_offline_msgs_\${id}\`;
      const queuedStr = localStorage.getItem(queueKey);
      if (queuedStr) {
        try {
          const queued = JSON.parse(queuedStr);
          if (Array.isArray(queued) && queued.length > 0) {
            const token = await auth.currentUser.getIdToken();
            for (const msg of queued) {
              await fetch('/api/messages/send', {
                method: 'POST',
                headers: {
                  'Content-Type': 'application/json',
                  'Authorization': \`Bearer \${token}\`
                },
                body: JSON.stringify({ chatId: id, text: msg.text })
              });
            }
            localStorage.removeItem(queueKey);
            // Reload messages to get the correct state from backend
            window.location.reload();
          }
        } catch (e) {
          console.error('Failed to sync offline messages', e);
        }
      }
    };

    window.addEventListener('online', syncOfflineMessages);
    return () => window.removeEventListener('online', syncOfflineMessages);
  }, [id, auth]);
`;

content = content.replace(
  '// Audio Cache laden (oder aehnliches)',
  offlineQueueHook + '\n  // Audio Cache laden (oder aehnliches)'
);

// If the above string is not there, we insert it near the beginning of ChatView body.
if (content.indexOf(offlineQueueHook) === -1) {
  content = content.replace(
    /export default function ChatView\(\) \{[\s\S]*?const \[messages, setMessages\] = useState<ChatMessage\[\]>\(\[\]\);/m,
    "export default function ChatView() {\n  const [messages, setMessages] = useState<ChatMessage[]>([]);\n" + offlineQueueHook
  );
}

const sendReplacement = `
    if (!istBeispielGespraech && auth.currentUser) {
      if (!navigator.onLine) {
        const queueKey = \`klar_offline_msgs_\${id}\`;
        const queued = JSON.parse(localStorage.getItem(queueKey) || '[]');
        queued.push({ text: msgText, timestamp: Date.now() });
        localStorage.setItem(queueKey, JSON.stringify(queued));
        // Also show a toast here optionally
        setOfflineToast(true);
        setTimeout(() => setOfflineToast(false), 3000);
      } else {
        auth.currentUser.getIdToken().then(token => {
          fetch('/api/messages/send', {
`;

content = content.replace(
  /    if \(!istBeispielGespraech && auth\.currentUser\) \{\s*auth\.currentUser\.getIdToken\(\)\.then\(token => \{/m,
  sendReplacement
);

// Need to add state for offlineToast
content = content.replace(
  "const [sprachHinweis, setSprachHinweis] = useState('');",
  "const [sprachHinweis, setSprachHinweis] = useState('');\n  const [offlineToast, setOfflineToast] = useState(false);\n  const [translationToast, setTranslationToast] = useState(false);"
);

// Add translationToast effect
const translationToastHook = `
  useEffect(() => {
    if (messages.length > 0) {
      const lastMsg = messages[messages.length - 1];
      if (lastMsg.role === 'verbindung' && lastMsg.translationStatus === 'completed' && !lastMsg.isRead) {
        setTranslationToast(true);
        const timer = setTimeout(() => setTranslationToast(false), 3000);
        return () => clearTimeout(timer);
      }
    }
  }, [messages]);
`;
content = content.replace(
  "  // Audio Cache laden",
  translationToastHook + "\n  // Audio Cache laden"
);
if (content.indexOf(translationToastHook) === -1) {
    content = content.replace(
        "const handleSend = async (forceSend = false) => {",
        translationToastHook + "\n  const handleSend = async (forceSend = false) => {"
    );
}

// Add UI for offline and translation toasts
const toastsUI = `
      <AnimatePresence>
        {offlineToast && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-stone-800 text-white px-4 py-2 rounded-full shadow-lg text-xs font-medium flex items-center gap-2">
            <Minimize2 size={14} /> Nachricht offline gespeichert. Wird gesendet, sobald du online bist.
          </motion.div>
        )}
        {translationToast && (
          <motion.div initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-brand text-white px-4 py-2 rounded-full shadow-lg text-xs font-medium flex items-center gap-2">
            <Languages size={14} /> Nachricht wurde automatisch übersetzt.
          </motion.div>
        )}
      </AnimatePresence>
`;

content = content.replace(
  "{/* DSGVO & KI Hinweis */}",
  toastsUI + "\n        {/* DSGVO & KI Hinweis */}"
);

fs.writeFileSync('src/screens/ChatView.tsx', content);
