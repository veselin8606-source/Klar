import fs from 'fs';

let content = fs.readFileSync('src/components/MessageBubble.tsx', 'utf8');

content = content.replace(
  "const original = msg.textOriginal || msg.text;",
  "const original = msg.original_text || msg.textOriginal || msg.text;"
);

content = content.replace(
  "const hasTranslation = !!msg.textTranslated && msg.translationStatus === 'completed';",
  "const hasTranslation = (!!msg.translated_text || !!msg.textTranslated) && msg.translationStatus === 'completed';"
);

content = content.replace(
  "{msg.textTranslated}",
  "{msg.translated_text || msg.textTranslated}"
);

fs.writeFileSync('src/components/MessageBubble.tsx', content);
