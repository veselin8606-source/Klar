import fs from 'fs';
let content = fs.readFileSync('src/components/ProfileDetailModal.tsx', 'utf8');
content = content.replace("import React, { useEffect, useRef } from 'react';", "import { useEffect, useRef } from 'react';");
fs.writeFileSync('src/components/ProfileDetailModal.tsx', content);
