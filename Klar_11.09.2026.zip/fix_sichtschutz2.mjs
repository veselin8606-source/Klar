import fs from 'fs';
let content = fs.readFileSync('src/components/Sichtschutz.tsx', 'utf8');

content = content.replace(/      transition=\{\{ duration: 0\.1 \}\}    \n      onClick=\{aktiviereSichtschutz\}    \n      className="p-2 rounded-full text-stone-700 dark:text-stone-300 hover:bg-stone-200 dark:hover:bg-stone-800 transition-colors"    \n      aria-label="Bildschirm verdecken"    \n      title="Bildschirm verdecken"    \n    >    \n      <EyeOff size=\{20\} \/>    \n    <\/motion\.button>    \n  \);    \n\}    \n/g, "");

fs.writeFileSync('src/components/Sichtschutz.tsx', content);
