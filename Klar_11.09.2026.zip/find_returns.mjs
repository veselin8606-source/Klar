import fs from 'fs';
const text = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
const lines = text.split('\n');

for (let i = 0; i < lines.length; i++) {
  if (lines[i].includes('return')) {
    console.log(`${i+1}: ${lines[i]}`);
  }
}
