#!/bin/bash
sed -i -e '/function AnimatedRoutes() {/,/^}/c\
const LazyRoute = ({ component: Component }: { component: React.ComponentType<any> }) => (\
  <ErrorBoundary>\
    <Suspense fallback={<Ladepunkt />}>\
      <PageWrapper>\
        <Component />\
      </PageWrapper>\
    </Suspense>\
  </ErrorBoundary>\
);\
\
function AnimatedRoutes() {\
  const location = useLocation();\
  return (\
    <AnimatePresence mode="wait">\
      <Routes location={location} key={location.pathname}>\
        <Route path="/" element={<LazyRoute component={Dashboard} />} />\
        <Route path="/chats" element={<LazyRoute component={Chats} />} />\
        <Route path="/chat/:id" element={<LazyRoute component={ChatView} />} />\
        <Route path="/ai-coach" element={<LazyRoute component={AICoach} />} />\
        <Route path="/tips" element={<LazyRoute component={Tips} />} />\
        <Route path="/profile" element={<LazyRoute component={Profile} />} />\
        <Route path="/klar-plus" element={<LazyRoute component={KlarPlus} />} />\
        <Route path="/meilensteine" element={<LazyRoute component={MeilensteineAlle} />} />\
        <Route path="/rituals" element={<LazyRoute component={DatingRituals} />} />\
        <Route path="/safety" element={<LazyRoute component={SafetyCenter} />} />\
        <Route path="/verifizierung" element={<LazyRoute component={Verifizierung} />} />\
        <Route path="/admin" element={<LazyRoute component={AdminDashboard} />} />\
        <Route path="/rechtstexte/:art" element={<LazyRoute component={Rechtstexte} />} />\
        <Route path="*" element={<LazyRoute component={NotFoundHandler} />} />\
      </Routes>\
    </AnimatePresence>\
  );\
}' src/App.tsx
