const fs = require('fs');
let code = fs.readFileSync('src/server/trustAndSafety.ts', 'utf8');

const replacement = `
    // 6a. Weitere Sammlungen (DSGVO)
    await db.collection('public_profiles').doc(meineUid).delete();
    await loescheAbfrage(db.collection('analytics_events').where('userId', '==', meineUid));
    await loescheAbfrage(db.collection('mail_queue').where('uid', '==', meineUid));
    await loescheAbfrage(db.collection('verification_requests').where('uid', '==', meineUid));
    await loescheAbfrage(db.collection('verification_events').where('uid', '==', meineUid));
    await loescheAbfrage(db.collection('audit_logs').where('userId', '==', meineUid));

    // 7. Profil.
`;

code = code.replace('// 7. Profil.', replacement);
fs.writeFileSync('src/server/trustAndSafety.ts', code);
