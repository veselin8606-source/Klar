import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

// Fix /api/chat
content = content.replace(
/(\/api\/chat"[\s\S]*?)config: \{([\s\S]*?)\}([\s\S]*?)\},[\s\S]*?\{ json: false, feld: "text" \},/g, 
`$1config: {$2, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } } }$3},`
);

// Fix /api/generate-message
content = content.replace(
/(\/api\/generate-message"[\s\S]*?)config: \{([\s\S]*?)\}([\s\S]*?)\},[\s\S]*?\{ json: false, feld: "text" \},/g, 
`$1config: {$2, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } } }$3},`
);

// Fix /api/quick-insight
content = content.replace(
/(\/api\/quick-insight"[\s\S]*?contents: `[^`]*`)(,[\s\S]*?\}\)),[\s\S]*?\{ json: false, feld: 'insight' \},/g, 
`$1, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { insight: { type: Type.STRING } } } }$2,`
);

// Fix /api/translate
content = content.replace(
/(\/api\/translate"[\s\S]*?)config: \{([\s\S]*?)\}([\s\S]*?)\},[\s\S]*?\{ json: false, feld: "text" \},/g, 
`$1config: {$2, responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { text: { type: Type.STRING } } } }$3},`
);

// Fix /api/generate-reflection-from-emojis
content = content.replace(
/(\/api\/generate-reflection-from-emojis"[\s\S]*?contents: `[^`]*`)(,[\s\S]*?\}\)),[\s\S]*?\{ json: false, feld: "notes" \},/g, 
`$1, config: { responseMimeType: "application/json", responseSchema: { type: Type.OBJECT, properties: { notes: { type: Type.STRING } } } }$2,`
);

fs.writeFileSync('server.ts', content);
