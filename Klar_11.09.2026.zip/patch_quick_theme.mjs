import fs from 'fs';

let code = fs.readFileSync('src/components/QuickThemeToggle.tsx', 'utf-8');

// Add import
const importMotion = `import { motion, AnimatePresence } from 'motion/react';\n`;
if (!code.includes('motion/react')) {
  code = code.replace(
    `import { Sun, Moon } from 'lucide-react';`,
    `import { Sun, Moon } from 'lucide-react';\n${importMotion}`
  );
}

// Replace button content
const targetRegex = /\{wirktDunkel \? <Sun size=\{20\} \/> : <Moon size=\{20\} \/>\}/;
const replacement = `<AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={wirktDunkel ? 'sun' : 'moon'}
          initial={{ opacity: 0, scale: 0.8, rotate: wirktDunkel ? -30 : 30 }}
          animate={{ opacity: 1, scale: 1, rotate: 0 }}
          exit={{ opacity: 0, scale: 0.8, rotate: wirktDunkel ? 30 : -30 }}
          transition={{ duration: 0.15 }}
          className="flex items-center justify-center"
        >
          {wirktDunkel ? <Sun size={20} /> : <Moon size={20} />}
        </motion.div>
      </AnimatePresence>`;

code = code.replace(targetRegex, replacement);

fs.writeFileSync('src/components/QuickThemeToggle.tsx', code);
console.log("Patched QuickThemeToggle.tsx");
