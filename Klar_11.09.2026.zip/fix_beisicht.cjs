const fs = require('fs');
let d = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
d = d.replace(/<BeiSicht>\s*<\/BeiSicht>/g, '');
fs.writeFileSync('src/screens/Dashboard.tsx', d);
console.log("Fixed empty BeiSicht");
