import fs from 'fs';
let content = fs.readFileSync('src/screens/ChatView.tsx', 'utf8');
if (content.endsWith('}\n}')) {
  content = content.slice(0, -1);
} else if (content.endsWith('}\n}\n')) {
  content = content.slice(0, -2) + '\n';
}
fs.writeFileSync('src/screens/ChatView.tsx', content);
