import fs from 'fs';
let code = fs.readFileSync('server.ts', 'utf8');

code = code.replace(
  "const { user_id, reward_amount, transaction_id, signature, key_id } = req.query;",
  "const { user_id, reward_amount, transaction_id, signature, key_id } = req.query as Record<string, string>;"
);

// I should check what is actually destructured:
code = code.replace(
  "const { user_id, reward_amount, transaction_id, signature, key_id } = req.query;",
  "const { user_id, reward_amount, transaction_id, signature, key_id } = req.query as { user_id: string, reward_amount: string, transaction_id: string, signature: string, key_id: string };"
);

fs.writeFileSync('server.ts', code);
console.log('Fixed req.query');
