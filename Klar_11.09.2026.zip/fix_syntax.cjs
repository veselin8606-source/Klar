const fs = require('fs');

function replaceInFile(filepath, regex, replacement) {
  if (fs.existsSync(filepath)) {
    let content = fs.readFileSync(filepath, 'utf8');
    content = content.replace(regex, replacement);
    fs.writeFileSync(filepath, content);
  }
}

replaceInFile('src/components/DateArchiveWidget.tsx', /0\.toString\(36\)/g, '"0"');
replaceInFile('src/components/MoodDiaryWidget.tsx', /0\.toString\(36\)/g, '"0"');
replaceInFile('src/components/ProfileCheckWidget.tsx', /0\.toString\(36\)/g, '"0"');
replaceInFile('src/screens/AICoach.tsx', /0\.toString\(36\)/g, '"0"');

// Fix SuccessDashboardWidget where confetti code was removed but left broken braces
let successContent = fs.readFileSync('src/components/SuccessDashboardWidget.tsx', 'utf8');
// This file likely has an unbalanced brace from the `import('canvas-confetti').then((confetti) => {` that we removed the start of, but not the end.
// We need to restore it from the clean source or fix it manually. Let's just fix the method.
successContent = successContent.replace(/import\('canvas-confetti'\)\.then\(\(confetti\) => \{/, '');
successContent = successContent.replace(/confetti\.default\(\{[\s\S]*?\}\);\n/g, '');
// The ending `});` might still be there.
successContent = successContent.replace(/\s*\}\);\s*\}\);/g, '});'); // Try to balance
fs.writeFileSync('src/components/SuccessDashboardWidget.tsx', successContent);

console.log("Syntax fixed.");
