const fs = require('fs');
let server = fs.readFileSync('server.ts', 'utf8');

// The array is called KI_ENDPUNKTE inside server.ts
// Let's find it.
const startIdx = server.indexOf('const KI_ENDPUNKTE = new Set([');
const endIdx = server.indexOf(']);', startIdx);
const existingArrayStr = server.substring(startIdx, endIdx + 3);

// We need to only keep existing KI endpoints
// Existing endpoints that call AI:
// /api/daily-coach-insight
// /api/dating-readiness
// /api/date-inspiration
// /api/optimize-bio-values
// /api/smart-audit
// /api/messages/send-audio
// Let's extract existing app.post, app.get
const routes = [...server.matchAll(/app\.(post|get)\("([^"]+)"/g)].map(m => m[2]);
const kiRoutes = ['/api/messages/send-audio', '/api/nogo-suggestions', '/api/compatibility-radar', '/api/dating-journal-analysis', '/api/date-check']; // plus others... let's just make KI_ENDPUNKTE match what's needed.

let newEndpunkte = new Set(['/api/messages/send-audio']);
// Let's parse all routes calling `ai.models.generateContent`
const lines = server.split('\n');
let currentRoute = '';
for (let i = 0; i < lines.length; i++) {
  const match = lines[i].match(/app\.(post|get)\("([^"]+)"/);
  if (match) currentRoute = match[2];
  if (lines[i].includes('ai.models.generateContent') || lines[i].includes('ai.models.streamGenerateContent')) {
     if (currentRoute) newEndpunkte.add(currentRoute);
  }
}
console.log("Found KI routes:", Array.from(newEndpunkte));

const newSetStr = 'const KI_ENDPUNKTE = new Set([\n' + Array.from(newEndpunkte).map(r => `  "${r}",`).join('\n') + '\n]);';
server = server.replace(existingArrayStr, newSetStr);
fs.writeFileSync('server.ts', server);

console.log("Fixed KI_ENDPUNKTE");
