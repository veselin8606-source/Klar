#!/bin/bash
# Note: Changing this in the frontend would require changing the backend /api/ai-coach route as well to return structured JSON.
# Since we are generating the audit table for the user to approve first, we will just record this in the audit.
