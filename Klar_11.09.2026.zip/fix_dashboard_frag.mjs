import fs from 'fs';
let content = fs.readFileSync('src/screens/Dashboard.tsx', 'utf8');
content = content.replace(/\{modalProfile && \(\n          <motion\.div \n              initial=\{\{ opacity: 0 \}\}/g, "{modalProfile && (\n          <>\n          <motion.div \n              initial={{ opacity: 0 }}");
content = content.replace(/                <\/div>\n              <\/div>\n            <\/motion\.div>\n        \)\}\n      <\/AnimatePresence>/g, "                </div>\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>");

content = content.replace(/\{smartKontaktDetailProfile && \(\n          <motion\.div\n            initial=\{\{ opacity: 0 \}\}/g, "{smartKontaktDetailProfile && (\n          <>\n          <motion.div\n            initial={{ opacity: 0 }}");
content = content.replace(/                   <\/button>\n                <\/div>\n              <\/div>\n            <\/motion\.div>\n          \)\}\n        <\/AnimatePresence>/g, "                   </button>\n                </div>\n              </div>\n            </motion.div>\n          </>\n        )}\n      </AnimatePresence>");

fs.writeFileSync('src/screens/Dashboard.tsx', content);
