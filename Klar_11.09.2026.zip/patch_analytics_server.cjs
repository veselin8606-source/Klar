const fs = require('fs');
let code = fs.readFileSync('server.ts', 'utf-8');

// 1. Add import
const importStr = `import { trackEvent } from "./src/server/analytics";\n`;
if (!code.includes('import { trackEvent }')) {
  code = code.replace(`import express from "express";`, `import express from "express";\n${importStr}`);
}

// 2. Add to Ads callback
const adTarget = `        // Transaktion erfassen
        t.set(ledgerRef, {
          type: 'grant',
          amount: parseInt(reward_amount || '3', 10),
          reason: 'admob_reward',
          transaction_id: transaction_id,
          timestamp: require('firebase-admin').firestore.FieldValue.serverTimestamp()
        });
      });`;

const adReplace = `        // Transaktion erfassen
        t.set(ledgerRef, {
          type: 'grant',
          amount: parseInt(reward_amount || '3', 10),
          reason: 'admob_reward',
          transaction_id: transaction_id,
          timestamp: require('firebase-admin').firestore.FieldValue.serverTimestamp()
        });
      });
      
      // Tracking fuer Unit Economics
      await trackEvent(user_id, 'ad_watched', { reward_amount, transaction_id });`;

code = code.replace(adTarget, adReplace);

fs.writeFileSync('server.ts', code);
