import fs from 'fs';
let content = fs.readFileSync('server.ts', 'utf8');

content = content.replace(/\} \}\n            \}\n          \}\n        \}\n      \}\);\n/m, 
`} }
            }
          }
        }
      }), { json: true });\n`);

fs.writeFileSync('server.ts', content);
